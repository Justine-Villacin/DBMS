// Professor Dashboard JavaScript

// Global variables
let currentClassId = null;
let classes = [];
let assignments = [];
let submissions = [];
let calendarEvents = {};
let notifications = [];

// DOM Elements
const sidebar = document.getElementById('sidebar');
const contentSections = document.querySelectorAll('.content-section');
const navLinks = document.querySelectorAll('.sidebar nav a');
const profileDropdown = document.getElementById('profile-dropdown');
const dropdownMenu = document.getElementById('dropdown-menu');
// Added for Assignment/Material saving functions
const assignmentModal = document.getElementById('assignment-modal');
const gradingModal = document.getElementById('grading-modal');

if (!assignmentModal) {
    console.error('Assignment modal not found');
}
if (!gradingModal) {
    console.error('Grading modal not found');
}

// Sidebar toggle
function toggleSidebar() {
  sidebar.classList.toggle('collapsed');
}

// Load notifications from localStorage
function loadNotifications() {
  const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
  const saved = localStorage.getItem(`${userType}_notifications`);
  if (saved) {
    try {
      notifications = JSON.parse(saved);
      updateNotificationBadge();
    } catch (e) {
      console.error('Error loading notifications:', e);
      notifications = [];
    }
  }
}

// Save notifications to localStorage
function saveNotifications() {
  const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
  localStorage.setItem(`${userType}_notifications`, JSON.stringify(notifications));
  updateNotificationBadge();
}

// Add a new notification
function addNotification(type, title, message, link = null) {
  const notification = {
    id: Date.now().toString(),
    type: type, // 'assignment', 'grade', 'material', 'enrollment', 'submission'
    title: title,
    message: message,
    link: link,
    timestamp: new Date().toISOString(),
    read: false
  };
  
  notifications.unshift(notification); // Add to beginning
  
  // Keep only last 50 notifications
  if (notifications.length > 50) {
    notifications = notifications.slice(0, 50);
  }
  
  saveNotifications();
}

// Update notification badge
function updateNotificationBadge() {
  const badge = document.querySelector('.notification-badge');
  if (badge) {
    const unreadCount = notifications.filter(n => !n.read).length;
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'block' : 'none';
  }
}

// Mark notification as read
function markNotificationRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification) {
    notification.read = true;
    saveNotifications();
  }
}

// Mark all as read
function markAllNotificationsRead() {
  notifications.forEach(n => n.read = true);
  saveNotifications();
}

// Clear all notifications
function clearAllNotifications() {
  if (confirm('Are you sure you want to clear all notifications?')) {
    notifications = [];
    saveNotifications();
    closeNotificationPanel();
  }
}

// Enhanced notification system with upcoming deadlines and recent activity
function generateUpcomingDeadlinesNotifications() {
  const notifications = [];
  const now = new Date();
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  
  // Check all classes for upcoming deadlines
  classes.forEach(classItem => {
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const dueDate = new Date(assignment.dueDate);
        if (dueDate > now && dueDate <= nextWeek) {
          const daysUntilDue = Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24));
          notifications.push({
            id: `deadline-${assignment.id}`,
            type: 'deadline',
            title: `Upcoming Deadline`,
            message: `${assignment.title} in ${classItem.name} due in ${daysUntilDue} day${daysUntilDue > 1 ? 's' : ''}`,
            timestamp: assignment.dueDate,
            priority: daysUntilDue <= 2 ? 'high' : 'medium'
          });
        }
      });
    }
  });
  
  return notifications.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
}

function generateRecentActivityNotifications() {
  const notifications = [];
  const now = new Date();
  const last24Hours = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  
  // Check for recent submissions
  classes.forEach(classItem => {
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        if (assignment.submissions) {
          assignment.submissions.forEach(submission => {
            const submissionDate = new Date(submission.date);
            if (submissionDate >= last24Hours) {
              notifications.push({
                id: `submission-${submission.id}`,
                type: 'submission',
                title: `New Submission`,
                message: `${submission.studentName} submitted "${assignment.title}"`,
                timestamp: submission.date,
                priority: 'medium'
              });
            }
          });
        }
      });
    }
  });
  
  return notifications.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// Show notification panel
function showNotificationPanel() {
  const existingPanel = document.getElementById('notification-panel');
  if (existingPanel) {
    existingPanel.remove();
    return;
  }
  
  const panel = document.createElement('div');
  panel.id = 'notification-panel';
  panel.style.cssText = `
    position: fixed;
    top: 70px;
    right: 20px;
    width: 400px;
    max-height: 600px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    z-index: 10000;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  `;
  
  let panelHTML = `
    <div style="padding: 1.5rem; border-bottom: 2px solid #e0e0e0; display: flex; justify-content: space-between; align-items: center; background: #4a90a4; color: white;">
      <h3 style="margin: 0; font-size: 1.2rem;">
        <i class="fas fa-bell"></i> Notifications
      </h3>
      <div style="display: flex; gap: 0.5rem;">
        <button onclick="markAllNotificationsRead()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;" title="Mark all as read">
          <i class="fas fa-check-double"></i>
        </button>
        <button onclick="clearAllNotifications()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;" title="Clear all">
          <i class="fas fa-trash"></i>
        </button>
        <button onclick="closeNotificationPanel()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;">
          <i class="fas fa-times"></i>
        </button>
      </div>
    </div>
    <div style="overflow-y: auto; max-height: 500px;">
  `;
  
  if (notifications.length === 0) {
    panelHTML += `
      <div style="padding: 3rem; text-align: center; color: #666;">
        <i class="fas fa-bell-slash" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
        <p>No notifications</p>
      </div>
    `;
  } else {
    notifications.forEach(notification => {
      const iconMap = {
        'assignment': 'fa-tasks',
        'grade': 'fa-star',
        'material': 'fa-file-upload',
        'enrollment': 'fa-user-plus',
        'submission': 'fa-paper-plane'
      };
      
      const colorMap = {
        'assignment': '#4a90a4',
        'grade': '#28a745',
        'material': '#17a2b8',
        'enrollment': '#6c757d',
        'submission': '#ffc107'
      };
      
      const icon = iconMap[notification.type] || 'fa-bell';
      const color = colorMap[notification.type] || '#4a90a4';
      const isUnread = !notification.read;
      
      panelHTML += `
        <div onclick="handleNotificationClick('${notification.id}', '${notification.link || ''}')" 
             style="padding: 1rem 1.5rem; border-bottom: 1px solid #f0f0f0; cursor: pointer; background: ${isUnread ? '#f8f9fa' : 'white'}; transition: all 0.2s ease;"
             onmouseover="this.style.background='#e8f4f8'"
             onmouseout="this.style.background='${isUnread ? '#f8f9fa' : 'white'}'">
          <div style="display: flex; gap: 1rem; align-items: start;">
            <div style="width: 40px; height: 40px; border-radius: 50%; background: ${color}20; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
              <i class="fas ${icon}" style="color: ${color}; font-size: 1.1rem;"></i>
            </div>
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.25rem;">
                <strong style="font-size: 0.95rem; color: #333;">${notification.title}</strong>
                ${isUnread ? '<span style="width: 8px; height: 8px; background: #4a90a4; border-radius: 50%; display: inline-block; margin-left: 0.5rem;"></span>' : ''}
              </div>
              <p style="margin: 0; color: #666; font-size: 0.85rem; line-height: 1.4;">${notification.message}</p>
              <span style="font-size: 0.75rem; color: #999; margin-top: 0.5rem; display: block;">
                ${formatNotificationTime(notification.timestamp)}
              </span>
            </div>
          </div>
        </div>
      `;
    });
  }
  
  panelHTML += `</div>`;
  panel.innerHTML = panelHTML;
  document.body.appendChild(panel);
  
  // Close on outside click
  setTimeout(() => {
    document.addEventListener('click', handleOutsideClick);
  }, 100);
}

function handleOutsideClick(e) {
  const panel = document.getElementById('notification-panel');
  const notificationIcon = document.querySelector('.notification-icon');
  
  if (panel && !panel.contains(e.target) && !notificationIcon.contains(e.target)) {
    closeNotificationPanel();
  }
}

function closeNotificationPanel() {
  const panel = document.getElementById('notification-panel');
  if (panel) {
    panel.remove();
    document.removeEventListener('click', handleOutsideClick);
  }
}

function handleNotificationClick(notificationId, link) {
  markNotificationRead(notificationId);
  
  if (link) {
    // Handle internal navigation
    if (link.startsWith('class:')) {
      const classId = link.replace('class:', '');
      openClass(classId);
    } else if (link.startsWith('section:')) {
      const sectionId = link.replace('section:', '');
      showSection(sectionId);
    }
  }
  
  closeNotificationPanel();
}

function formatNotificationTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  return date.toLocaleDateString();
}

// ✅ ADD: Hook up notification icon click
document.addEventListener('DOMContentLoaded', function() {
  loadNotifications();
  
  const notificationIcon = document.querySelector('.notification-icon');
  if (notificationIcon) {
    notificationIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      showNotificationPanel();
    });
  }
  
  
});

    document.querySelectorAll('.settings-tab').forEach(tab => {
    tab.addEventListener('click', function() {
      const tabName = this.getAttribute('data-tab');
      
      document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
      
      this.classList.add('active');
      document.getElementById(`${tabName}-settings`).classList.add('active');
    });
  });
  
  // ✅ Password update in settings
  document.getElementById('settings-update-password')?.addEventListener('click', async function() {
    const currentPassword = document.getElementById('settings-current-password').value.trim();
    const newPassword = document.getElementById('settings-new-password').value.trim();
    const confirmPassword = document.getElementById('settings-confirm-password').value.trim();
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert('Please fill in all password fields');
      return;
    }
    
    if (newPassword.length < 8) {
      alert('New password must be at least 8 characters');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    
    try {
      this.disabled = true;
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
      
      const response = await fetch('/api/profile/update-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword
        })
      });
      
      const result = await response.json();
      
      if (response.ok) {
        alert('✅ Password updated successfully!');
        document.getElementById('settings-current-password').value = '';
        document.getElementById('settings-new-password').value = '';
        document.getElementById('settings-confirm-password').value = '';
      } else {
        alert('❌ ' + (result.error || 'Failed to update password'));
      }
    } catch (error) {
      alert('❌ Error updating password: ' + error.message);
    } finally {
      this.disabled = false;
      this.innerHTML = 'Update Password';
    }
  });
  
  // ✅ Notification settings
  document.getElementById('save-notification-settings')?.addEventListener('click', function() {
    const settings = {
      assignments: document.getElementById('notif-assignments').checked,
      grades: document.getElementById('notif-grades').checked,
      materials: document.getElementById('notif-materials').checked,
      deadlines: document.getElementById('notif-deadlines').checked
    };
    
    const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
    localStorage.setItem(`${userType}_notification_settings`, JSON.stringify(settings));
    
    alert('✅ Notification settings saved!');
  });
  
  // ✅ Privacy settings
document.getElementById('save-privacy-settings')?.addEventListener('click', function() {
  const settings = {
    profileVisible: document.getElementById('privacy-profile').checked,
    emailVisible: document.getElementById('privacy-email').checked
  };
  
  const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
  localStorage.setItem(`${userType}_privacy_settings`, JSON.stringify(settings));
  
  // âœ… SHOW SUCCESS MESSAGE
  alert('âœ… Privacy settings saved successfully!');
});

// âœ… ADD: Clear all data function (around line 220)
document.getElementById('clear-all-data')?.addEventListener('click', function() {
  if (confirm('âš ï¸ Are you sure? This will clear ALL your data from LearnSync.\n\nThis includes:\nâ€¢ All classes and their content\nâ€¢ All assignments and submissions\nâ€¢ All materials and files\nâ€¢ Your profile picture\nâ€¢ All notifications\n\nThis action CANNOT be undone!')) {
    if (confirm('âš ï¸ FINAL WARNING: Press OK to permanently delete all data.')) {
      const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
      
      // Clear all localStorage data
      const keysToRemove = [
        `${userType}_classes`,
        `${userType}_notifications`,
        `${userType}_avatar`,
        `${userType}_notification_settings`,
        `${userType}_privacy_settings`,
        'professor_classes',
        'calendar_events'
      ];
      
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      alert('âœ… All data cleared successfully!\n\nThe page will now reload.');
      window.location.reload();
    }
  }
});

// âœ… LOAD saved privacy settings on page load
function loadSavedSettings() {
  const userType = document.body.classList.contains('professor-dashboard') ? 'professor' : 'student';
  
  // Load notification settings
  const notifSettings = localStorage.getItem(`${userType}_notification_settings`);
  if (notifSettings) {
    try {
      const settings = JSON.parse(notifSettings);
      document.getElementById('notif-assignments').checked = settings.assignments !== false;
      document.getElementById('notif-grades').checked = settings.grades !== false;
      document.getElementById('notif-materials').checked = settings.materials !== false;
      document.getElementById('notif-deadlines').checked = settings.deadlines !== false;
    } catch (e) {
      console.error('Error loading notification settings:', e);
    }
  }
  
  // âœ… LOAD privacy settings
  const privacySettings = localStorage.getItem(`${userType}_privacy_settings`);
  if (privacySettings) {
    try {
      const settings = JSON.parse(privacySettings);
      document.getElementById('privacy-profile').checked = settings.profileVisible !== false;
      document.getElementById('privacy-email').checked = settings.emailVisible === true;
    } catch (e) {
      console.error('Error loading privacy settings:', e);
    }
  }
}


// Show section function
function showSection(sectionId, element = null) {
  // Hide all sections INCLUDING class-view
  contentSections.forEach(section => {
    section.classList.remove('active');
  });
  
  // IMPORTANT: Also hide class-view explicitly
  const classView = document.getElementById('class-view');
  if (classView) {
    classView.classList.add('hidden');
    classView.classList.remove('active');
  }

  // Remove active class from all nav links
  if (element) {
    navLinks.forEach(link => {
      link.classList.remove('active');
    });
    element.classList.add('active');
  }

  // Show selected section (but not if it's class-view)
  if (sectionId !== 'class-view') {
    const section = document.getElementById(sectionId);
    if (section) {
      section.classList.add('active');
      
      // CRITICAL FIX: Load data based on section
      if (sectionId === 'students-section') {
        setTimeout(loadAllStudents, 50);
      } else if (sectionId === 'assignments-section') {
        // For student dashboard
        if (typeof loadAllAssignments === 'function') {
          setTimeout(loadAllAssignments, 50);
        }
      }
    }
  }
}

// Profile dropdown toggle
if (profileDropdown) {
  profileDropdown.addEventListener('click', function(e) {
    e.stopPropagation();
    dropdownMenu.classList.toggle('show');
  });
}

// Close dropdown when clicking outside
document.addEventListener('click', function() {
  dropdownMenu.classList.remove('show');
});

document.addEventListener('DOMContentLoaded', function() {
  // Date picker OK button functionality
  const dateInput = document.getElementById('assignment-due-date');
  const confirmBtn = document.getElementById('confirm-date-btn');
  
  if (dateInput && confirmBtn) {
    // Show OK button when date input is focused or has value
    dateInput.addEventListener('focus', function() {
      confirmBtn.style.display = 'flex';
    });
    
    dateInput.addEventListener('input', function() {
      if (this.value) {
        confirmBtn.style.display = 'flex';
      }
    });
    
    // Hide OK button when date input loses focus and has no value
    dateInput.addEventListener('blur', function() {
      if (!this.value) {
        setTimeout(() => {
          if (document.activeElement !== confirmBtn) {
            confirmBtn.style.display = 'none';
          }
        }, 200);
      }
    });
    
    // OK button click handler
    confirmBtn.addEventListener('click', function() {
      if (dateInput.value) {
        // Close the date picker by blurring the input
        dateInput.blur();
        // Hide the OK button
        this.style.display = 'none';
        
        // Optional: Add visual feedback
        this.style.background = '#28a745';
        setTimeout(() => {
          this.style.background = '';
        }, 300);
      }
    });
    
    // Keep OK button visible when it's focused
    confirmBtn.addEventListener('focus', function() {
      this.style.display = 'flex';
    });
    
    confirmBtn.addEventListener('blur', function() {
      if (!dateInput.value) {
        this.style.display = 'none';
      }
    });
  }

  // Initialize dashboard stats
  updateDashboardStats();
  
  // Load classes from API
  loadClasses();
  
  // Initialize calendar
  initializeCalendar();
  
  // Event listeners for class management
  document.getElementById('create-class-btn').addEventListener('click', showCreateClassModal);
  document.getElementById('cancel-class').addEventListener('click', hideCreateClassModal);
  document.getElementById('save-class').addEventListener('click', createClass);
  
  // Auto-generate class code
  document.getElementById('class-name').addEventListener('input', function() {
    if (!document.getElementById('class-code').value) {
      document.getElementById('class-code').value = generateClassCode();
    }
  
  });

    // ✅ ADD THIS - Assignment modal controls (MUST be inside DOMContentLoaded)
  const createAssignmentBtns = document.querySelectorAll('[onclick*="createAssignment"]');
  createAssignmentBtns.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      if (assignmentModal) {
        assignmentModal.style.display = 'flex';
        // Reset form
        resetAssignmentForm();
      }
    });
  });
  
  // Existing assignment modal controls
  if (assignmentModal) {
    document.getElementById('close-assignment-modal').addEventListener('click', function() {
      assignmentModal.style.display = 'none';
      resetAssignmentForm();
    });
  }
  

  
  // Back to classes button
  document.getElementById('back-to-classes').addEventListener('click', function() {
    document.getElementById('class-view').classList.add('hidden');
    // Ensure the main "Enrolled Classes" section is made active and visible
    document.getElementById('class-view').classList.remove('active');
    document.getElementById('enrolled-section').classList.add('active');
    currentClassId = null; // Clear current class context
  });
  
  // Upload form controls
  document.getElementById('show-upload-form').addEventListener('click', function() {
    document.getElementById('upload-form').classList.remove('hidden');
  });
  
  document.getElementById('cancel-upload').addEventListener('click', function() {
    document.getElementById('upload-form').classList.add('hidden');
    resetUploadForm();
  });
  
  document.getElementById('post-upload').addEventListener('click', uploadMaterial);
  
  // File upload display
  document.getElementById('lesson-file').addEventListener('change', function() {
    const fileChosen = document.getElementById('file-chosen');
    if (this.files.length > 0) {
      fileChosen.textContent = `${this.files.length} file(s) selected`;
    } else {
      fileChosen.textContent = 'No files selected';
    }
  });
  
  // Tab switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tabName = this.getAttribute('data-tab');
      switchTab(tabName);
      
      // Load content when tabs are clicked
      if (currentClassId) {
        if (tabName === 'posts') loadClassPosts();
        if (tabName === 'students') loadClassStudents();
        if (tabName === 'assignments') loadClassAssignments();
        if (tabName === 'grades') loadClassGrades();
      }
    });
  });
  
  // Assignment modal controls
  if (assignmentModal) {
    document.getElementById('close-assignment-modal').addEventListener('click', function() {
      assignmentModal.style.display = 'none';
      resetAssignmentForm(); // Bug fix: Reset form when closing
    });
  }
  
  
  document.getElementById('save-assignment').addEventListener('click', saveAssignment);
  
  // Assignment files display
  document.getElementById('assignment-files').addEventListener('change', function() {
    const fileChosen = document.getElementById('assignment-files-chosen');
    if (this.files.length > 0) {
      fileChosen.textContent = `${this.files.length} file(s) selected`;
    } else {
      fileChosen.textContent = 'No files selected';
    }
  });
  
  // Grading modal controls
  if (gradingModal) {
    document.getElementById('close-grading-modal').addEventListener('click', function() {
      gradingModal.style.display = 'none';
    });
    
    // Close modal when clicking outside
    gradingModal.addEventListener('click', function(e) {
      if (e.target === gradingModal) {
        gradingModal.style.display = 'none';
      }
    });
  }
  
  // ✅ FIX: Save grade button - MUST be here, not at top
  const saveGradeBtn = document.getElementById('save-grade');
  if (saveGradeBtn) {
    // Remove any old listeners
    const newBtn = saveGradeBtn.cloneNode(true);
    saveGradeBtn.parentNode.replaceChild(newBtn, saveGradeBtn);
    
    // Add fresh listener
    newBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      console.log('🖱️ Save Grade button clicked');
      saveGrade(); // Call the function defined later
    });
    
    console.log('✅ Save grade button listener attached');
  }
});

// Load classes from API
async function loadClasses() {
  try {
    const response = await fetch('/api/professor/classes');
    if (response.ok) {
      classes = await response.json();
      
      // Merge with localStorage data for assignments AND ensure students data is present
      const savedClasses = localStorage.getItem('professor_classes');
      if (savedClasses) {
        const localClasses = JSON.parse(savedClasses);
        classes = classes.map(cls => {
          const localClass = localClasses.find(lc => lc.id === cls.id || lc.code === cls.code);
          if (localClass) {
            // Merge assignments from localStorage
            if (localClass.assignments) {
              cls.assignments = localClass.assignments;
            }
            // Merge materials from localStorage
            if (localClass.materials) {
              cls.materials = localClass.materials;
            }
          }
          // Ensure students array exists (API should provide this)
          if (!cls.students) {
            cls.students = [];
          }
          return cls;
        });
      }
      
      // Save merged data back to localStorage
      localStorage.setItem('professor_classes', JSON.stringify(classes));
      
      renderClassList();
      updateDashboardStats();
      // CRITICAL FIX: Load all students after classes are loaded
      loadAllStudents();
    } else {
      console.error('Failed to load classes:', response.status);
    }
  } catch (error) {
    console.error('Error loading classes:', error);
  }
}

// Generate random class code
function generateClassCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Show create class modal
function showCreateClassModal() {
  document.getElementById('class-modal').style.display = 'flex';
  document.getElementById('class-code').value = generateClassCode();
}

// Hide create class modal
function hideCreateClassModal() {
  document.getElementById('class-modal').style.display = 'none';
  resetCreateClassForm();
}

// Reset create class form
function resetCreateClassForm() {
  document.getElementById('class-name').value = '';
  document.getElementById('class-description').value = '';
  document.getElementById('class-code').value = '';
}

// Create new class
// FIXED: Create new class - properly updates local state
// In professor-script.js - ensure this matches
async function createClass() {
  const className = document.getElementById('class-name').value.trim();
  const classDescription = document.getElementById('class-description').value.trim();
  const classCode = document.getElementById('class-code').value.trim();
  
  if (!className) {
    alert('Please enter a class name');
    return;
  }
  
  try {
    const response = await fetch('/api/professor/classes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: className,
        description: classDescription,
        code: classCode
      })
    });

    const result = await response.json();

    if (response.ok) {
      // Add the new class to the local array
      classes.push(result);
      
      // Save to localStorage
      const savedClasses = localStorage.getItem('professor_classes');
      let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
      localClasses.push(result);
      localStorage.setItem('professor_classes', JSON.stringify(localClasses));
      
      renderClassList();
      hideCreateClassModal();
      alert(`Class "${className}" created successfully! Class Code: ${classCode}`);
      updateDashboardStats();
    } else {
      alert(result.error || 'Failed to create class');
    }
  } catch (error) {
    console.error('Error creating class:', error);
    alert('Error creating class. Please try again.');
  }
}

// Render class list
function renderClassList() {
  const classList = document.getElementById('class-list');
  classList.innerHTML = '';
  
  if (classes.length === 0) {
    classList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-book-open"></i>
        <h3>No Classes Created</h3>
        <p>Create your first class to get started</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT CLASSES ALPHABETICALLY BY NAME
  const sortedClasses = [...classes].sort((a, b) => 
    a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
  );
  
  sortedClasses.forEach(classItem => {
    const classCard = document.createElement('div');
    classCard.className = 'class-card';
    const studentCount = classItem.students ? classItem.students.length : 0;
    const materialsCount = classItem.materials ? classItem.materials.length : 0;
    const assignmentsCount = classItem.assignments ? classItem.assignments.length : 0;

    classCard.innerHTML = `
      <div class="class-card-header">
        <h3>${classItem.name}</h3>
        <span class="class-code">${classItem.code}</span>
      </div>
      <p class="class-description">${classItem.description || 'No description provided'}</p>
      <div class="class-stats">
        <span><i class="fas fa-users"></i> ${studentCount} Students</span>
        <span><i class="fas fa-file-alt"></i> ${materialsCount} Materials</span>
        <span><i class="fas fa-tasks"></i> ${assignmentsCount} Assignments</span>
      </div>
      <div class="class-actions">
        <button class="btn-primary" onclick="openClass('${classItem.id}')">Open Class</button>
        <button class="btn-secondary" onclick="copyClassCode('${classItem.code}')">
          <i class="fas fa-copy"></i> Copy Code
        </button>
        <button class="btn-warning" onclick="archiveClass('${classItem.id}')">
          <i class="fas fa-archive"></i> Archive
        </button>
        <button class="btn-danger" onclick="deleteClass('${classItem.id}')">
          <i class="fas fa-trash"></i> Delete
        </button>
      </div>
    `;
    classList.appendChild(classCard);
  });
}

// ADD archive function:
// In professor-script.js - UPDATE the archiveClass function
async function archiveClass(classId) {
  if (!confirm('Are you sure you want to archive this class?')) {
    return;
  }

  try {
    const response = await fetch(`/api/professor/classes/${classId}/archive`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'}
    });

    const result = await response.json();

    if (response.ok) {
      // Remove from current view and reload both sections
      classes = classes.filter(c => c.id !== classId);
      renderClassList();
      
      // Reload archived classes if we're in that section
      const archivedSection = document.getElementById('archived-section');
      if (archivedSection && archivedSection.classList.contains('active')) {
        loadArchivedClasses();
      }
      
      alert('Class archived successfully!');
      updateDashboardStats();
    } else {
      alert(result.error || 'Failed to archive class');
    }
  } catch (error) {
    console.error('Error archiving class:', error);
    alert('Error archiving class. Please try again.');
  }
}

// ADD this function to automatically refresh both sections
function refreshClassSections() {
  loadClasses(); // Reload main classes
  loadArchivedClasses(); // Reload archived classes
}

// UPDATE loadClasses to load archived separately:
async function loadArchivedClasses() {
  try {
    const response = await fetch('/api/professor/classes?archived=true');
    if (response.ok) {
      const archivedClasses = await response.json();
      renderArchivedClassList(archivedClasses);
    }
  } catch (error) {
    console.error('Error loading archived classes:', error);
  }
}

function renderArchivedClassList(archivedClasses) {
  const archivedContent = document.querySelector('.archived-content');
  if (!archivedContent) return;
  
  archivedContent.innerHTML = '';
  
  if (archivedClasses.length === 0) {
    archivedContent.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-archive"></i>
        <h3>No Archived Classes</h3>
        <p>Classes you archive will appear here.</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT ARCHIVED CLASSES ALPHABETICALLY BY NAME
  const sortedArchivedClasses = [...archivedClasses].sort((a, b) => 
    a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
  );
  
  sortedArchivedClasses.forEach(classItem => {
    const classCard = document.createElement('div');
    classCard.className = 'class-card archived';
    classCard.innerHTML = `
      <div class="class-card-header">
        <h3>${classItem.name}</h3>
        <span class="class-code">${classItem.code}</span>
      </div>
      <p class="class-description">${classItem.description || 'No description provided'}</p>
      <div class="class-actions">
        <button class="btn-secondary" onclick="unarchiveClass('${classItem.id}')">
          <i class="fas fa-undo"></i> Restore
        </button>
        <button class="btn-danger" onclick="deleteClass('${classItem.id}')">
          <i class="fas fa-trash"></i> Delete
        </button>
      </div>
    `;
    archivedContent.appendChild(classCard);
  });
}

// UPDATE the unarchiveClass function to use refresh
async function unarchiveClass(classId) {
  await archiveClass(classId); // This toggles the status
  refreshClassSections(); // Refresh both sections
}

function loadMissedTasks() {
  const missedTasksSection = document.getElementById('missed-tasks-section');
  if (!missedTasksSection) return;
  
  const missedTasksContainer = missedTasksSection.querySelector('.missed-tasks-container') || 
    document.createElement('div');
  missedTasksContainer.className = 'missed-tasks-container';
  missedTasksContainer.innerHTML = '';
  
  let allMissedTasks = [];
  const now = new Date();
  
  // Collect all missed tasks across all classes
  classes.forEach(classItem => {
    if (!classItem.assignments || classItem.assignments.length === 0) return;
    
    classItem.assignments.forEach(assignment => {
      const dueDate = new Date(assignment.dueDate);
      
      // Only include past-due assignments
      if (dueDate >= now) return;
      
      // Get list of students who haven't submitted
      const studentsWithMissedTasks = [];
      
      if (classItem.students && classItem.students.length > 0) {
        classItem.students.forEach(student => {
          const submission = assignment.submissions ? 
            assignment.submissions.find(s => String(s.studentId) === String(student.id)) : null;
          
          if (!submission) {
            const daysOverdue = Math.floor((now - dueDate) / (1000 * 60 * 60 * 24));
            studentsWithMissedTasks.push({
              studentId: student.id,
              studentName: student.name || `${student.first_name} ${student.last_name}`,
              studentIdNumber: student.student_id || student.id,
              email: student.email || student.username,
              daysOverdue: daysOverdue
            });
          }
        });
      }
      
      if (studentsWithMissedTasks.length > 0) {
        allMissedTasks.push({
          assignmentId: assignment.id,
          assignmentTitle: assignment.title,
          className: classItem.name,
          classId: classItem.id,
          dueDate: dueDate,
          points: assignment.points,
          studentsWithMissedTasks: studentsWithMissedTasks
        });
      }
    });
  });
  
  // Sort by due date (most recent first)
  allMissedTasks.sort((a, b) => b.dueDate - a.dueDate);
  
  if (allMissedTasks.length === 0) {
    missedTasksContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-check-circle" style="color: #28a745;"></i>
        <h3>No Missed Tasks</h3>
        <p>All students have submitted their assignments on time!</p>
      </div>
    `;
  } else {
    // Summary card
    const totalMissedSubmissions = allMissedTasks.reduce((sum, task) => 
      sum + task.studentsWithMissedTasks.length, 0);
    
    missedTasksContainer.innerHTML = `
      <div class="missed-tasks-summary">
        <div class="summary-card">
          <i class="fas fa-exclamation-triangle"></i>
          <div>
            <h3>${allMissedTasks.length}</h3>
            <p>Assignments with Missed Submissions</p>
          </div>
        </div>
        <div class="summary-card">
          <i class="fas fa-users"></i>
          <div>
            <h3>${totalMissedSubmissions}</h3>
            <p>Total Missed Submissions</p>
          </div>
        </div>
      </div>
    `;
    
    // List of missed tasks
    allMissedTasks.forEach(task => {
      const daysOverdue = Math.floor((now - task.dueDate) / (1000 * 60 * 60 * 24));
      
      let severityClass = 'mild';
      let severityLabel = 'Recently Overdue';
      if (daysOverdue > 7) {
        severityClass = 'severe';
        severityLabel = 'Severely Overdue';
      } else if (daysOverdue > 3) {
        severityClass = 'warning';
        severityLabel = 'Moderately Overdue';
      }
      
      const taskCard = document.createElement('div');
      taskCard.className = `missed-task-card ${severityClass}`;
      taskCard.innerHTML = `
        <div class="missed-task-header">
          <div class="missed-task-info">
            <h4>${task.assignmentTitle}</h4>
            <p class="class-name">${task.className}</p>
          </div>
          <div class="missed-task-badge ${severityClass}">
            <i class="fas fa-clock"></i>
            ${daysOverdue} day${daysOverdue !== 1 ? 's' : ''} overdue
          </div>
        </div>
        
        <div class="missed-task-details">
          <div class="detail-item">
            <i class="fas fa-calendar-times"></i>
            <span>Due: ${task.dueDate.toLocaleDateString()} at ${task.dueDate.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-star"></i>
            <span>${task.points} Points</span>
          </div>
          <div class="detail-item">
            <i class="fas fa-user-times"></i>
            <span>${task.studentsWithMissedTasks.length} Student${task.studentsWithMissedTasks.length !== 1 ? 's' : ''} Haven't Submitted</span>
          </div>
        </div>
        
        <div class="missed-students-section">
          <h5><i class="fas fa-users"></i> Students Who Missed This Assignment:</h5>
          <div class="missed-students-list">
            ${task.studentsWithMissedTasks.map(student => `
              <div class="missed-student-item">
                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(student.studentName)}&background=dc3545&color=fff" 
                     alt="${student.studentName}" class="student-avatar">
                <div class="student-info">
                  <strong>${student.studentName}</strong>
                  <span>${student.studentIdNumber}</span>
                  <span class="overdue-label">${student.daysOverdue} day${student.daysOverdue !== 1 ? 's' : ''} late</span>
                </div>
                <button class="btn-outline btn-small" onclick="contactStudent('${student.email}', '${student.studentName}', '${task.assignmentTitle}')" title="Send reminder email">
                  <i class="fas fa-envelope"></i> Contact
                </button>
              </div>
            `).join('')}
          </div>
        </div>
        
        <div class="missed-task-actions">
          <button class="btn-secondary" onclick="openClass('${task.classId}'); setTimeout(() => switchTab('assignments'), 300);">
            <i class="fas fa-eye"></i> View Assignment
          </button>
          <button class="btn-primary" onclick="extendDeadline('${task.assignmentId}', '${task.classId}')">
            <i class="fas fa-calendar-plus"></i> Extend Deadline
          </button>
        </div>
      `;
      
      missedTasksContainer.appendChild(taskCard);
    });
  }
  
  if (!missedTasksSection.contains(missedTasksContainer)) {
    missedTasksSection.appendChild(missedTasksContainer);
  }
}

const missedTasksStyles = `
<style>
.missed-tasks-summary {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.summary-card {
  background: white;
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  display: flex;
  align-items: center;
  gap: 1rem;
}

.summary-card i {
  font-size: 2.5rem;
  color: #ffc107;
}

.summary-card h3 {
  margin: 0;
  font-size: 2rem;
  color: #333;
}

.summary-card p {
  margin: 0;
  color: #666;
  font-size: 0.9rem;
}

.missed-task-card {
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  border-left: 4px solid #ffc107;
}

.missed-task-card.warning {
  border-left-color: #fd7e14;
}

.missed-task-card.severe {
  border-left-color: #dc3545;
  background: #fff5f5;
}

.missed-task-header {
  display: flex;
  justify-content: space-between;
  align-items: start;
  margin-bottom: 1rem;
  gap: 1rem;
  flex-wrap: wrap;
}

.missed-task-info h4 {
  margin: 0 0 0.25rem 0;
  font-size: 1.2rem;
  color: #333;
}

.missed-task-info .class-name {
  color: #666;
  font-size: 0.9rem;
}

.missed-task-badge {
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-weight: 600;
  font-size: 0.9rem;
  white-space: nowrap;
}

.missed-task-badge.mild {
  background: #fff3cd;
  color: #856404;
}

.missed-task-badge.warning {
  background: #ffe5cc;
  color: #8b4513;
}

.missed-task-badge.severe {
  background: #f8d7da;
  color: #721c24;
}

.missed-task-details {
  display: flex;
  gap: 2rem;
  margin: 1rem 0;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
  flex-wrap: wrap;
}

.detail-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #666;
  font-size: 0.9rem;
}

.detail-item i {
  color: #4a90a4;
}

.missed-students-section {
  margin: 1.5rem 0;
  padding: 1.5rem;
  background: #f8f9fa;
  border-radius: 8px;
}

.missed-students-section h5 {
  margin: 0 0 1rem 0;
  color: #333;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.missed-students-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.missed-student-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
}

.student-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  flex-shrink: 0;
}

.missed-student-item .student-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.missed-student-item .student-info strong {
  color: #333;
  font-size: 0.95rem;
}

.missed-student-item .student-info span {
  color: #666;
  font-size: 0.85rem;
}

.overdue-label {
  color: #dc3545 !important;
  font-weight: 600 !important;
}

.missed-task-actions {
  display: flex;
  gap: 1rem;
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 2px solid #e0e0e0;
  flex-wrap: wrap;
}

.missed-task-actions button {
  flex: 1;
  min-width: 180px;
}
</style>
`;

// Inject styles (only once)
if (!document.getElementById('missed-tasks-styles')) {
  const styleElement = document.createElement('div');
  styleElement.id = 'missed-tasks-styles';
  styleElement.innerHTML = missedTasksStyles;
  document.head.appendChild(styleElement);
}

function contactStudent(email, studentName, assignmentTitle) {
  const subject = encodeURIComponent(`Reminder: Missing Assignment - ${assignmentTitle}`);
  const body = encodeURIComponent(`Dear ${studentName},

This is a friendly reminder that you have not yet submitted the assignment "${assignmentTitle}".

Please submit your work as soon as possible or contact me if you need assistance or an extension.

Best regards`);
  
  window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
}

// Extend deadline for an assignment
function extendDeadline(assignmentId, classId) {
  const classItem = classes.find(c => c.id === classId);
  if (!classItem) {
    alert('Class not found');
    return;
  }
  
  const assignment = classItem.assignments ? 
    classItem.assignments.find(a => a.id === assignmentId) : null;
  
  if (!assignment) {
    alert('Assignment not found');
    return;
  }
  
  const currentDueDate = new Date(assignment.dueDate);
  const newDate = prompt(
    `Current deadline: ${currentDueDate.toLocaleString()}\n\nEnter new deadline (YYYY-MM-DD HH:MM):`,
    currentDueDate.toISOString().slice(0, 16).replace('T', ' ')
  );
  
  if (!newDate) return;
  
  try {
    const updatedDueDate = new Date(newDate);
    
    if (isNaN(updatedDueDate.getTime())) {
      alert('Invalid date format');
      return;
    }
    
    if (updatedDueDate <= new Date()) {
      alert('New deadline must be in the future');
      return;
    }
    
    assignment.dueDate = updatedDueDate.toISOString();
    
    // Update in localStorage
    const savedClasses = localStorage.getItem('professor_classes');
    let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
    const localClassIndex = localClasses.findIndex(c => c.id === classId || c.code === classItem.code);
    
    if (localClassIndex !== -1) {
      const localAssignmentIndex = localClasses[localClassIndex].assignments.findIndex(a => a.id === assignmentId);
      if (localAssignmentIndex !== -1) {
        localClasses[localClassIndex].assignments[localAssignmentIndex].dueDate = assignment.dueDate;
        localStorage.setItem('professor_classes', JSON.stringify(localClasses));
      }
    }
    
    // Add notification
    addNotification(
      'deadline',
      'Deadline Extended',
      `Deadline for "${assignment.title}" extended to ${updatedDueDate.toLocaleString()}`,
      `class:${classId}`
    );
    
    alert(`✅ Deadline extended successfully!\n\nNew deadline: ${updatedDueDate.toLocaleString()}`);
    
    // Refresh views
    loadMissedTasks();
    if (currentClassId === classId) {
      loadClassAssignments();
    }
    
  } catch (error) {
    console.error('Error extending deadline:', error);
    alert('Failed to extend deadline: ' + error.message);
  }
}

// UPDATE showSection to load archived when viewing that section:
function showSection(sectionId, element = null) {
  contentSections.forEach(section => {
    section.classList.remove('active');
  });
  
  const classView = document.getElementById('class-view');
  if (classView) {
    classView.classList.add('hidden');
    classView.classList.remove('active');
  }

  if (element) {
    navLinks.forEach(link => {
      link.classList.remove('active');
    });
    element.classList.add('active');
  }

  if (sectionId !== 'class-view') {
    const section = document.getElementById(sectionId);
    if (section) {
      section.classList.add('active');
      
      if (sectionId === 'students-section') {
        setTimeout(loadAllStudents, 50);
      } else if (sectionId === 'archived-section') {
        setTimeout(loadArchivedClasses, 50);
      }
    }
  }
}

const originalShowSection = showSection;
showSection = function(sectionId, element = null) {
  originalShowSection(sectionId, element);
  
  if (sectionId === 'missed-tasks-section') {
    setTimeout(loadMissedTasks, 50);
  }
};

// Delete class
async function deleteClass(classId) {
  if (!confirm('Are you sure you want to delete this class? This action cannot be undone.')) {
    return;
  }

  try {
    const response = await fetch(`/api/professor/classes`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ class_id: classId })
    });

    const result = await response.json();

    if (response.ok) {
      // Remove the class from the local array
      classes = classes.filter(c => c.id !== classId);
      renderClassList();
      alert('Class deleted successfully!');
      updateDashboardStats(); // Update dashboard after class deletion
    } else {
      alert(result.error || 'Failed to delete class');
    }
  } catch (error) {
    console.error('Error deleting class:', error);
    alert('Error deleting class. Please try again.');
  }
}

// Copy class code to clipboard
function copyClassCode(code) {
  navigator.clipboard.writeText(code).then(() => {
    alert('Class code copied to clipboard!');
  });
}

// Open class view
function openClass(classId) {
  currentClassId = classId;
  const classItem = classes.find(c => c.id === classId);
  
  if (!classItem) return;
  
  // ✅ RECALCULATE ALL STATS BEFORE DISPLAY
  const studentsCount = classItem.students ? classItem.students.length : 0;
  const materialsCount = classItem.materials ? classItem.materials.length : 0;
  const assignmentsCount = classItem.assignments ? classItem.assignments.length : 0;

  // Update class view header
  document.getElementById('class-title').textContent = classItem.name;
  document.getElementById('class-desc').textContent = classItem.description || 'No description provided';
  
  // ✅ UPDATE STATS COUNTERS
  document.getElementById('class-students').textContent = studentsCount;
  document.getElementById('class-materials').textContent = materialsCount;
  document.getElementById('class-assignments').textContent = assignmentsCount;
  
  // Hide enrolled section and show class view
  document.getElementById('enrolled-section').classList.remove('active');
  document.getElementById('class-view').classList.remove('hidden');
  document.getElementById('class-view').classList.add('active');
  
  // Load class content
  loadClassPosts();
  loadClassStudents();
  loadClassAssignments();
  loadClassGrades();
  
  // ✅ FORCE STATS UPDATE AFTER CONTENT LOADS
  setTimeout(() => {
    const updatedMaterialsCount = classItem.materials ? classItem.materials.length : 0;
    const updatedAssignmentsCount = classItem.assignments ? classItem.assignments.length : 0;
    
    document.getElementById('class-materials').textContent = updatedMaterialsCount;
    document.getElementById('class-assignments').textContent = updatedAssignmentsCount;
  }, 100);
}


// Switch tabs in class view
function switchTab(tabName) {
  // Hide all tab contents
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  
  // Remove active class from all tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  
  // Show selected tab content and activate button
  document.getElementById(`${tabName}-tab`).classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
}

// DELETE ASSIGNMENT FUNCTION
// REPLACE deleteAssignment function
async function deleteAssignment(assignmentId) {
  if (!confirm('Are you sure you want to delete this assignment? This will also delete all student submissions.')) {
    return;
  }
  
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  // Remove assignment from classItem
  classItem.assignments = classItem.assignments.filter(a => a.id !== assignmentId);
  
  // Update classes array
  const classIndex = classes.findIndex(c => c.id === currentClassId);
  if (classIndex !== -1) {
    classes[classIndex] = classItem;
  }
  
  // Save to localStorage
  const savedClasses = localStorage.getItem('professor_classes');
  let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
  const localClassIndex = localClasses.findIndex(c => c.id === currentClassId || c.code === classItem.code);
  
  if (localClassIndex !== -1) {
    localClasses[localClassIndex].assignments = classItem.assignments;
    localStorage.setItem('professor_classes', JSON.stringify(localClasses));
  }
  
  // ✅ FIX: Force immediate UI update
  loadClassAssignments();
  
  // ✅ FIX: Update stats immediately
  document.getElementById('class-assignments').textContent = classItem.assignments.length;
  updateDashboardStats();
  
  alert('Assignment deleted successfully!');
}

// DELETE MATERIAL/POST FUNCTION
async function deleteMaterial(materialId) {
  if (!confirm('Are you sure you want to delete this material?')) {
    return;
  }
  
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  classItem.materials = classItem.materials.filter(m => m.id !== materialId);
  
  const classIndex = classes.findIndex(c => c.id === currentClassId);
  if (classIndex !== -1) {
    classes[classIndex] = classItem;
  }
  
  const savedClasses = localStorage.getItem('professor_classes');
  let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
  const localClassIndex = localClasses.findIndex(c => c.id === currentClassId || c.code === classItem.code);
  
  if (localClassIndex !== -1) {
    localClasses[localClassIndex].materials = classItem.materials;
    localStorage.setItem('professor_classes', JSON.stringify(localClasses));
  }
  
  loadClassPosts();
  
  // ✅ UPDATE STATS IMMEDIATELY
  document.getElementById('class-materials').textContent = classItem.materials.length;
  updateDashboardStats();
  
  alert('Material deleted successfully!');
}

async function deleteAssignment(assignmentId) {
  if (!confirm('Are you sure you want to delete this assignment? This will also delete all student submissions.')) {
    return;
  }
  
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  classItem.assignments = classItem.assignments.filter(a => a.id !== assignmentId);
  
  const classIndex = classes.findIndex(c => c.id === currentClassId);
  if (classIndex !== -1) {
    classes[classIndex] = classItem;
  }
  
  const savedClasses = localStorage.getItem('professor_classes');
  let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
  const localClassIndex = localClasses.findIndex(c => c.id === currentClassId || c.code === classItem.code);
  
  if (localClassIndex !== -1) {
    localClasses[localClassIndex].assignments = classItem.assignments;
    localStorage.setItem('professor_classes', JSON.stringify(localClasses));
  }
  
  loadClassAssignments();
  
  // ✅ UPDATE STATS IMMEDIATELY
  document.getElementById('class-assignments').textContent = classItem.assignments.length;
  updateDashboardStats();
  
  alert('Assignment deleted successfully!');
}

// Load class posts/materials
function loadClassPosts() {
  const classItem = classes.find(c => c.id === currentClassId);
  const postsContainer = document.getElementById('posts-container');
  
  if (!classItem || !postsContainer) return;
  
  postsContainer.innerHTML = '';
  
  if (!classItem.materials || classItem.materials.length === 0) {
    postsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-file-upload"></i>
        <h3>No Materials Posted</h3>
        <p>Upload your first material to get started</p>
      </div>
    `;
    return;
  }
  
  const sortedMaterials = classItem.materials.sort((a, b) => new Date(b.date) - new Date(a.date));

  sortedMaterials.forEach(material => {
    const postElement = document.createElement('div');
    postElement.className = 'post-card';
    postElement.innerHTML = `
      <div class="post-header">
        <h4>${material.title}</h4>
        <div style="display: flex; align-items: center; gap: 1rem;">
          <span class="post-date">${new Date(material.date).toLocaleDateString()}</span>
          <button class="btn-danger btn-small" onclick="deleteMaterial('${material.id}')" title="Delete material">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <p class="post-description">${material.description}</p>
      ${material.deadline ? `<p class="post-deadline"><strong>Deadline:</strong> ${new Date(material.deadline).toLocaleDateString()}</p>` : ''}
      ${material.resourceLink ? `<p class="post-link"><a href="${material.resourceLink}" target="_blank">${material.resourceLink}</a></p>` : ''}
      ${material.files && material.files.length > 0 ? `
        <div class="post-files">
          <strong>Attached Files:</strong>
          <ul>
            ${material.files.map(file => `
              <li>
                <a href="#" onclick="downloadFile('${file.name.replace(/'/g, "\\'")}', '${file.url || file.content}'); return false;">
                  <i class="fas fa-download"></i> ${file.name} (${(file.size / 1024 / 1024).toFixed(2)}MB)
                </a>
              </li>
            `).join('')}
          </ul>
        </div>
      ` : ''}
    `;
    postsContainer.appendChild(postElement);
  });
}

function loadClassAssignments() {
  const classItem = classes.find(c => c.id === currentClassId);
  const assignmentsContainer = document.getElementById('assignments-container');
  
  if (!classItem || !assignmentsContainer) return;
  
  assignmentsContainer.innerHTML = '';
  
  if (!classItem.assignments || classItem.assignments.length === 0) {
    assignmentsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No Assignments</h3>
        <p>Create your first assignment to get started</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT BY CREATION DATE (NEWEST FIRST)
  const sortedAssignments = [...classItem.assignments].sort((a, b) => {
    const dateA = new Date(a.dateCreated || a.dueDate);
    const dateB = new Date(b.dateCreated || b.dueDate);
    return dateB - dateA; // Descending order (newest first)
  });

  sortedAssignments.forEach(assignment => {
    const submissionCount = assignment.submissions ? assignment.submissions.length : 0;
    const gradedCount = assignment.submissions ? assignment.submissions.filter(s => s.grade !== undefined).length : 0;
    
    const assignmentElement = document.createElement('div');
    assignmentElement.className = 'assignment-card';
    assignmentElement.innerHTML = `
      <div class="assignment-header">
        <h4>${assignment.title}</h4>
        <div style="display: flex; align-items: center; gap: 1rem;">
          <span class="due-date">Due: ${new Date(assignment.dueDate).toLocaleDateString()}</span>
          <button class="btn-danger btn-small" onclick="deleteAssignment('${assignment.id}')" title="Delete assignment">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <p class="assignment-description">${assignment.description}</p>
      <div class="assignment-details">
        <span><i class="fas fa-file-alt"></i> ${assignment.points} Points</span>
        <span><i class="fas fa-users"></i> ${submissionCount} Submissions</span>
        <span><i class="fas fa-check-circle"></i> ${gradedCount} Graded</span>
      </div>
      ${assignment.files && assignment.files.length > 0 ? `
        <div class="assignment-files">
          <strong>Resources:</strong>
          <ul>
            ${assignment.files.map(file => {
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <li>
                  <a href="#" onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;">
                    <i class="fas ${file.type && file.type.startsWith('video/') ? 'fa-play-circle' : 'fa-download'}"></i> ${file.name}
                  </a>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      ` : ''}
      <div class="assignment-actions">
        <button class="btn-primary" onclick="viewSubmissions('${assignment.id}')">
          <i class="fas fa-eye"></i> View Submissions
        </button>
      </div>
    `;
    assignmentsContainer.appendChild(assignmentElement);
  });
}

// professor-script.js - Replace uploadMaterial function

async function uploadMaterial() {
  const title = document.getElementById('upload-title').value.trim();
  const description = document.getElementById('upload-description').value.trim();
  const deadline = document.getElementById('upload-deadline').value;
  const resourceLink = document.getElementById('resource-link').value.trim();
  const filesInput = document.getElementById('lesson-file');
  
  if (!title) {
    alert('Please enter a title');
    return;
  }
  
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) {
    alert('Error: Class not found.');
    return;
  }
  
  const material = {
    id: Date.now().toString(),
    title,
    description,
    date: new Date().toISOString(),
    deadline: deadline || null,
    resourceLink: resourceLink || null,
    files: []
  };
  
  // ✅ NEW: Upload files to server instead of localStorage
  if (filesInput.files.length > 0) {
    try {
      const postBtn = document.getElementById('post-upload');
      const originalText = postBtn.innerHTML;
      postBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
      postBtn.disabled = true;
      
      // Upload each file to server
      for (const file of filesInput.files) {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('/api/upload_file', {
          method: 'POST',
          body: formData
        });
        
        if (!response.ok) {
          throw new Error(`Failed to upload ${file.name}`);
        }
        
        const result = await response.json();
        
        // Store file reference (not the actual data)
        material.files.push({
          name: file.name,
          type: file.type,
          size: file.size,
          url: result.url,
          file_id: result.file_id
        });
      }
      
      postBtn.innerHTML = originalText;
      postBtn.disabled = false;
      
      await saveMaterial(material);
      
    } catch (error) {
      console.error('Error uploading files:', error);
      alert('Error uploading files: ' + error.message);
      const postBtn = document.getElementById('post-upload');
      postBtn.innerHTML = 'Post Material';
      postBtn.disabled = false;
    }
  } else {
    await saveMaterial(material);
  }
}

// ✅ ADD THIS HELPER IF NOT EXISTS (same as student)
function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target.result);
    reader.onerror = (e) => reject(e);
    reader.readAsDataURL(file);
  });
}

// FIXED: Save material to ensure student access
async function saveMaterial(material) {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  if (!classItem.materials) {
    classItem.materials = [];
  }
  
  classItem.materials.push(material);
  
  const savedClasses = localStorage.getItem('professor_classes');
  let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
  
  const classIndex = localClasses.findIndex(c => c.id === currentClassId || c.code === classItem.code);
  if (classIndex !== -1) {
    if (!localClasses[classIndex].materials) {
      localClasses[classIndex].materials = [];
    }
    localClasses[classIndex].materials.push(material);
  } else {
    localClasses.push({
      ...classItem,
      materials: [material]
    });
  }
  
  localStorage.setItem('professor_classes', JSON.stringify(localClasses));
  
  loadClassPosts();
  
  // ✅ UPDATE STATS IMMEDIATELY
  document.getElementById('class-materials').textContent = classItem.materials.length;
  updateDashboardStats();

  document.getElementById('upload-form').classList.add('hidden');
  resetUploadForm();
  
  alert('Material posted successfully! Students can now see this material.');
}

// Reset upload form
function resetUploadForm() {
  document.getElementById('upload-title').value = '';
  document.getElementById('upload-description').value = '';
  document.getElementById('upload-deadline').value = '';
  document.getElementById('resource-link').value = '';
  document.getElementById('lesson-file').value = '';
  document.getElementById('file-chosen').textContent = 'No files selected';
}

// Load class students
function loadClassStudents() {
  const classItem = classes.find(c => c.id === currentClassId);
  const studentsList = document.getElementById('students-list');
  
  if (!classItem || !studentsList) return;
  
  studentsList.innerHTML = '';
  
  if (!classItem.students || classItem.students.length === 0) {
    studentsList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-users"></i>
        <h3>No Students Enrolled</h3>
        <p>Students can join using the class code: <strong>${classItem.code}</strong></p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT STUDENTS ALPHABETICALLY BY NAME
  const sortedStudents = [...classItem.students].sort((a, b) => {
    const nameA = (a.name || `${a.first_name || ''} ${a.last_name || ''}`.trim()).toLowerCase();
    const nameB = (b.name || `${b.first_name || ''} ${b.last_name || ''}`.trim()).toLowerCase();
    return nameA.localeCompare(nameB);
  });
  
  sortedStudents.forEach(student => {
    const studentDatabaseId = String(student.id);
    const studentDisplayId = student.student_id || student.id;
    
    // Calculate assignment stats for this student
    let completedAssignments = 0;
    let totalGrade = 0;
    let gradedAssignments = 0;
    
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        if (assignment.submissions) {
          const submission = assignment.submissions.find(s => 
            String(s.studentId) === studentDatabaseId
          );
          if (submission) {
            completedAssignments++;
            if (submission.grade !== undefined) {
              totalGrade += (submission.grade / assignment.points) * 100;
              gradedAssignments++;
            }
          }
        }
      });
    }
    
    const averageGrade = gradedAssignments > 0 ? 
      (totalGrade / gradedAssignments).toFixed(2) : 'N/A';
    const studentName = student.name || 
      `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
    const studentEmail = student.email || student.username || 'N/A';
    
    const studentElement = document.createElement('div');
    studentElement.className = 'student-item';
    studentElement.innerHTML = `
      <div class="student-info">
        <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(studentName)}&background=4a90a4&color=fff" 
             alt="${studentName}" class="avatar">
        <div>
          <h4>${studentName}</h4>
          <p>${studentDisplayId} • ${studentEmail}</p>
        </div>
      </div>
      <div class="student-stats">
        <span>Assignments: ${completedAssignments}/${classItem.assignments ? classItem.assignments.length : 0}</span>
        <span>Average: ${averageGrade}${averageGrade !== 'N/A' ? '%' : ''}</span>
      </div>
      <div class="student-actions" style="display: flex; gap: 0.5rem;">
        <button class="btn-secondary btn-small" 
                onclick="viewStudentDetails('${studentDatabaseId}')"
                title="View student details">
          <i class="fas fa-eye"></i> View
        </button>
        <button class="btn-danger btn-small" 
                onclick="removeStudentFromClass('${studentDatabaseId}', '${studentName}')"
                title="Remove student from class">
          <i class="fas fa-user-minus"></i> Remove
        </button>
      </div>
    `;
    studentsList.appendChild(studentElement);
  });
}


// ✅ FIX #4: NEW FUNCTION - Remove student from class
async function removeStudentFromClass(studentId, studentName) {
  if (!confirm(`Are you sure you want to remove ${studentName} from this class?\n\nThis will:\n• Remove the student from the class roster\n• Keep their submissions (for records)\n• Prevent them from accessing class materials`)) {
    return;
  }
  
  try {
    const classItem = classes.find(c => c.id === currentClassId);
    if (!classItem) {
      alert('Error: Class not found');
      return;
    }
    
    // Call backend API to remove student
    const response = await fetch('/api/professor/remove_student', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        class_id: currentClassId,
        student_id: studentId
      })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      // Remove from local array
      classItem.students = classItem.students.filter(s => 
        String(s.id) !== String(studentId)
      );
      
      // Update classes array
      const classIndex = classes.findIndex(c => c.id === currentClassId);
      if (classIndex !== -1) {
        classes[classIndex].students = classItem.students;
      }
      
      // Update localStorage
      const savedClasses = localStorage.getItem('professor_classes');
      let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
      const localClassIndex = localClasses.findIndex(c => 
        c.id === currentClassId || c.code === classItem.code
      );
      
      if (localClassIndex !== -1) {
        localClasses[localClassIndex].students = classItem.students;
        localStorage.setItem('professor_classes', JSON.stringify(localClasses));
      }
      
      // Refresh UI
      loadClassStudents();
      document.getElementById('class-students').textContent = classItem.students.length;
      updateDashboardStats();
      loadAllStudents(); // Refresh the Students section
      
      // Create notification
      addNotification(
        'enrollment',
        'Student Removed',
        `${studentName} has been removed from ${classItem.name}`,
        `class:${currentClassId}`
      );
      
      alert(`✅ ${studentName} has been successfully removed from the class.`);
      
    } else {
      alert(result.error || 'Failed to remove student');
    }
  } catch (error) {
    console.error('Error removing student:', error);
    alert('Error removing student. Please try again.');
  }
}

// ✅ FIX #4: NEW FUNCTION - View student details
function viewStudentDetails(studentId) {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const student = classItem.students.find(s => String(s.id) === String(studentId));
  if (!student) {
    alert('Student not found');
    return;
  }
  
  const studentName = student.name || 
    `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
  
  // Create modal for student details
  const existingModal = document.getElementById('student-details-modal');
  if (existingModal) {
    existingModal.remove();
  }
  
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.style.display = 'flex';
  modal.id = 'student-details-modal';
  
  // Collect student's submissions
  let submissionsHTML = '';
  if (classItem.assignments) {
    classItem.assignments.forEach(assignment => {
      const submission = assignment.submissions ? 
        assignment.submissions.find(s => String(s.studentId) === String(studentId)) : null;
      
      if (submission) {
        const isGraded = submission.grade !== undefined;
        submissionsHTML += `
          <div style="padding: 1rem; border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 1rem;">
            <h4 style="margin: 0 0 0.5rem 0;">${assignment.title}</h4>
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span>
                <i class="fas fa-calendar"></i> 
                Submitted: ${new Date(submission.date).toLocaleDateString()}
              </span>
              ${isGraded ? `
                <span style="background: #28a745; color: white; padding: 0.5rem 1rem; border-radius: 6px; font-weight: 600;">
                  Grade: ${submission.grade}/${assignment.points}
                </span>
              ` : `
                <span style="background: #ffc107; color: #333; padding: 0.5rem 1rem; border-radius: 6px; font-weight: 600;">
                  Not Graded
                </span>
              `}
            </div>
          </div>
        `;
      }
    });
  }
  
  if (!submissionsHTML) {
    submissionsHTML = '<p style="color: #666; text-align: center; padding: 2rem;">No submissions yet</p>';
  }
  
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 700px;">
      <div class="modal-header">
        <h3><i class="fas fa-user"></i> Student Details</h3>
        <button class="close-btn" onclick="closeStudentDetailsModal()">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body" style="padding: 2rem;">
        <div style="display: flex; align-items: center; gap: 1.5rem; margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 2px solid #e0e0e0;">
          <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(studentName)}&background=4a90a4&color=fff&size=80" 
               alt="${studentName}" 
               style="width: 80px; height: 80px; border-radius: 50%;">
          <div>
            <h3 style="margin: 0 0 0.5rem 0;">${studentName}</h3>
            <p style="margin: 0; color: #666;">
              <i class="fas fa-id-card"></i> ${student.student_id || student.id}
            </p>
            <p style="margin: 0.25rem 0; color: #666;">
              <i class="fas fa-envelope"></i> ${student.email || student.username || 'N/A'}
            </p>
          </div>
        </div>
        
        <h4 style="margin-bottom: 1rem;">
          <i class="fas fa-clipboard-list"></i> Submissions
        </h4>
        ${submissionsHTML}
      </div>
      <div class="modal-footer">
        <button class="btn-danger" onclick="removeStudentFromClass('${studentId}', '${studentName}'); closeStudentDetailsModal();">
          <i class="fas fa-user-minus"></i> Remove Student
        </button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeStudentDetailsModal();
    }
  });
}

function closeStudentDetailsModal() {
  const modal = document.getElementById('student-details-modal');
  if (modal) {
    modal.remove();
  }
}

// Save assignment
async function saveAssignment() {
  const title = document.getElementById('assignment-title').value.trim();
  const description = document.getElementById('assignment-description').value.trim();
  const dueDate = document.getElementById('assignment-due-date').value;
  const points = document.getElementById('assignment-points').value;
  const instructions = document.getElementById('assignment-instructions').value.trim();
  const filesInput = document.getElementById('assignment-files');
  
  if (!title || !description || !dueDate) {
    alert('Please fill in all required fields');
    return;
  }
  
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) {
    alert('Error: Class not found.');
    return;
  }
  
  const assignment = {
    id: Date.now().toString(),
    title,
    description,
    dueDate,
    points: parseInt(points) || 100,
    instructions: instructions || '',
    dateCreated: new Date().toISOString(),
    submissions: [],
    files: []
  };
  
  // âœ… FIX: Upload ALL files before saving
  if (filesInput && filesInput.files && filesInput.files.length > 0) {
    try {
      const saveBtn = document.getElementById('save-assignment');
      const originalText = saveBtn.innerHTML;
      saveBtn.disabled = true;
      
      // âœ… UPLOAD ALL FILES IN PARALLEL (faster)
      const uploadPromises = Array.from(filesInput.files).map(async (file, index) => {
        console.log(`Uploading file ${index + 1}/${filesInput.files.length}: ${file.name}`);
        
        saveBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Uploading ${index + 1}/${filesInput.files.length}...`;
        
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('/api/upload_file', {
          method: 'POST',
          body: formData
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Failed to upload ${file.name}`);
        }
        
        const result = await response.json();
        
        return {
          name: file.name,
          type: file.type,
          size: file.size,
          url: result.url
        };
      });
      
      // âœ… WAIT FOR ALL UPLOADS TO COMPLETE
      assignment.files = await Promise.all(uploadPromises);
      
      saveBtn.innerHTML = originalText;
      saveBtn.disabled = false;
      
      console.log(`âœ… All ${assignment.files.length} files uploaded successfully`);
      
      await saveAssignmentToClass(assignment);
      
    } catch (uploadError) {
      console.error('âŒ Error during file upload:', uploadError);
      alert('âŒ Error uploading files: ' + uploadError.message);
      const saveBtn = document.getElementById('save-assignment');
      saveBtn.innerHTML = 'Create Assignment';
      saveBtn.disabled = false;
      return;
    }
  } else {
    await saveAssignmentToClass(assignment);
  }
}

// Save assignment to class
async function saveAssignmentToClass(assignment) {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const dueDate = new Date(assignment.dueDate);
  
  const confirmModal = document.createElement('div');
  confirmModal.className = 'modal';
  confirmModal.style.display = 'flex';
  confirmModal.style.zIndex = '10001';
  confirmModal.id = 'calendar-confirm-modal';
  
  confirmModal.innerHTML = `
    <div class="modal-content" style="max-width: 500px;">
      <div class="modal-header">
        <h3><i class="fas fa-calendar-check"></i> Confirm Assignment</h3>
      </div>
      <div class="modal-body">
        <div style="text-align: center; padding: 1rem;">
          <i class="fas fa-calendar-check" style="font-size: 3rem; color: #4a90a4; margin-bottom: 1rem;"></i>
          <h3 style="margin-bottom: 1rem;">Confirm Assignment Schedule</h3>
          <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; text-align: left;">
            <p style="margin-bottom: 0.5rem;"><strong>Assignment:</strong> ${assignment.title}</p>
            <p style="margin-bottom: 0.5rem;"><strong>Class:</strong> ${classItem.name}</p>
            <p style="margin-bottom: 0.5rem;"><strong>Due Date:</strong> ${dueDate.toLocaleString()}</p>
            <p style="margin-bottom: 0;"><strong>Points:</strong> ${assignment.points}</p>
          </div>
          <p style="color: #666; font-size: 0.9rem;">This assignment will be visible to all students and added to the calendar.</p>
        </div>
      </div>
      <div class="modal-footer" style="display: flex; gap: 1rem; justify-content: center;">
        <button id="cancel-calendar-confirm" class="btn-secondary" style="min-width: 120px;">
          <i class="fas fa-times"></i> Cancel
        </button>
        <button id="confirm-calendar-ok" class="btn-primary" style="min-width: 120px;">
          <i class="fas fa-check"></i> OK, Create Assignment
        </button>
      </div>
    </div>
  `;
  
  document.body.appendChild(confirmModal);
  
  return new Promise((resolve, reject) => {
    document.getElementById('confirm-calendar-ok').addEventListener('click', async function() {
      confirmModal.remove();
      
      try {
        if (!classItem.assignments) {
          classItem.assignments = [];
        }
        
        classItem.assignments.push(assignment);
        
        localStorage.setItem('professor_classes', JSON.stringify(classes));
        
        const dateKey = `${dueDate.getFullYear()}-${dueDate.getMonth() + 1}-${dueDate.getDate()}`;
        if (!calendarEvents[dateKey]) {
          calendarEvents[dateKey] = [];
        }
        calendarEvents[dateKey].push(`Assignment Due: ${assignment.title} (${classItem.name})`);
        localStorage.setItem('calendar_events', JSON.stringify(calendarEvents));
        
        loadClassAssignments();
        
        // ✅ UPDATE STATS IMMEDIATELY
        document.getElementById('class-assignments').textContent = classItem.assignments.length;
        updateDashboardStats();
        
        if (typeof initializeCalendar === 'function') {
          initializeCalendar();
        }
        
        assignmentModal.style.display = 'none';
        resetAssignmentForm();
        
        alert('✅ Assignment created successfully and added to calendar!');
        
        addNotification(
          'assignment',
          'New Assignment Created',
          `"${assignment.title}" has been posted to ${classItem.name}`,
          `class:${currentClassId}`
        );
        
        resolve();
      } catch (error) {
        reject(error);
      }
    });
    
    document.getElementById('cancel-calendar-confirm').addEventListener('click', function() {
      confirmModal.remove();
      reject(new Error('Assignment creation cancelled'));
    });
    
    confirmModal.addEventListener('click', function(e) {
      if (e.target === confirmModal) {
        confirmModal.remove();
        reject(new Error('Assignment creation cancelled'));
      }
    });
  });
}

// REPLACE the resetAssignmentForm function (around line 681)
function resetAssignmentForm() {
  document.getElementById('assignment-title').value = '';
  document.getElementById('assignment-description').value = '';
  document.getElementById('assignment-due-date').value = '';
  document.getElementById('assignment-points').value = '100';
  document.getElementById('assignment-instructions').value = '';
  document.getElementById('assignment-files').value = '';
  document.getElementById('assignment-files-chosen').textContent = 'No files selected';
  
  // ✅ FIX: Clear the modal dataset to prevent conflicts
  const modal = document.getElementById('assignment-modal');
  if (modal) {
    delete modal.dataset.assignmentId;
    delete modal.dataset.classId;
  }
}

// Load class assignments
function loadClassAssignments() {
  const classItem = classes.find(c => c.id === currentClassId);
  const assignmentsContainer = document.getElementById('assignments-container');
  
  if (!classItem || !assignmentsContainer) return;
  
  assignmentsContainer.innerHTML = '';
  
  if (!classItem.assignments || classItem.assignments.length === 0) {
    assignmentsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No Assignments</h3>
        <p>Create your first assignment to get started</p>
      </div>
    `;
    return;
  }
  
  const sortedAssignments = classItem.assignments.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

  sortedAssignments.forEach(assignment => {
    const submissionCount = assignment.submissions ? assignment.submissions.length : 0;
    const gradedCount = assignment.submissions ? assignment.submissions.filter(s => s.grade !== undefined).length : 0;
    
    const assignmentElement = document.createElement('div');
    assignmentElement.className = 'assignment-card';
    assignmentElement.innerHTML = `
      <div class="assignment-header">
        <h4>${assignment.title}</h4>
        <div style="display: flex; align-items: center; gap: 1rem;">
          <span class="due-date">Due: ${new Date(assignment.dueDate).toLocaleDateString()}</span>
          <button class="btn-danger btn-small" onclick="deleteAssignment('${assignment.id}')" title="Delete assignment">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <p class="assignment-description">${assignment.description}</p>
      <div class="assignment-details">
        <span><i class="fas fa-file-alt"></i> ${assignment.points} Points</span>
        <span><i class="fas fa-users"></i> ${submissionCount} Submissions</span>
        <span><i class="fas fa-check-circle"></i> ${gradedCount} Graded</span>
      </div>
      ${assignment.files && assignment.files.length > 0 ? `
        <div class="assignment-files">
          <strong>Resources:</strong>
          <ul>
            ${assignment.files.map(file => {
              // ✅ FIX: Handle both URL and content (backward compatibility)
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <li>
                  <a href="#" onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;">
                    <i class="fas fa-download"></i> ${file.name}
                  </a>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      ` : ''}
      <div class="assignment-actions">
        <button class="btn-primary" onclick="viewSubmissions('${assignment.id}')">
          <i class="fas fa-eye"></i> View Submissions
        </button>
      </div>
    `;
    assignmentsContainer.appendChild(assignmentElement);
  });
}

// View assignment submissions with grading functionality
function viewSubmissions(assignmentId) {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const assignment = classItem.assignments.find(a => a.id === assignmentId);
  if (!assignment) return;
  
  // Remove any existing submissions modal
  const existingModal = document.getElementById('submissions-modal');
  if (existingModal) {
    existingModal.remove();
  }
  
  // Create a new modal for submissions
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.style.display = 'flex';
  modal.id = 'submissions-modal';
  
  let submissionsHTML = `
    <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
      <div class="modal-header">
        <h3>Submissions for "${assignment.title}"</h3>
        <button class="close-btn" onclick="closeSubmissionsModal()"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body" style="padding: 2rem;">
  `;
  
  if (!assignment.submissions || assignment.submissions.length === 0) {
    submissionsHTML += `
      <div class="empty-state">
        <i class="fas fa-inbox"></i>
        <h3>No Submissions Yet</h3>
        <p>Students haven't submitted this assignment yet.</p>
      </div>
    `;
  } else {
    submissionsHTML += '<div class="submissions-list" style="display: flex; flex-direction: column; gap: 1.5rem;">';
    
    assignment.submissions.forEach(submission => {
      const student = classItem.students ? classItem.students.find(s => String(s.id) === String(submission.studentId)) : null;
      const studentName = student ? (student.name || `${student.first_name || ''} ${student.last_name || ''}`.trim()) : 'Unknown Student';
      const isGraded = submission.grade !== undefined;
      
      submissionsHTML += `
        <div class="submission-item" style="border: 2px solid #e0e0e0; border-radius: 12px; padding: 1.5rem; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem; flex-wrap: wrap; gap: 1rem;">
            <div style="flex: 1; min-width: 200px;">
              <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem;">
                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(studentName)}&background=4a90a4&color=fff" 
                     alt="${studentName}" 
                     style="width: 40px; height: 40px; border-radius: 50%;">
                <h4 style="margin: 0; font-size: 1.1rem;">${studentName}</h4>
              </div>
              <p style="color: #666; font-size: 0.9rem; margin: 0.25rem 0;">
                <i class="fas fa-clock"></i> Submitted: ${new Date(submission.date).toLocaleString()}
              </p>
              ${isGraded ? `
                <div style="margin-top: 0.75rem;">
                  <span style="display: inline-block; background: #d4edda; color: #155724; padding: 0.5rem 1rem; border-radius: 6px; font-weight: 600; font-size: 0.95rem;">
                    <i class="fas fa-check-circle"></i> Graded: ${submission.grade}/${assignment.points} (${((submission.grade / assignment.points) * 100).toFixed(1)}%)
                  </span>
                </div>
              ` : `
                <div style="margin-top: 0.75rem;">
                  <span style="display: inline-block; background: #fff3cd; color: #856404; padding: 0.5rem 1rem; border-radius: 6px; font-weight: 600; font-size: 0.95rem;">
                    <i class="fas fa-hourglass-half"></i> Not Graded Yet
                  </span>
                </div>
              `}
            </div>
            <button class="btn-primary" 
                    onclick="openGradingModal('${assignmentId}', '${submission.studentId}')"
                    style="white-space: nowrap; padding: 0.75rem 1.5rem;">
              <i class="fas fa-pen"></i> ${isGraded ? 'Edit Grade' : 'Grade Now'}
            </button>
          </div>
          
          <div style="margin: 1.5rem 0;">
            <strong style="font-size: 1rem; color: #333; display: block; margin-bottom: 0.75rem;">
              <i class="fas fa-file-alt"></i> Submission Content:
            </strong>
            <div style="padding: 1.25rem; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #4a90a4; white-space: pre-wrap; line-height: 1.6; font-size: 0.95rem;">
              ${submission.content || 'No content provided'}
            </div>
          </div>
          
          ${submission.files && submission.files.length > 0 ? `
            <div style="margin: 1.5rem 0;">
              <strong style="font-size: 1rem; color: #333; display: block; margin-bottom: 0.75rem;">
                <i class="fas fa-paperclip"></i> Attached Files:
              </strong>
              <div style="display: flex; flex-wrap: wrap; gap: 0.75rem;">
                ${submission.files.map(file => `
                  <a href="#" 
                    onclick="downloadFile('${file.name.replace(/'/g, "\\'")}', '${file.url || file.content}'); return false;" 
                    style="display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1rem; background: #e8f4f8; color: #4a90a4; text-decoration: none; border-radius: 6px; font-size: 0.9rem; font-weight: 500; transition: all 0.2s ease;"
                    onmouseover="this.style.background='#d0e8f0'; this.style.transform='translateY(-2px)'"
                    onmouseout="this.style.background='#e8f4f8'; this.style.transform='translateY(0)'">
                    <i class="fas fa-download"></i> ${file.name}
                  </a>
                `).join('')}
              </div>
            </div>
          ` : ''}
          
          ${isGraded && submission.feedback ? `
            <div style="margin: 1.5rem 0;">
              <strong style="font-size: 1rem; color: #333; display: block; margin-bottom: 0.75rem;">
                <i class="fas fa-comment"></i> Your Feedback:
              </strong>
              <div style="padding: 1.25rem; background: #e8f4f8; border-radius: 8px; border-left: 4px solid #17a2b8; line-height: 1.6; font-size: 0.95rem;">
                ${submission.feedback}
              </div>
            </div>
          ` : ''}
        </div>
      `;
    });
    
    submissionsHTML += '</div>';
  }
  
  submissionsHTML += `
      </div>
    </div>
  `;
  
  modal.innerHTML = submissionsHTML;
  document.body.appendChild(modal);
  
  // Add click outside to close
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeSubmissionsModal();
    }
  });
}

function openGradeModal(submissionId) {
  // Hide submission modal first
  const submissionModal = document.getElementById('submission-modal');
  if (submissionModal) submissionModal.style.display = 'none';

  // Show grade modal above it
  const gradingModal = document.getElementById('grading-modal');
  if (gradingModal) {
    gradingModal.style.display = 'flex';
    gradingModal.style.zIndex = '1000'; // Ensures it's above all
  }
}


// Close submissions modal
function closeSubmissionsModal() {
  const modal = document.getElementById('submissions-modal');
  if (modal) {
    modal.remove();
  }
} 

// FIXED: Complete openGradingModal function
function openGradingModal(assignmentId, studentId) {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const assignment = classItem.assignments.find(a => a.id === assignmentId);
  if (!assignment) return;
  
  const submission = assignment.submissions.find(s => String(s.studentId) === String(studentId));
  if (!submission) {
    alert('Submission not found.');
    return;
  }
  
  const student = classItem.students ? classItem.students.find(s => String(s.id) === String(studentId)) : null;
  const studentName = student ? (student.name || `${student.first_name || ''} ${student.last_name || ''}`.trim()) : 'Unknown Student';
  
  const gradingModal = document.getElementById('grading-modal');
  if (!gradingModal) {
    console.error('Grading modal not found in HTML');
    return;
  }
  
  // Set high z-index to appear above submissions modal
  gradingModal.style.zIndex = '10000';
  
  const modalBody = gradingModal.querySelector('.modal-body');
  if (modalBody) {
    modalBody.innerHTML = `
      <div class="form-group">
        <label><i class="fas fa-user"></i> Student</label>
        <div style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 6px; font-weight: 500;">
          ${studentName}
        </div>
      </div>
      
      <div class="form-group">
        <label><i class="fas fa-tasks"></i> Assignment</label>
        <div style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 6px; font-weight: 500;">
          ${assignment.title}
        </div>
      </div>
      
      <div class="form-group">
        <label><i class="fas fa-file-alt"></i> Submission</label>
        <div style="max-height: 200px; overflow-y: auto; padding: 1rem; background: #f8f9fa; border-radius: 6px; white-space: pre-wrap; line-height: 1.6; border-left: 3px solid #4a90a4;">
          ${submission.content || 'No content'}
        </div>
      </div>
      
      <div class="form-group">
        <label for="grade-score"><i class="fas fa-star"></i> Grade (0-${assignment.points})</label>
        <input type="number" 
               id="grade-score" 
               min="0" 
               max="${assignment.points}" 
               value="${submission.grade || ''}" 
               placeholder="Enter grade"
               style="width: 100%; padding: 0.75rem; border: 2px solid #e0e0e0; border-radius: 6px; font-size: 1rem;">
        <small style="color: #666; display: block; margin-top: 0.5rem;">
          Maximum points: ${assignment.points}
        </small>
      </div>
      
      <div class="form-group">
        <label for="grade-feedback"><i class="fas fa-comment"></i> Feedback (Optional)</label>
        <textarea id="grade-feedback" 
                  rows="4" 
                  placeholder="Provide feedback to the student..."
                  style="width: 100%; padding: 0.75rem; border: 2px solid #e0e0e0; border-radius: 6px; font-size: 1rem; resize: vertical; font-family: inherit;">${submission.feedback || ''}</textarea>
      </div>
    `;
  }
  
  gradingModal.dataset.assignmentId = assignmentId;
  gradingModal.dataset.studentId = studentId;
  gradingModal.style.display = 'flex';
  
  setTimeout(() => {
    const gradeInput = document.getElementById('grade-score');
    if (gradeInput) gradeInput.focus();
  }, 100);
}

// Add at the top of both files

// ✅ Monitor localStorage usage
function checkStorageUsage() {
  try {
    let totalSize = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        totalSize += localStorage[key].length + key.length;
      }
    }
    
    const sizeInMB = (totalSize / 1024 / 1024).toFixed(2);
    const maxSize = 10; // Approximate max
    const percentUsed = ((sizeInMB / maxSize) * 100).toFixed(1);
    
    console.log(`📊 Storage Usage: ${sizeInMB}MB / ~${maxSize}MB (${percentUsed}%)`);
    
    if (percentUsed > 80) {
      console.warn('⚠️ Storage nearly full! Consider clearing old data.');
      if (percentUsed > 95) {
        alert('⚠️ Warning: Storage is almost full. Please clear some data or avoid uploading large files.');
      }
    }
    
    return { sizeInMB, percentUsed };
  } catch (e) {
    console.error('Error checking storage:', e);
    return null;
  }
}

// Call this periodically
setInterval(checkStorageUsage, 30000); // Check every 30 seconds

function saveGrade() {
    console.log('💾 saveGrade() function called');
    
    const modalEl = document.getElementById('grading-modal');
    if (!modalEl) {
        console.error('❌ Grading modal not found');
        alert('Error: Grading modal not found. Please refresh the page.');
        return;
    }
    
    const assignmentId = modalEl.dataset.assignmentId;
    const studentId = modalEl.dataset.studentId;
    
    console.log('📋 Assignment ID:', assignmentId);
    console.log('👤 Student ID:', studentId);
    
    if (!assignmentId || !studentId) {
        alert('❌ Error: Missing assignment or student ID');
        return;
    }
    
    const gradeInput = document.getElementById('grade-score');
    const feedbackInput = document.getElementById('grade-feedback');
    
    if (!gradeInput) {
        console.error('❌ Grade input not found');
        alert('Error: Grade input field not found');
        return;
    }
    
    const gradeValue = gradeInput.value.trim();
    
    if (gradeValue === '') {
        alert('⚠️ Please enter a grade');
        gradeInput.focus();
        return;
    }
    
    const grade = parseInt(gradeValue);
    const feedback = feedbackInput ? feedbackInput.value.trim() : '';
    
    if (isNaN(grade)) {
        alert('⚠️ Please enter a valid number');
        gradeInput.focus();
        return;
    }
    
    const classItem = classes.find(c => c.id === currentClassId);
    if (!classItem) {
        alert('❌ Class not found');
        return;
    }
    
    const assignment = classItem.assignments ? classItem.assignments.find(a => a.id === assignmentId) : null;
    if (!assignment) {
        alert('❌ Assignment not found');
        return;
    }
    
    const maxPoints = assignment.points || 100;
    
    if (grade < 0 || grade > maxPoints) {
        alert(`⚠️ Grade must be between 0 and ${maxPoints}`);
        gradeInput.focus();
        return;
    }
    
    const submission = assignment.submissions ? 
        assignment.submissions.find(s => String(s.studentId) === String(studentId)) : null;
    
    if (!submission) {
        alert('❌ Submission not found');
        return;
    }
    
    console.log('✓ Found submission:', submission);
    
    // ✅ FIX: Update submission with grade
    submission.grade = grade;
    submission.feedback = feedback;
    submission.gradedDate = new Date().toISOString();
    
    console.log('✓ Updated submission:', submission);
    
    try {
        // Update classes array
        const classIndex = classes.findIndex(c => c.id === currentClassId);
        if (classIndex !== -1 && classes[classIndex].assignments) {
            const assignmentIndex = classes[classIndex].assignments.findIndex(a => a.id === assignmentId);
            if (assignmentIndex !== -1 && classes[classIndex].assignments[assignmentIndex].submissions) {
                const submissionIndex = classes[classIndex].assignments[assignmentIndex].submissions
                    .findIndex(s => String(s.studentId) === String(studentId));
                
                if (submissionIndex !== -1) {
                    classes[classIndex].assignments[assignmentIndex].submissions[submissionIndex] = submission;
                    console.log('✓ Updated in classes array');
                }
            }
        }
        
        // ✅ FIX: Save to localStorage with error handling
        try {
            const savedClasses = localStorage.getItem('professor_classes');
            let localClasses = savedClasses ? JSON.parse(savedClasses) : [];
            
            const localClassIndex = localClasses.findIndex(c => c.id === currentClassId || c.code === classItem.code);
            
            if (localClassIndex !== -1 && localClasses[localClassIndex].assignments) {
                const localAssignmentIndex = localClasses[localClassIndex].assignments
                    .findIndex(a => a.id === assignmentId);
                
                if (localAssignmentIndex !== -1 && localClasses[localClassIndex].assignments[localAssignmentIndex].submissions) {
                    const localSubmissionIndex = localClasses[localClassIndex].assignments[localAssignmentIndex].submissions
                        .findIndex(s => String(s.studentId) === String(studentId));
                    
                    if (localSubmissionIndex !== -1) {
                        localClasses[localClassIndex].assignments[localAssignmentIndex].submissions[localSubmissionIndex] = submission;
                    }
                }
                
                localStorage.setItem('professor_classes', JSON.stringify(localClasses));
                console.log('✓ Saved to localStorage');
            }
        } catch (storageError) {
            if (storageError.name === 'QuotaExceededError') {
                console.error('⚠️ Storage quota exceeded');
                alert('⚠️ Warning: Storage full. Grade saved in memory but may not persist. Please clear old data.');
            } else {
                throw storageError;
            }
        }
        
        // Close modal
        modalEl.style.display = 'none';
        modalEl.style.zIndex = '';
        
        // Update UI
        loadClassAssignments();
        loadClassGrades();
        
        // ✅ FIX: Create notification for student
        addNotification(
            'grade',
            'Assignment Graded',
            `${submission.studentName}'s assignment "${assignment.title}" has been graded: ${grade}/${maxPoints}`,
            `class:${currentClassId}`
        );
        
        // Success message
        const studentName = submission.studentName || 'Student';
        const percentage = ((grade / maxPoints) * 100).toFixed(1);
        alert(`✅ Grade Saved Successfully!\n\nStudent: ${studentName}\nGrade: ${grade}/${maxPoints} (${percentage}%)\n${feedback ? 'Feedback: ' + feedback : ''}`);
        
        console.log('✅ Grade saved successfully!');
        
        // Reopen submissions modal
        setTimeout(() => {
            viewSubmissions(assignmentId);
        }, 300);
        
    } catch (error) {
        console.error('❌ Error saving grade:', error);
        alert('❌ Failed to save grade: ' + error.message);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Wait for DOM to be fully loaded
    setTimeout(() => {
        const saveGradeBtn = document.getElementById('save-grade');
        if (saveGradeBtn) {
            // Remove any old listeners
            const newBtn = saveGradeBtn.cloneNode(true);
            saveGradeBtn.parentNode.replaceChild(newBtn, saveGradeBtn);
            
            // Add fresh listener
            newBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                console.log('🖱️ Save Grade button clicked');
                saveGrade();
            });
            
            console.log('✅ Save grade button listener attached');
        } else {
            console.warn('⚠️ Save grade button not found on page load');
        }
    }, 500);
});

// Load class grades
function loadClassGrades() {
  const classItem = classes.find(c => c.id === currentClassId);
  const gradesContainer = document.getElementById('grades-container');
  
  if (!classItem || !gradesContainer) return;
  
  gradesContainer.innerHTML = '';
  
  if (!classItem.students || classItem.students.length === 0) { // Bug fix: Check if students array exists
    gradesContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-chart-line"></i>
        <h3>No Student Grades</h3>
        <p>Grades will appear here once students submit assignments</p>
      </div>
    `;
    return;
  }
  
  // Create grades table
  let gradesHTML = `
    <div class="grades-table">
      <table>
        <thead>
          <tr>
            <th>Student</th>
            <th>Student ID</th>
  `;
  
  // Add assignment columns
  classItem.assignments.forEach(assignment => {
    gradesHTML += `<th>${assignment.title} (${assignment.points}pts)</th>`;
  });
  
  gradesHTML += `
            <th>Average</th>
          </tr>
        </thead>
        <tbody>
  `;
  
  // Add student rows
  classItem.students.forEach(student => {
    gradesHTML += `
      <tr>
        <td>${student.name}</td>
        <td>${student.id}</td>
    `;
    
    let totalScore = 0;
    let totalMaxPoints = 0;
    
    // Add grades for each assignment
    classItem.assignments.forEach(assignment => {
      const submission = assignment.submissions.find(s => s.studentId === student.id);
      if (submission && submission.grade !== undefined) {
        gradesHTML += `<td>${submission.grade}/${assignment.points}</td>`;
        totalScore += submission.grade;
        totalMaxPoints += assignment.points;
      } else {
        gradesHTML += '<td>-</td>';
      }
    });
    
    // Calculate average
    const average = totalMaxPoints > 0 ? ((totalScore / totalMaxPoints) * 100).toFixed(2) : '-';
    // Update student local stats for display in student-list
    student.averageGrade = average !== '-' ? average : 'N/A';
    student.assignmentCount = classItem.assignments.length;
    
    gradesHTML += `<td>${average}${average !== '-' ? '%' : ''}</td>`; // Display average as a percentage
    
    gradesHTML += `</tr>`;
  });
  
  gradesHTML += `
        </tbody>
      </table>
    </div>
  `;
  
  gradesContainer.innerHTML = gradesHTML;
}

// Export student list
function exportStudentList() {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem || !classItem.students || classItem.students.length === 0) {
    alert('No students to export');
    return;
  }
  
  let csvContent = 'Name,Student ID,Email\n';
  classItem.students.forEach(student => {
    // Bug Fix: Ensure no commas in data break CSV format (simple fix for demo)
    const name = (student.name || '').replace(/,/g, '');
    const email = (student.email || '').replace(/,/g, '');
    csvContent += `${name},${student.id},${email}\n`;
  });
  
  downloadCSV(csvContent, `${classItem.name}_students.csv`);
}

// Export grades
function exportGrades() {
  const classItem = classes.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  let csvContent = 'Student,Student ID';
  
  // Add assignment headers
  classItem.assignments.forEach(assignment => {
    csvContent += `,"${assignment.title} (Score)","${assignment.title} (Points)"`; // Export score and max points
  });
  
  csvContent += ',Average (%)\n';
  
  // Add student data
  classItem.students.forEach(student => {
    csvContent += `"${student.name}",${student.id}`;
    
    let totalScore = 0;
    let totalMaxPoints = 0;
    
    classItem.assignments.forEach(assignment => {
      const submission = assignment.submissions.find(s => s.studentId === student.id);
      if (submission && submission.grade !== undefined) {
        csvContent += `,${submission.grade},${assignment.points}`;
        totalScore += submission.grade;
        totalMaxPoints += assignment.points;
      } else {
        csvContent += ',-,-';
      }
    });
    
    const average = totalMaxPoints > 0 ? ((totalScore / totalMaxPoints) * 100).toFixed(2) : '-';
    csvContent += `,${average}\n`;
  });
  
  downloadCSV(csvContent, `${classItem.name}_grades.csv`);
}

// Download CSV file
function downloadCSV(content, filename) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' }); // Added charset for broader compatibility
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Download file
// ✅ PROFESSOR VERSION: Enhanced downloadFile with VIDEO PLAYER
function downloadFile(filename, urlOrContent) {
  console.log('📥 Downloading/Playing file:', filename);
  
  // Check if it's a video file
  const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
  const fileExtension = filename.split('.').pop().toLowerCase();
  const isVideo = videoExtensions.includes(fileExtension);
  
  // If video, show player modal
  if (isVideo && urlOrContent && urlOrContent.startsWith('/uploads/')) {
    showVideoPlayerProfessor(filename, urlOrContent);
    return;
  }
  
  // Regular download for non-video
  if (urlOrContent && urlOrContent.startsWith('/uploads/')) {
    const link = document.createElement('a');
    link.href = urlOrContent;
    link.download = filename;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } else if (urlOrContent && urlOrContent.startsWith('data:')) {
    try {
      const link = document.createElement('a');
      link.href = urlOrContent;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error('Error downloading file:', e);
      alert('Error downloading file: ' + e.message);
    }
  } else {
    alert('Invalid file format. Please contact support.');
  }
}

// ✅ VIDEO PLAYER for professors
function showVideoPlayerProfessor(filename, videoUrl) {
  const existingModal = document.getElementById('video-player-modal-prof');
  if (existingModal) {
    existingModal.remove();
  }
  
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.style.display = 'flex';
  modal.style.zIndex = '10001';
  modal.id = 'video-player-modal-prof';
  
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 900px; max-height: 95vh; overflow: hidden;">
      <div class="modal-header">
        <h3><i class="fas fa-play-circle"></i> ${filename}</h3>
        <button class="close-btn" onclick="closeVideoPlayerProfessor()">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body" style="padding: 0; background: #000;">
        <video 
          id="prof-video-player" 
          controls 
          controlsList="nodownload"
          style="width: 100%; max-height: 70vh; display: block;"
          autoplay>
          <source src="${videoUrl}" type="video/${filename.split('.').pop()}">
          Your browser does not support the video tag.
        </video>
      </div>
      <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.5rem;">
        <div style="display: flex; gap: 1rem; align-items: center;">
          <button onclick="togglePlayPauseProfessor()" class="btn-secondary" style="min-width: 100px;">
            <i class="fas fa-pause" id="prof-play-pause-icon"></i> <span id="prof-play-pause-text">Pause</span>
          </button>
          <button onclick="toggleFullscreenProfessor()" class="btn-secondary">
            <i class="fas fa-expand"></i> Fullscreen
          </button>
        </div>
        <div style="display: flex; gap: 0.5rem;">
          <button onclick="changePlaybackSpeedProfessor(-0.25)" class="btn-outline" title="Slower">
            <i class="fas fa-backward"></i>
          </button>
          <span id="prof-playback-speed" style="padding: 0.5rem 1rem; background: #f8f9fa; border-radius: 6px; font-weight: 600;">1.0x</span>
          <button onclick="changePlaybackSpeedProfessor(0.25)" class="btn-outline" title="Faster">
            <i class="fas fa-forward"></i>
          </button>
        </div>
        <a href="${videoUrl}" download="${filename}" class="btn-primary" style="text-decoration: none;">
          <i class="fas fa-download"></i> Download
        </a>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeVideoPlayerProfessor();
    }
  });
  
  document.addEventListener('keydown', videoKeyboardHandlerProfessor);
}

function closeVideoPlayerProfessor() {
  const modal = document.getElementById('video-player-modal-prof');
  if (modal) {
    const video = document.getElementById('prof-video-player');
    if (video) video.pause();
    modal.remove();
    document.removeEventListener('keydown', videoKeyboardHandlerProfessor);
  }
}

function togglePlayPauseProfessor() {
  const video = document.getElementById('prof-video-player');
  const icon = document.getElementById('prof-play-pause-icon');
  const text = document.getElementById('prof-play-pause-text');
  
  if (video.paused) {
    video.play();
    icon.className = 'fas fa-pause';
    text.textContent = 'Pause';
  } else {
    video.pause();
    icon.className = 'fas fa-play';
    text.textContent = 'Play';
  }
}

function toggleFullscreenProfessor() {
  const video = document.getElementById('prof-video-player');
  
  if (!document.fullscreenElement) {
    if (video.requestFullscreen) {
      video.requestFullscreen();
    } else if (video.webkitRequestFullscreen) {
      video.webkitRequestFullscreen();
    } else if (video.msRequestFullscreen) {
      video.msRequestFullscreen();
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }
}

function changePlaybackSpeedProfessor(delta) {
  const video = document.getElementById('prof-video-player');
  const speedDisplay = document.getElementById('prof-playback-speed');
  
  let newSpeed = video.playbackRate + delta;
  newSpeed = Math.max(0.25, Math.min(2.0, newSpeed));
  
  video.playbackRate = newSpeed;
  speedDisplay.textContent = newSpeed.toFixed(2) + 'x';
}

function videoKeyboardHandlerProfessor(e) {
  const video = document.getElementById('prof-video-player');
  if (!video) return;
  
  switch(e.key) {
    case ' ':
    case 'k':
      e.preventDefault();
      togglePlayPauseProfessor();
      break;
    case 'f':
      e.preventDefault();
      toggleFullscreenProfessor();
      break;
    case 'ArrowLeft':
      e.preventDefault();
      video.currentTime -= 5;
      break;
    case 'ArrowRight':
      e.preventDefault();
      video.currentTime += 5;
      break;
    case 'ArrowUp':
      e.preventDefault();
      video.volume = Math.min(1, video.volume + 0.1);
      break;
    case 'ArrowDown':
      e.preventDefault();
      video.volume = Math.max(0, video.volume - 0.1);
      break;
    case 'm':
      e.preventDefault();
      video.muted = !video.muted;
      break;
    case 'Escape':
      closeVideoPlayerProfessor();
      break;
  }
}

// ✅ UPDATED: Load class assignments with VIDEO ICONS
function loadClassAssignments() {
  const classItem = classes.find(c => c.id === currentClassId);
  const assignmentsContainer = document.getElementById('assignments-container');
  
  if (!classItem || !assignmentsContainer) return;
  
  assignmentsContainer.innerHTML = '';
  
  if (!classItem.assignments || classItem.assignments.length === 0) {
    assignmentsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No Assignments</h3>
        <p>Create your first assignment to get started</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT BY CREATION DATE (NEWEST FIRST)
  const sortedAssignments = [...classItem.assignments].sort((a, b) => {
    const dateA = new Date(a.dateCreated || a.dueDate);
    const dateB = new Date(b.dateCreated || b.dueDate);
    return dateB - dateA;
  });

  sortedAssignments.forEach(assignment => {
    const submissionCount = assignment.submissions ? assignment.submissions.length : 0;
    const gradedCount = assignment.submissions ? assignment.submissions.filter(s => s.grade !== undefined).length : 0;
    
    // ✅ SEPARATE VIDEO AND OTHER FILES
    const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
    const videoFiles = [];
    const otherFiles = [];
    
    if (assignment.files && assignment.files.length > 0) {
      assignment.files.forEach(file => {
        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (videoExtensions.includes(fileExtension)) {
          videoFiles.push(file);
        } else {
          otherFiles.push(file);
        }
      });
    }
    
    const assignmentElement = document.createElement('div');
    assignmentElement.className = 'assignment-card';
    assignmentElement.innerHTML = `
      <div class="assignment-header">
        <h4>${assignment.title}</h4>
        <div style="display: flex; align-items: center; gap: 1rem;">
          <span class="due-date">Due: ${new Date(assignment.dueDate).toLocaleDateString()}</span>
          <button class="btn-danger btn-small" onclick="deleteAssignment('${assignment.id}')" title="Delete assignment">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <p class="assignment-description">${assignment.description}</p>
      <div class="assignment-details">
        <span><i class="fas fa-file-alt"></i> ${assignment.points} Points</span>
        <span><i class="fas fa-users"></i> ${submissionCount} Submissions</span>
        <span><i class="fas fa-check-circle"></i> ${gradedCount} Graded</span>
        ${videoFiles.length > 0 ? `<span style="color: #667eea;"><i class="fas fa-video"></i> ${videoFiles.length} Video${videoFiles.length > 1 ? 's' : ''}</span>` : ''}
      </div>
      
      ${videoFiles.length > 0 ? `
        <div class="assignment-files" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1rem; border-radius: 8px; margin-top: 1rem;">
          <strong style="color: white; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.75rem;">
            <i class="fas fa-video"></i> Video Resources:
          </strong>
          <ul style="list-style: none; padding: 0; margin: 0;">
            ${videoFiles.map(file => {
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <li style="margin-bottom: 0.5rem;">
                  <a href="#" 
                     onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;"
                     style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background: rgba(255,255,255,0.95); border-radius: 6px; text-decoration: none; color: #2d3748; transition: all 0.2s ease;"
                     onmouseover="this.style.transform='translateX(5px)'; this.style.background='white'"
                     onmouseout="this.style.transform='translateX(0)'; this.style.background='rgba(255,255,255,0.95)'">
                    <i class="fas fa-play-circle" style="color: #667eea; font-size: 1.5rem;"></i>
                    <span style="flex: 1; font-weight: 500;">${file.name}</span>
                    <i class="fas fa-chevron-right" style="color: #cbd5e0;"></i>
                  </a>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      ` : ''}
      
      ${otherFiles.length > 0 ? `
        <div class="assignment-files">
          <strong>Other Resources:</strong>
          <ul>
            ${otherFiles.map(file => {
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <li>
                  <a href="#" onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;">
                    <i class="fas fa-download"></i> ${file.name}
                  </a>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      ` : ''}
      
      <div class="assignment-actions">
        <button class="btn-primary" onclick="viewSubmissions('${assignment.id}')">
          <i class="fas fa-eye"></i> View Submissions
        </button>
      </div>
    `;
    assignmentsContainer.appendChild(assignmentElement);
  });
}

// Convert base64 to Blob
function base64ToBlob(base64) {
  const parts = base64.split(';base64,');
  if (parts.length !== 2) {
    throw new Error('Invalid base64 format for Blob conversion.');
  }
  const contentType = parts[0].split(':')[1];
  const raw = window.atob(parts[1]);
  const uInt8Array = new Uint8Array(raw.length);
  
  for (let i = 0; i < raw.length; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }
  
  return new Blob([uInt8Array], { type: contentType });
}

// Calendar functionality
function initializeCalendar() {
  const monthYear = document.getElementById('month-year');
  const calendarDays = document.getElementById('calendar-days');
  const prevMonth = document.getElementById('prev-month');
  const nextMonth = document.getElementById('next-month');
  
  let currentDate = new Date();
  
  function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    // Update month-year display
    monthYear.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;
    
    // Clear previous days
    calendarDays.innerHTML = '';
    
    // Get first day of month (0=Sunday, 6=Saturday)
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Add empty cells for days before first day of month
    // Bug Fix: Adjusting for calendar starting on Sunday (getDay())
    for (let i = 0; i < firstDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day empty';
      calendarDays.appendChild(emptyCell);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      
      const dateKey = `${year}-${month + 1}-${day}`;
      if (calendarEvents[dateKey] && calendarEvents[dateKey].length > 0) { // Bug Fix: Check if events array is not empty
        dayElement.classList.add('has-event');
      }
      
      dayElement.addEventListener('click', () => openEventModal(year, month, day));
      calendarDays.appendChild(dayElement);
    }
  }
  
  prevMonth.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
  });
  
  nextMonth.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
  });
  
  renderCalendar();
}

// Function to update the selected date in the modal before showing it
let currentSelectedDate = null;

function openEventModal(year, month, day) {
  const selectedDateEl = document.getElementById('selected-date');
  const eventList = document.getElementById('event-list');
  
  const date = new Date(year, month, day);
  currentSelectedDate = date;
  selectedDateEl.textContent = date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  const dateKey = `${year}-${month + 1}-${day}`;
  const events = calendarEvents[dateKey] || [];
  
  eventList.innerHTML = '';
  if (events.length === 0) {
    eventList.innerHTML = '<li class="empty-event-li">No events for this day</li>';
  } else {
    // ✅ ADD DELETE BUTTONS to each event
    events.forEach((event, index) => {
      const li = document.createElement('li');
      li.style.display = 'flex';
      li.style.justifyContent = 'space-between';
      li.style.alignItems = 'center';
      li.style.padding = '0.5rem';
      li.style.marginBottom = '0.5rem';
      li.style.background = '#f8f9fa';
      li.style.borderRadius = '6px';
      
      const textSpan = document.createElement('span');
      textSpan.textContent = event;
      textSpan.style.flex = '1';
      
      const deleteBtn = document.createElement('button');
      deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
      deleteBtn.className = 'btn-danger btn-small';
      deleteBtn.style.marginLeft = '1rem';
      deleteBtn.onclick = () => deleteEvent(dateKey, index);
      
      li.appendChild(textSpan);
      li.appendChild(deleteBtn);
      eventList.appendChild(li);
    });
  }
  
  document.getElementById('event-text').value = '';
  document.getElementById('event-modal').style.display = 'flex';
}


// ✅ NEW: Delete calendar event
function deleteEvent(dateKey, eventIndex) {
  if (!confirm('Are you sure you want to delete this event?')) {
    return;
  }
  
  if (!calendarEvents[dateKey]) return;
  
  // Remove event from array
  calendarEvents[dateKey].splice(eventIndex, 1);
  
  // If no events left for this date, remove the date key
  if (calendarEvents[dateKey].length === 0) {
    delete calendarEvents[dateKey];
  }
  
  // Save to localStorage
  localStorage.setItem('calendar_events', JSON.stringify(calendarEvents));
  
  // Re-render calendar to update indicators
  initializeCalendar();
  
  // Refresh the event modal to show updated list
  if (currentSelectedDate) {
    const year = currentSelectedDate.getFullYear();
    const month = currentSelectedDate.getMonth();
    const day = currentSelectedDate.getDate();
    openEventModal(year, month, day);
  }
  
  alert('Event deleted successfully!');
}

document.getElementById('close-event').addEventListener('click', () => {
  document.getElementById('event-modal').style.display = 'none';
});

// ✅ UPDATE: Save event handler (around line 1400)
document.getElementById('save-event').addEventListener('click', () => {
    const eventText = document.getElementById('event-text').value.trim();
    if (!eventText) {
        alert('Please enter event text');
        return;
    }
    
    if (!currentSelectedDate) {
        alert('Error: No date selected.');
        return;
    }
    
    const dateKey = `${currentSelectedDate.getFullYear()}-${currentSelectedDate.getMonth() + 1}-${currentSelectedDate.getDate()}`;
    
    if (!calendarEvents[dateKey]) {
        calendarEvents[dateKey] = [];
    }
    
    calendarEvents[dateKey].push(eventText);
    
    // ✅ FIX: Save to localStorage
    saveCalendarEvents();
    
    document.getElementById('event-text').value = '';
    initializeCalendar();
    
    const year = currentSelectedDate.getFullYear();
    const month = currentSelectedDate.getMonth();
    const day = currentSelectedDate.getDate();
    openEventModal(year, month, day);
    
    alert('Event saved successfully!');
});

// Update dashboard statistics
async function updateDashboardStats() {
  try {
    const response = await fetch('/api/professor/stats');
    if (response.ok) {
      const stats = await response.json();
      
      document.getElementById('total-classes').textContent = stats.total_classes;
      document.getElementById('total-students').textContent = stats.total_students;
      document.getElementById('pending-tasks').textContent = stats.pending_tasks;
      document.getElementById('upcoming-deadlines').textContent = stats.upcoming_deadlines;
    } else {
      // Fallback to calculated stats if API fails
      calculateDashboardStats();
    }
  } catch (error) {
    console.error('Error fetching stats:', error);
    calculateDashboardStats();
  }
  
  // Update deadline list
  updateDeadlineList();
  
  // Update activity list
  updateActivityList();

  // CRITICAL FIX: Load all students for the Students section
  loadAllStudents();
}

// Calculate dashboard stats locally (fallback)
function calculateDashboardStats() {
  document.getElementById('total-classes').textContent = classes.length;
  
  let totalStudents = 0;
  classes.forEach(classItem => {
    // Bug Fix: Check if students array exists
    totalStudents += classItem.students ? classItem.students.length : 0;
  });
  document.getElementById('total-students').textContent = totalStudents;
  
  // Calculate pending tasks (assignments due soon)
  let pendingTasks = 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Normalize today's date
  
  classes.forEach(classItem => {
    // Bug Fix: Check if assignments array exists
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const dueDate = new Date(assignment.dueDate);
        dueDate.setHours(23, 59, 59, 999); // Set to end of day
        if (dueDate > today) {
          pendingTasks++;
        }
      });
    }
  });
  document.getElementById('pending-tasks').textContent = pendingTasks;
  
  // Calculate upcoming deadlines (within 7 days)
  let upcomingDeadlines = 0;
  const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  nextWeek.setHours(23, 59, 59, 999); // Set to end of the week
  
  classes.forEach(classItem => {
    // Bug Fix: Check if assignments array exists
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const dueDate = new Date(assignment.dueDate);
        dueDate.setHours(23, 59, 59, 999);
        if (dueDate > today && dueDate <= nextWeek) {
          upcomingDeadlines++;
        }
      });
    }
  });
  document.getElementById('upcoming-deadlines').textContent = upcomingDeadlines;
}

function updateDeadlineList() {
  const deadlineList = document.getElementById('deadline-list');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  let allDeadlines = [];
  classes.forEach(classItem => {
    // Bug Fix: Check if assignments array exists
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const dueDate = new Date(assignment.dueDate);
        dueDate.setHours(23, 59, 59, 999);
        if (dueDate > today) {
          allDeadlines.push({
            title: assignment.title,
            dueDate: dueDate,
            class: classItem.name
          });
        }
      });
    }
  });
  
  // Sort by due date
  allDeadlines.sort((a, b) => a.dueDate - b.dueDate);
  
  // Take top 5
  allDeadlines = allDeadlines.slice(0, 5);
  
  deadlineList.innerHTML = '';
  if (allDeadlines.length === 0) {
    deadlineList.innerHTML = '<div class="empty-message">No upcoming deadlines</div>';
    return;
  }
  
  allDeadlines.forEach(deadline => {
    const deadlineElement = document.createElement('div');
    deadlineElement.className = 'deadline-item';
    deadlineElement.innerHTML = `
      <div class="deadline-info">
        <h4>${deadline.title}</h4>
        <p>${deadline.class}</p>
      </div>
      <div class="deadline-date">
        ${deadline.dueDate.toLocaleDateString()}
      </div>
    `;
    deadlineList.appendChild(deadlineElement);
  });
}

function updateActivityList() {
  const activityList = document.getElementById('activity-list');
  
  // For demo purposes, create some sample activities
  // Bug fix: Added new activity for the fixed saveGrade functionality to be complete.
  const activities = [
    { action: 'graded', item: 'Submission for Advanced Algorithms', time: '10 minutes ago' },
    { action: 'created', item: 'Data Structures class', time: '2 hours ago' },
    { action: 'uploaded', item: 'Lecture notes for Algorithms', time: '1 day ago' },
    { action: 'created', item: 'Assignment 1: Linked Lists', time: '2 days ago' },
    { action: 'graded', item: '5 submissions for Assignment 1', time: '3 days ago' }
  ];
  
  activityList.innerHTML = '';
  activities.forEach(activity => {
    const activityElement = document.createElement('div');
    activityElement.className = 'activity-item';
    activityElement.innerHTML = `
      <div class="activity-icon">
        <i class="fas fa-${getActivityIcon(activity.action)}"></i>
      </div>
      <div class="activity-details">
        <p>You ${activity.action} <strong>${activity.item}</strong></p>
        <span class="activity-time">${activity.time}</span>
      </div>
    `;
    activityList.appendChild(activityElement);
  });
}

function getActivityIcon(action) {
  switch(action) {
    case 'created': return 'plus-circle';
    case 'uploaded': return 'file-upload';
    case 'graded': return 'check-circle';
    default: return 'circle';
  }
}

// Profile Section Functionality
document.addEventListener('DOMContentLoaded', function() {
  const avatarUpload = document.getElementById('avatar-upload');
  const profileAvatar = document.getElementById('profile-avatar');
  const topbarAvatar = document.getElementById('topbar-avatar');
  
  // Load saved avatar on page load
  const userType = '{{ session.user_type }}'; // 'professor' or 'student'
  const savedAvatar = localStorage.getItem(`${userType}_avatar`);
  if (savedAvatar && profileAvatar && topbarAvatar) {
    profileAvatar.src = savedAvatar;
    topbarAvatar.src = savedAvatar;
  }
  
  if (avatarUpload && profileAvatar && topbarAvatar) {
    avatarUpload.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        if (!file.type.startsWith('image/')) {
          alert('Please select an image file.');
          return;
        }
        
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
          alert('Image size should be less than 5MB');
          return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
          const avatarData = e.target.result;
          
          // Update UI immediately
          profileAvatar.src = avatarData;
          topbarAvatar.src = avatarData;
          
          // Save to localStorage
          localStorage.setItem(`${userType}_avatar`, avatarData);
          
          alert('Profile picture updated successfully!');
        };
        reader.readAsDataURL(file);
      }
    });
  }
  
});

    const savedEvents = localStorage.getItem('calendar_events');
    if (savedEvents) {
        try {
            calendarEvents = JSON.parse(savedEvents);
            console.log('✓ Loaded calendar events:', Object.keys(calendarEvents).length);
        } catch (e) {
            console.error('✗ Error loading calendar events:', e);
            calendarEvents = {};
        }
    }


  // ✅ ADD THIS: Password update functionality
  const updatePasswordBtn = document.getElementById('update-password');
  if (updatePasswordBtn) {
    updatePasswordBtn.addEventListener('click', async function() {
      const currentPassword = document.getElementById('current-password').value.trim();
      const newPassword = document.getElementById('new-password').value.trim();
      const confirmPassword = document.getElementById('confirm-password').value.trim();
      
      // Validation
      if (!currentPassword || !newPassword || !confirmPassword) {
        showMessage('Please fill in all password fields', 'error');
        return;
      }
      
      if (newPassword.length < 8) {
        showMessage('New password must be at least 8 characters', 'error');
        return;
      }
      
      if (newPassword !== confirmPassword) {
        showMessage('New passwords do not match', 'error');
        return;
      }
      
      if (currentPassword === newPassword) {
        showMessage('New password must be different from current password', 'error');
        return;
      }
      
      try {
        updatePasswordBtn.disabled = true;
        updatePasswordBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
        
        const response = await fetch('/api/profile/update-password', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            current_password: currentPassword,
            new_password: newPassword
          })
        });
        
        const result = await response.json();
        
        if (response.ok) {
          showMessage('Password updated successfully!', 'success');
          // Clear fields
          document.getElementById('current-password').value = '';
          document.getElementById('new-password').value = '';
          document.getElementById('confirm-password').value = '';
        } else {
          showMessage(result.error || 'Failed to update password', 'error');
        }
      } catch (error) {
        console.error('Error updating password:', error);
        showMessage('Error updating password. Please try again.', 'error');
      } finally {
        updatePasswordBtn.disabled = false;
        updatePasswordBtn.innerHTML = 'Update Password';
      }
    });
  }
  
  function saveCalendarEvents() {
    try {
        localStorage.setItem('calendar_events', JSON.stringify(calendarEvents));
        console.log('✓ Calendar events saved');
    } catch (e) {
        console.error('✗ Error saving calendar events:', e);
        if (e.name === 'QuotaExceededError') {
            alert('⚠️ Storage full. Please clear some old calendar events.');
        }
    }
}
  
  // ✅ Helper function to show messages
  function showMessage(message, type) {
    const messageEl = document.getElementById('profile-message');
    if (!messageEl) return;
    
    messageEl.textContent = message;
    messageEl.className = `profile-message ${type}`;
    messageEl.style.display = 'block';
    
    setTimeout(() => {
      messageEl.style.display = 'none';
    }, 5000);
  }

// Helper function to show messages
function showMessage(message, type) {
  const messageEl = document.getElementById('profile-message');
  if (!messageEl) return; // Bug Fix: Check if element exists
  
  messageEl.textContent = message;
  messageEl.className = `profile-message ${type}`;
  messageEl.style.display = 'block';
  
  setTimeout(() => {
    messageEl.style.display = 'none';
  }, 5000);
}

// Load all students across all classes for the Students section
function loadAllStudents() {
  const allStudentsList = document.getElementById('all-students-list');
  if (!allStudentsList) return;
  
  allStudentsList.innerHTML = '';
  
  const studentMap = new Map();
  
  classes.forEach(classItem => {
    if (classItem.students && classItem.students.length > 0) {
      classItem.students.forEach(student => {
        const studentKey = student.id || student.student_id;
        if (!studentMap.has(studentKey)) {
          studentMap.set(studentKey, {
            ...student,
            classes: [classItem.name],
            classIds: [classItem.id]
          });
        } else {
          const existingStudent = studentMap.get(studentKey);
          existingStudent.classes.push(classItem.name);
          existingStudent.classIds.push(classItem.id);
        }
      });
    }
  });
  
  let allStudents = Array.from(studentMap.values());
  
  if (allStudents.length === 0) {
    allStudentsList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-users"></i>
        <h3>No Students Enrolled</h3>
        <p>Students will appear here once they join your classes</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT STUDENTS ALPHABETICALLY BY NAME
  allStudents.sort((a, b) => {
    const nameA = (a.name || `${a.first_name || ''} ${a.last_name || ''}`.trim()).toLowerCase();
    const nameB = (b.name || `${b.first_name || ''} ${b.last_name || ''}`.trim()).toLowerCase();
    return nameA.localeCompare(nameB);
  });
  
  const searchInput = document.getElementById('students-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase();
      filterStudents(allStudents, searchTerm);
    });
  }
  
  renderStudentsList(allStudents);
}

// Render students list
function renderStudentsList(students) {
  const allStudentsList = document.getElementById('all-students-list');
  allStudentsList.innerHTML = '';
  
  students.forEach(student => {
    const studentName = student.name || `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
    const studentEmail = student.email || student.username || 'N/A';
    const studentId = student.student_id || student.id || 'N/A';
    
    const studentElement = document.createElement('div');
    studentElement.className = 'student-item';
    studentElement.innerHTML = `
      <div class="student-info">
        <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(studentName)}&background=4a90a4&color=fff" alt="${studentName}" class="avatar">
        <div>
          <h4>${studentName}</h4>
          <p>${studentId} • ${studentEmail}</p>
          <p style="font-size: 0.85rem; color: var(--text-light); margin-top: 0.25rem;">
            Enrolled in: ${student.classes.join(', ')}
          </p>
        </div>
      </div>
      <div class="student-stats">
        <span>${student.classes.length} Class${student.classes.length !== 1 ? 'es' : ''}</span>
      </div>
    `;
    allStudentsList.appendChild(studentElement);
  });
}

// Filter students based on search term
function filterStudents(allStudents, searchTerm) {
  const filtered = allStudents.filter(student => {
    const studentName = (student.name || `${student.first_name || ''} ${student.last_name || ''}`.trim() || '').toLowerCase();
    const studentEmail = (student.email || student.username || '').toLowerCase();
    const studentId = (student.student_id || student.id || '').toLowerCase();
    
    return studentName.includes(searchTerm) || 
           studentEmail.includes(searchTerm) || 
           studentId.includes(searchTerm);
  });
  
  renderStudentsList(filtered);
}

// Export all students to CSV
function exportAllStudents() {
  const studentMap = new Map();
  
  classes.forEach(classItem => {
    if (classItem.students && classItem.students.length > 0) {
      classItem.students.forEach(student => {
        const studentKey = student.id || student.student_id;
        if (!studentMap.has(studentKey)) {
          studentMap.set(studentKey, {
            ...student,
            classes: [classItem.name]
          });
        } else {
          const existingStudent = studentMap.get(studentKey);
          existingStudent.classes.push(classItem.name);
        }
      });
    }
  });
  
  const allStudents = Array.from(studentMap.values());
  
  if (allStudents.length === 0) {
    alert('No students to export');
    return;
  }
  
  let csvContent = 'Name,Student ID,Email,Classes\n';
  allStudents.forEach(student => {
    const name = (student.name || `${student.first_name || ''} ${student.last_name || ''}`.trim() || '').replace(/,/g, '');
    const email = (student.email || student.username || '').replace(/,/g, '');
    const studentId = student.student_id || student.id || '';
    const classes = student.classes.join('; ');
    csvContent += `${name},${studentId},${email},"${classes}"\n`;
  });
  
  downloadCSV(csvContent, 'all_students.csv');
}