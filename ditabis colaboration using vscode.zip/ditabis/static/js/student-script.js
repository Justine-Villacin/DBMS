// Student Dashboard JavaScript - FIXED VERSION

// Global variables
let currentClassId = null;
let enrolledClasses = [];
let assignments = [];
let submissions = [];
let calendarEvents = {};
let notifications = [];

// Get student data from backend
let studentData = {
  id: null,
  student_id: null,
  name: null
};

// DOM Elements
const sidebar = document.getElementById('sidebar');
const contentSections = document.querySelectorAll('.content-section');
const navLinks = document.querySelectorAll('.sidebar nav a');
const profileDropdown = document.getElementById('profile-dropdown');
const dropdownMenu = document.getElementById('dropdown-menu');

// Sidebar toggle
function toggleSidebar() {
  sidebar.classList.toggle('collapsed');
}

// ✅ FIX #2: Load notifications from localStorage
function loadNotifications() {
  const userType = 'student';
  const saved = localStorage.getItem(`${userType}_notifications`);
  if (saved) {
    try {
      notifications = JSON.parse(saved);
      updateNotificationBadge();
    } catch (e) {
      console.error('Error loading notifications:', e);
      notifications = [];
    }
  }
}

// ✅ FIX #2: Save notifications to localStorage
function saveNotifications() {
  const userType = 'student';
  localStorage.setItem(`${userType}_notifications`, JSON.stringify(notifications));
  updateNotificationBadge();
}

// ✅ FIX #2: Add a new notification with settings check
function addNotification(type, title, message, link = null) {
  // Check notification settings
  const settings = getNotificationSettings();
  
  // Map notification types to settings
  const typeToSetting = {
    'assignment': 'assignments',
    'grade': 'grades',
    'material': 'materials',
    'deadline': 'deadlines',
    'feedback': 'grades',
    'enrollment': 'assignments' // Always show
  };
  
  const settingKey = typeToSetting[type];
  if (settingKey && !settings[settingKey]) {
    console.log(`🔕 Notification blocked by settings: ${type}`);
    return; // Don't add notification if disabled
  }
  
  const notification = {
    id: Date.now().toString(),
    type: type,
    title: title,
    message: message,
    link: link,
    timestamp: new Date().toISOString(),
    read: false
  };
  
  notifications.unshift(notification);
  
  // Keep only last 50 notifications
  if (notifications.length > 50) {
    notifications = notifications.slice(0, 50);
  }
  
  saveNotifications();
  
  // ✅ FIX #2: Show browser notification if enabled
  if (settings[settingKey] && "Notification" in window) {
    if (Notification.permission === "granted") {
      new Notification(title, {
        body: message,
        icon: '/images/logo.png',
        badge: '/images/logo.png'
      });
    }
  }
}

// ✅ FIX #2: Get notification settings
function getNotificationSettings() {
  const saved = localStorage.getItem('student_notification_settings');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading notification settings:', e);
    }
  }
  // Default: all enabled
  return {
    assignments: true,
    grades: true,
    materials: true,
    deadlines: true
  };
}

// ✅ FIX #2: Update notification badge
function updateNotificationBadge() {
  const badge = document.querySelector('.notification-badge');
  if (badge) {
    const unreadCount = notifications.filter(n => !n.read).length;
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  }
}

// Mark notification as read
function markNotificationRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification) {
    notification.read = true;
    saveNotifications();
  }
}

// Mark all as read
function markAllNotificationsRead() {
  notifications.forEach(n => n.read = true);
  saveNotifications();
}

// Clear all notifications
function clearAllNotifications() {
  if (confirm('⚠️ Are you sure you want to clear all notifications?')) {
    notifications = [];
    saveNotifications();
    closeNotificationPanel();
  }
}

// ✅ FIX #2: Show notification panel
function showNotificationPanel() {
  const existingPanel = document.getElementById('notification-panel');
  if (existingPanel) {
    existingPanel.remove();
    return;
  }
  
  const panel = document.createElement('div');
  panel.id = 'notification-panel';
  panel.style.cssText = `
    position: fixed;
    top: 70px;
    right: 20px;
    width: 400px;
    max-height: 600px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    z-index: 10000;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  `;
  
  let panelHTML = `
    <div style="padding: 1.5rem; border-bottom: 2px solid #e0e0e0; display: flex; justify-content: space-between; align-items: center; background: #4a90a4; color: white;">
      <h3 style="margin: 0; font-size: 1.2rem;">
        <i class="fas fa-bell"></i> Notifications
      </h3>
      <div style="display: flex; gap: 0.5rem;">
        <button onclick="markAllNotificationsRead()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;" title="Mark all as read">
          <i class="fas fa-check-double"></i>
        </button>
        <button onclick="clearAllNotifications()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;" title="Clear all">
          <i class="fas fa-trash"></i>
        </button>
        <button onclick="closeNotificationPanel()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-size: 0.85rem;">
          <i class="fas fa-times"></i>
        </button>
      </div>
    </div>
    <div style="overflow-y: auto; max-height: 500px;">
  `;
  
  if (notifications.length === 0) {
    panelHTML += `
      <div style="padding: 3rem; text-align: center; color: #666;">
        <i class="fas fa-bell-slash" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
        <p>No notifications</p>
      </div>
    `;
  } else {
    notifications.forEach(notification => {
      const iconMap = {
        'assignment': 'fa-tasks',
        'grade': 'fa-star',
        'material': 'fa-file-upload',
        'enrollment': 'fa-user-plus',
        'submission': 'fa-paper-plane',
        'deadline': 'fa-clock',
        'feedback': 'fa-comment'
      };
      
      const colorMap = {
        'assignment': '#4a90a4',
        'grade': '#28a745',
        'material': '#17a2b8',
        'enrollment': '#6c757d',
        'submission': '#ffc107',
        'deadline': '#dc3545',
        'feedback': '#fd7e14'
      };
      
      const icon = iconMap[notification.type] || 'fa-bell';
      const color = colorMap[notification.type] || '#4a90a4';
      const isUnread = !notification.read;
      
      panelHTML += `
        <div onclick="handleNotificationClick('${notification.id}', '${notification.link || ''}')" 
             style="padding: 1rem 1.5rem; border-bottom: 1px solid #f0f0f0; cursor: pointer; background: ${isUnread ? '#f8f9fa' : 'white'}; transition: all 0.2s ease;"
             onmouseover="this.style.background='#e8f4f8'"
             onmouseout="this.style.background='${isUnread ? '#f8f9fa' : 'white'}'">
          <div style="display: flex; gap: 1rem; align-items: start;">
            <div style="width: 40px; height: 40px; border-radius: 50%; background: ${color}20; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
              <i class="fas ${icon}" style="color: ${color}; font-size: 1.1rem;"></i>
            </div>
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.25rem;">
                <strong style="font-size: 0.95rem; color: #333;">${notification.title}</strong>
                ${isUnread ? '<span style="width: 8px; height: 8px; background: #4a90a4; border-radius: 50%; display: inline-block; margin-left: 0.5rem;"></span>' : ''}
              </div>
              <p style="margin: 0; color: #666; font-size: 0.85rem; line-height: 1.4;">${notification.message}</p>
              <span style="font-size: 0.75rem; color: #999; margin-top: 0.5rem; display: block;">
                ${formatNotificationTime(notification.timestamp)}
              </span>
            </div>
          </div>
        </div>
      `;
    });
  }
  
  panelHTML += `</div>`;
  panel.innerHTML = panelHTML;
  document.body.appendChild(panel);
  
  // Close on outside click
  setTimeout(() => {
    document.addEventListener('click', handleOutsideClick);
  }, 100);
}

function handleOutsideClick(e) {
  const panel = document.getElementById('notification-panel');
  const notificationIcon = document.querySelector('.notification-icon');
  
  if (panel && !panel.contains(e.target) && !notificationIcon.contains(e.target)) {
    closeNotificationPanel();
  }
}

function closeNotificationPanel() {
  const panel = document.getElementById('notification-panel');
  if (panel) {
    panel.remove();
    document.removeEventListener('click', handleOutsideClick);
  }
}

function handleNotificationClick(notificationId, link) {
  markNotificationRead(notificationId);
  
  if (link) {
    if (link.startsWith('class:')) {
      const classId = link.replace('class:', '');
      openClass(classId);
    } else if (link.startsWith('section:')) {
      const sectionId = link.replace('section:', '');
      showSection(sectionId);
    }
  }
  
  closeNotificationPanel();
}

function formatNotificationTime(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  return date.toLocaleDateString();
}

// ✅ FIX #3: Main Search Bar Functionality
function initializeMainSearch() {
  const searchInput = document.querySelector('.topbar .search-bar input');
  if (!searchInput) return;
  
  let searchResults = null;
  
  searchInput.addEventListener('input', function(e) {
    const query = e.target.value.trim().toLowerCase();
    
    // Remove existing results
    if (searchResults) {
      searchResults.remove();
      searchResults = null;
    }
    
    if (query.length < 2) return;
    
    // Search through classes, assignments, and materials
    const results = [];
    
    enrolledClasses.forEach(classItem => {
      // Search class names
      if (classItem.name.toLowerCase().includes(query)) {
        results.push({
          type: 'class',
          title: classItem.name,
          subtitle: `Class • Code: ${classItem.code}`,
          icon: 'fa-book-open',
          action: () => openClass(classItem.id)
        });
      }
      
      // Search assignments
      if (classItem.assignments) {
        classItem.assignments.forEach(assignment => {
          if (assignment.title.toLowerCase().includes(query) || 
              assignment.description.toLowerCase().includes(query)) {
            results.push({
              type: 'assignment',
              title: assignment.title,
              subtitle: `Assignment • ${classItem.name}`,
              icon: 'fa-tasks',
              action: () => {
                openClass(classItem.id);
                setTimeout(() => switchTab('assignments'), 300);
              }
            });
          }
        });
      }
      
      // Search materials
      if (classItem.materials) {
        classItem.materials.forEach(material => {
          if (material.title.toLowerCase().includes(query) || 
              material.description.toLowerCase().includes(query)) {
            results.push({
              type: 'material',
              title: material.title,
              subtitle: `Material • ${classItem.name}`,
              icon: 'fa-file-alt',
              action: () => {
                openClass(classItem.id);
                setTimeout(() => switchTab('posts'), 300);
              }
            });
          }
        });
      }
    });
    
    if (results.length === 0) {
      results.push({
        type: 'empty',
        title: 'No results found',
        subtitle: `No matches for "${query}"`,
        icon: 'fa-search',
        action: null
      });
    }
    
    // Display results
    showSearchResults(results, searchInput);
  });
  
  // Close results when clicking outside
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.search-bar')) {
      if (searchResults) {
        searchResults.remove();
        searchResults = null;
      }
    }
  });
}

function showSearchResults(results, inputElement) {
  const searchBar = inputElement.closest('.search-bar');
  
  const resultsDiv = document.createElement('div');
  resultsDiv.style.cssText = `
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    margin-top: 0.5rem;
    max-height: 400px;
    overflow-y: auto;
    z-index: 1000;
  `;
  
  results.slice(0, 10).forEach((result, index) => {
    const resultItem = document.createElement('div');
    resultItem.style.cssText = `
      padding: 1rem;
      border-bottom: 1px solid #f0f0f0;
      cursor: ${result.action ? 'pointer' : 'default'};
      transition: background 0.2s;
    `;
    
    resultItem.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1rem;">
        <div style="width: 40px; height: 40px; border-radius: 50%; background: #e8f4f8; display: flex; align-items: center; justify-content: center;">
          <i class="fas ${result.icon}" style="color: #4a90a4;"></i>
        </div>
        <div style="flex: 1;">
          <div style="font-weight: 500; color: #333;">${result.title}</div>
          <div style="font-size: 0.85rem; color: #666;">${result.subtitle}</div>
        </div>
      </div>
    `;
    
    if (result.action) {
      resultItem.addEventListener('mouseover', () => {
        resultItem.style.background = '#f8f9fa';
      });
      
      resultItem.addEventListener('mouseout', () => {
        resultItem.style.background = 'white';
      });
      
      resultItem.addEventListener('click', () => {
        result.action();
        resultsDiv.remove();
        inputElement.value = '';
      });
    }
    
    resultsDiv.appendChild(resultItem);
  });
  
  searchBar.style.position = 'relative';
  searchBar.appendChild(resultsDiv);
  
  // Store reference for cleanup
  const existingResults = document.querySelector('.search-bar > div[style*="position: absolute"]');
  if (existingResults) {
    existingResults.remove();
  }
}

// Show section function
function showSection(sectionId, element = null) {
  contentSections.forEach(section => {
    section.classList.remove('active');
  });

  if (element) {
    navLinks.forEach(link => {
      link.classList.remove('active');
    });
    element.classList.add('active');
  }

  document.getElementById(sectionId).classList.add('active');
  
  if (sectionId === 'assignments-section') {
    loadAllAssignments();
  } else if (sectionId === 'archived-classes-section') {
    loadArchivedClasses();
  }
}

// Profile dropdown toggle
if (profileDropdown) {
  profileDropdown.addEventListener('click', function(e) {
    e.stopPropagation();
    dropdownMenu.classList.toggle('show');
  });
}

// Close dropdown when clicking outside
document.addEventListener('click', function() {
  dropdownMenu.classList.remove('show');
});

document.addEventListener('DOMContentLoaded', async function() {
  // ✅ FIX #2: Initialize notifications
  loadNotifications();
  
  // ✅ FIX #2: Hook up notification icon
  const notificationIcon = document.querySelector('.notification-icon');
  if (notificationIcon) {
    notificationIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      showNotificationPanel();
    });
  }
  
  // ✅ FIX #3: Initialize main search bar
  initializeMainSearch();
  
  // Fetch student profile data first
  await fetchStudentProfile();
  
  // Initialize dashboard stats
  updateDashboardStats();
  
  // Load enrolled classes from API
  await loadEnrolledClasses();
  
  // Initialize calendar
  initializeCalendar();
  
  // Event listeners for class management
  document.getElementById('join-class-btn').addEventListener('click', showJoinClassModal);
  document.getElementById('cancel-join-class').addEventListener('click', hideJoinClassModal);
  document.getElementById('join-class').addEventListener('click', joinClass);

  const closeSubmissionModal = document.getElementById('close-submission-modal');
  if (closeSubmissionModal) {
    closeSubmissionModal.addEventListener('click', function() {
      const modal = document.getElementById('submission-modal');
      if (modal) {
        modal.style.display = 'none';
        document.getElementById('submission-text').value = '';
        document.getElementById('submission-files').value = '';
        document.getElementById('submission-files-chosen').textContent = 'No files selected';
      }
    });
  }

  const submitBtn = document.getElementById('submit-assignment');
  if (submitBtn) {
    const newSubmitBtn = submitBtn.cloneNode(true);
    submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);
    
    newSubmitBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      this.disabled = true;
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
      
      try {
        await submitAssignment();
      } catch (error) {
        console.error('❌ Submission error:', error);
        alert('❌ Error submitting assignment: ' + error.message);
      } finally {
        this.disabled = false;
        this.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Assignment';
      }
    });
  }
  
  const submissionFiles = document.getElementById('submission-files');
  if (submissionFiles) {
    submissionFiles.addEventListener('change', function() {
      const fileChosen = document.getElementById('submission-files-chosen');
      if (this.files.length > 0) {
        const fileNames = Array.from(this.files).map(f => f.name).join(', ');
        fileChosen.textContent = `${this.files.length} file(s) selected: ${fileNames}`;
      } else {
        fileChosen.textContent = 'No files selected';
      }
    });
  }

  // Profile picture upload
  const avatarUpload = document.getElementById('avatar-upload');
  const profileAvatar = document.getElementById('profile-avatar');
  const topbarAvatar = document.getElementById('topbar-avatar');
  
  const userType = 'student';
  
  const savedAvatar = localStorage.getItem(`${userType}_avatar`);
  if (savedAvatar && profileAvatar && topbarAvatar) {
    profileAvatar.src = savedAvatar;
    topbarAvatar.src = savedAvatar;
  }
  
  if (avatarUpload && profileAvatar && topbarAvatar) {
    const newAvatarUpload = avatarUpload.cloneNode(true);
    avatarUpload.parentNode.replaceChild(newAvatarUpload, avatarUpload);
    
    newAvatarUpload.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (!file) return;
      
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file (JPG, PNG, GIF)');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size must be less than 5MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = function(e) {
        const avatarData = e.target.result;
        
        profileAvatar.src = avatarData;
        topbarAvatar.src = avatarData;
        
        try {
          localStorage.setItem(`${userType}_avatar`, avatarData);
          showMessage('Profile picture updated successfully!', 'success');
        } catch (error) {
          if (error.name === 'QuotaExceededError') {
            alert('Storage full. Please choose a smaller image or clear browser data.');
          } else {
            alert('Error saving profile picture: ' + error.message);
          }
        }
      };
      
      reader.onerror = function() {
        alert('Error reading file. Please try again.');
      };
      
      reader.readAsDataURL(file);
    });
  }
  
  // Settings tabs
  document.querySelectorAll('.settings-tab').forEach(tab => {
    tab.addEventListener('click', function() {
      const tabName = this.getAttribute('data-tab');
      
      document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
      
      this.classList.add('active');
      document.getElementById(`${tabName}-settings`).classList.add('active');
    });
  });
  
  // Password update in settings
  document.getElementById('settings-update-password')?.addEventListener('click', async function() {
    const currentPassword = document.getElementById('settings-current-password').value.trim();
    const newPassword = document.getElementById('settings-new-password').value.trim();
    const confirmPassword = document.getElementById('settings-confirm-password').value.trim();
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert('Please fill in all password fields');
      return;
    }
    
    if (newPassword.length < 8) {
      alert('New password must be at least 8 characters');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    
    try {
      this.disabled = true;
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
      
      const response = await fetch('/api/profile/update-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword
        })
      });
      
      const result = await response.json();
      
      if (response.ok) {
        alert('✅ Password updated successfully!');
        document.getElementById('settings-current-password').value = '';
        document.getElementById('settings-new-password').value = '';
        document.getElementById('settings-confirm-password').value = '';
      } else {
        alert('❌ ' + (result.error || 'Failed to update password'));
      }
    } catch (error) {
      alert('❌ Error updating password: ' + error.message);
    } finally {
      this.disabled = false;
      this.innerHTML = 'Update Password';
    }
  });
  
  // ✅ FIX #2: Notification settings
  document.getElementById('save-notification-settings')?.addEventListener('click', function() {
    const settings = {
      assignments: document.getElementById('notif-assignments').checked,
      grades: document.getElementById('notif-grades').checked,
      materials: document.getElementById('notif-materials').checked,
      deadlines: document.getElementById('notif-deadlines').checked
    };
    
    localStorage.setItem('student_notification_settings', JSON.stringify(settings));
    
    alert('✅ Notification settings saved!');
  });
  
  // Privacy settings
  document.getElementById('save-privacy-settings')?.addEventListener('click', function() {
    const settings = {
      profileVisible: document.getElementById('privacy-profile').checked,
      emailVisible: document.getElementById('privacy-email').checked
    };
    
    localStorage.setItem('student_privacy_settings', JSON.stringify(settings));
    
    alert('✅ Privacy settings saved!');
  });
  
  // Clear all data
  document.getElementById('clear-all-data')?.addEventListener('click', function() {
    if (confirm('⚠️ Are you sure? This will clear ALL your data from LearnSync.\n\nThis action CANNOT be undone!')) {
      if (confirm('⚠️ FINAL WARNING: This will permanently delete all your classes, assignments, and submissions. Continue?')) {
        localStorage.removeItem('student_classes');
        localStorage.removeItem('student_notifications');
        localStorage.removeItem('student_avatar');
        localStorage.removeItem('student_notification_settings');
        localStorage.removeItem('student_privacy_settings');
        localStorage.removeItem('professor_classes');
        localStorage.removeItem('calendar_events');
        
        alert('✅ All data cleared successfully. Reloading page...');
        window.location.reload();
      }
    }
  });
  
  loadSavedSettings();
  
  document.getElementById('back-to-classes').addEventListener('click', () => {
    const classView = document.getElementById('class-view');
    classView.classList.add('hidden');
    classView.classList.remove('active');

    const classesSection = document.getElementById('classes-section');
    classesSection.classList.add('active');
  });
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tabName = this.getAttribute('data-tab');
      switchTab(tabName);
    });
  });
  
  document.getElementById('assignment-filter')?.addEventListener('change', function() {
    filterAssignments(this.value);
  });
  
  document.getElementById('grade-filter')?.addEventListener('change', function() {
    filterGrades(this.value);
  });
});

function loadSavedSettings() {
  const userType = 'student';
  
  const notifSettings = localStorage.getItem(`${userType}_notification_settings`);
  if (notifSettings) {
    try {
      const settings = JSON.parse(notifSettings);
      document.getElementById('notif-assignments').checked = settings.assignments !== false;
      document.getElementById('notif-grades').checked = settings.grades !== false;
      document.getElementById('notif-materials').checked = settings.materials !== false;
      document.getElementById('notif-deadlines').checked = settings.deadlines !== false;
    } catch (e) {
      console.error('Error loading notification settings:', e);
    }
  }
  
  const privacySettings = localStorage.getItem(`${userType}_privacy_settings`);
  if (privacySettings) {
    try {
      const settings = JSON.parse(privacySettings);
      document.getElementById('privacy-profile').checked = settings.profileVisible !== false;
      document.getElementById('privacy-email').checked = settings.emailVisible === true;
    } catch (e) {
      console.error('Error loading privacy settings:', e);
    }
  }
}

async function fetchStudentProfile() {
  try {
    const response = await fetch('/api/profile');
    if (response.ok) {
      const profile = await response.json();
      studentData = {
        id: String(profile.id),
        student_id: profile.student_id,
        name: `${profile.first_name} ${profile.last_name}`
      };
      console.log('✅ Student data loaded:', studentData);
    } else {
      console.error('❌ Failed to load profile:', response.status);
      const sessionData = document.body.dataset.studentData;
      if (sessionData) {
        studentData = JSON.parse(sessionData);
        console.log('✅ Using session student data:', studentData);
      }
    }
  } catch (error) {
    console.error('❌ Error fetching profile:', error);
  }
}

function renderArchivedClassList(archivedClasses) {
  const archivedSection = document.getElementById('archived-classes-section');
  if (!archivedSection) return;
  
  const archivedList = archivedSection.querySelector('.archived-classes-list') || 
                       document.createElement('div');
  archivedList.className = 'archived-classes-list';
  archivedList.innerHTML = '';
  
  if (archivedClasses.length === 0) {
    archivedList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-archive"></i>
        <h3>No Archived Classes</h3>
        <p>Archived classes will appear here</p>
      </div>
    `;
  } else {
    archivedClasses.forEach(classItem => {
      const classCard = document.createElement('div');
      classCard.className = 'class-card archived';
      classCard.innerHTML = `
        <div class="class-card-header">
          <h3>${classItem.name}</h3>
          <span class="class-code">${classItem.code}</span>
        </div>
        <p class="class-description">${classItem.description || 'No description provided'}</p>
        <div class="class-stats">
          <span><i class="fas fa-user-tie"></i> ${classItem.professor_name || 'Professor'}</span>
          <span><i class="fas fa-file-alt"></i> ${classItem.materials ? classItem.materials.length : 0} Materials</span>
        </div>
        <div class="class-actions">
          <button class="btn-secondary" onclick="openClass('${classItem.id}', true)">
            <i class="fas fa-eye"></i> View (Read-only)
          </button>
        </div>
      `;
      archivedList.appendChild(classCard);
    });
  }
  
  if (!archivedSection.contains(archivedList)) {
    archivedSection.appendChild(archivedList);
  }
}

async function loadEnrolledClasses() {
    try {
        const response = await fetch('/api/professor/classes?archived=false');
        if (response.ok) {
            enrolledClasses = await response.json();
            
            const professorClasses = localStorage.getItem('professor_classes');
            if (professorClasses) {
                try {
                    const profClasses = JSON.parse(professorClasses);
                    enrolledClasses = enrolledClasses.map(cls => {
                        const matchingClass = profClasses.find(pc => 
                            pc.code === cls.code && !pc.archived
                        );
                        
                        if (matchingClass) {
                            cls.assignments = matchingClass.assignments ? 
                                JSON.parse(JSON.stringify(matchingClass.assignments)) : [];
                            cls.materials = matchingClass.materials ? 
                                JSON.parse(JSON.stringify(matchingClass.materials)) : [];
                            
                            console.log(`✓ Loaded ${cls.assignments.length} assignments for ${cls.name}`);
                        }
                        return cls;
                    });
                } catch (e) {
                    console.error('✗ Error loading professor data:', e);
                }
            }
            
            console.log('✅ Loaded enrolled classes:', enrolledClasses.length);
            
            renderClassList();
            updateDashboardStats();
            updateGradeFilter();
            loadAllAssignments();
            
            // ✅ FIX #2: Check for new assignments and send notifications
            checkForNewAssignments();
            checkUpcomingDeadlines();
        } else {
            console.error('Failed to load classes:', response.status);
        }
    } catch (error) {
        console.error('Error loading classes:', error);
    }
}

// ✅ FIX #2: Check for new assignments and notify
function checkForNewAssignments() {
  const lastCheck = localStorage.getItem('student_last_assignment_check');
  const lastCheckTime = lastCheck ? new Date(lastCheck) : new Date(0);
  
  enrolledClasses.forEach(classItem => {
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const assignmentDate = new Date(assignment.dateCreated || assignment.dueDate);
        
        if (assignmentDate > lastCheckTime) {
          addNotification(
            'assignment',
            'New Assignment Posted',
            `"${assignment.title}" in ${classItem.name}`,
            `class:${classItem.id}`
          );
        }
      });
    }
    
    // Check for new materials
    if (classItem.materials) {
      classItem.materials.forEach(material => {
        const materialDate = new Date(material.date);
        
        if (materialDate > lastCheckTime) {
          addNotification(
            'material',
            'New Material Uploaded',
            `"${material.title}" in ${classItem.name}`,
            `class:${classItem.id}`
          );
        }
      });
    }
  });
  
  localStorage.setItem('student_last_assignment_check', new Date().toISOString());
}

// ✅ FIX #2: Check for upcoming deadlines
function checkUpcomingDeadlines() {
  const now = new Date();
  const threeDaysFromNow = new Date(now.getTime() + (3 * 24 * 60 * 60 * 1000));
  
  enrolledClasses.forEach(classItem => {
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const dueDate = new Date(assignment.dueDate);
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => String(s.studentId) === String(studentData.id)) : null;
        
        // Only notify if not submitted and deadline is within 3 days
        if (!submission && dueDate > now && dueDate <= threeDaysFromNow) {
          const daysUntil = Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24));
          
          addNotification(
            'deadline',
            'Upcoming Deadline',
            `"${assignment.title}" due in ${daysUntil} day${daysUntil > 1 ? 's' : ''} (${classItem.name})`,
            `class:${classItem.id}`
          );
        }
      });
    }
  });
}

async function loadArchivedClasses() {
  try {
    const response = await fetch('/api/professor/classes?archived=true');
    if (response.ok) {
      const archivedClasses = await response.json();
      renderArchivedClassList(archivedClasses);
    }
  } catch (error) {
    console.error('Error loading archived classes:', error);
  }
}

function showJoinClassModal() {
  document.getElementById('join-class-modal').style.display = 'flex';
}

function hideJoinClassModal() {
  document.getElementById('join-class-modal').style.display = 'none';
  document.getElementById('class-code-input').value = '';
}

async function joinClass() {
  const classCode = document.getElementById('class-code-input').value.trim().toUpperCase();
  
  if (!classCode) {
    alert('Please enter a class code');
    return;
  }
  
  try {
    const response = await fetch('/api/student/join_class', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code: classCode })
    });

    const result = await response.json();

    if (response.ok) {
      alert(`Successfully joined ${result.class.name}!`);
      
      // ✅ FIX #2: Add notification for successful enrollment
      addNotification(
        'enrollment',
        'Successfully Joined Class',
        `You are now enrolled in ${result.class.name}`,
        `class:${result.class.id}`
      );
      
      hideJoinClassModal();
      await loadEnrolledClasses();
    } else {
      alert(result.error || 'Failed to join class');
    }
  } catch (error) {
    console.error('Error joining class:', error);
    alert('Error joining class. Please try again.');
  }
}

function renderClassList() {
  const classList = document.getElementById('class-list');
  classList.innerHTML = '';
  
  if (enrolledClasses.length === 0) {
    classList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-book-open"></i>
        <h3>No Classes Enrolled</h3>
        <p>Join a class using a class code from your professor</p>
      </div>
    `;
    return;
  }
  
  enrolledClasses.forEach(classItem => {
    const pendingAssignments = classItem.assignments ? 
      classItem.assignments.filter(a => {
        const submission = a.submissions ? a.submissions.find(s => s.studentId === String(studentData.id)) : null;
        return !submission && new Date(a.dueDate) > new Date();
      }).length : 0;
    
    const classCard = document.createElement('div');
    classCard.className = 'class-card';
    classCard.innerHTML = `
      <div class="class-card-header">
        <h3>${classItem.name}</h3>
        <span class="class-code">${classItem.code}</span>
      </div>
      <p class="class-description">${classItem.description || 'No description provided'}</p>
      <div class="class-stats">
        <span><i class="fas fa-user-tie"></i> ${classItem.professor_name || 'Professor'}</span>
        <span><i class="fas fa-file-alt"></i> ${classItem.materials ? classItem.materials.length : 0} Materials</span>
        <span><i class="fas fa-tasks"></i> ${pendingAssignments} Pending</span>
      </div>
      <div class="class-actions">
        <button class="btn-primary" onclick="openClass('${classItem.id}', false)">Open Class</button>
        <button class="btn-secondary" onclick="unenrollClass('${classItem.id}')">
          <i class="fas fa-sign-out-alt"></i> Unenroll
        </button>
      </div>
    `;
    classList.appendChild(classCard);
  });
}

async function unenrollClass(classId) {
  if (!confirm('Are you sure you want to unenroll from this class?')) {
    return;
  }

  try {
    const response = await fetch('/api/student/unenroll_class', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ class_id: classId })
    });

    const result = await response.json();

    if (response.ok) {
      alert('Successfully unenrolled from class!');
      await loadEnrolledClasses();
    } else {
      alert(result.error || 'Failed to unenroll from class');
    }
  } catch (error) {
    console.error('Error unenrolling from class:', error);
    alert('Error unenrolling from class. Please try again.');
  }
}

// ✅ FIX #1: Open class view with archived support
function openClass(classId, isArchived = false) {
  currentClassId = classId;
  
  // Try to find in enrolled classes first
  let classItem = enrolledClasses.find(c => c.id === classId);
  
  // If not found and isArchived, load archived classes
  if (!classItem && isArchived) {
    fetch('/api/professor/classes?archived=true')
      .then(response => response.json())
      .then(archivedClasses => {
        classItem = archivedClasses.find(c => c.id === classId);
        if (classItem) {
          displayClassView(classItem, true);
        } else {
          alert('❌ Class not found');
        }
      })
      .catch(error => {
        console.error('Error loading archived class:', error);
        alert('❌ Error loading class');
      });
    return;
  }
  
  if (!classItem) {
    alert('❌ Class not found');
    return;
  }
  
  displayClassView(classItem, isArchived);
}

// ✅ FIX #1: Display class view (separated for clarity)
function displayClassView(classItem, isArchived = false) {
  document.getElementById('class-title').textContent = classItem.name + (isArchived ? ' (Archived)' : '');
  document.getElementById('class-desc').textContent = classItem.description;
  document.getElementById('class-professor').textContent = classItem.professor_name || 'Professor';

  if (!isArchived) {
    const professorClasses = localStorage.getItem('professor_classes');
    if (professorClasses) {
      try {
        const profClasses = JSON.parse(professorClasses);
        const matchingClass = profClasses.find(pc => pc.code === classItem.code);
        if (matchingClass) {
          if (matchingClass.assignments) {
            classItem.assignments = matchingClass.assignments;
          }
          if (matchingClass.materials) {
            classItem.materials = matchingClass.materials;
          }
        }
      } catch (e) {
        console.error('Error loading professor data:', e);
      }
    }
  }

  const materialsCount = classItem.materials ? classItem.materials.length : 0;
  const assignmentsCount = classItem.assignments ? classItem.assignments.length : 0;
  
  document.getElementById('class-materials').textContent = materialsCount;
  document.getElementById('class-assignments').textContent = assignmentsCount;

  document.querySelectorAll('.content-section').forEach(section => section.classList.remove('active'));

  const classView = document.getElementById('class-view');
  classView.classList.remove('hidden');
  classView.classList.add('active');
  
  // ✅ FIX #1: Add archived indicator to class view
  if (isArchived) {
    classView.dataset.archived = 'true';
    // Disable submission buttons for archived classes
    const assignmentTabs = document.querySelectorAll('.tab-btn');
    assignmentTabs.forEach(tab => {
      if (tab.dataset.tab === 'assignments') {
        tab.style.opacity = '0.6';
      }
    });
  } else {
    delete classView.dataset.archived;
  }

  loadClassPosts();
  loadClassAssignments(isArchived);
  loadClassGrades();
}

function switchTab(tabName) {
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  
  document.getElementById(`${tabName}-tab`).classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
}

function loadClassPosts() {
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  const postsContainer = document.getElementById('posts-container');
  
  if (!classItem || !postsContainer) return;
  
  postsContainer.innerHTML = '';
  
  const professorClasses = localStorage.getItem('professor_classes');
  if (professorClasses) {
    try {
      const profClasses = JSON.parse(professorClasses);
      const matchingClass = profClasses.find(pc => pc.code === classItem.code);
      if (matchingClass && matchingClass.materials) {
        classItem.materials = matchingClass.materials;
      }
    } catch (e) {
      console.error('Error loading professor materials:', e);
    }
  }
  
  if (!classItem.materials || classItem.materials.length === 0) {
    postsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-file-upload"></i>
        <h3>No Materials Posted</h3>
        <p>Check back later for class materials</p>
      </div>
    `;
    return;
  }
  
  classItem.materials.forEach(material => {
    const postElement = document.createElement('div');
    postElement.className = 'post-card';
    postElement.innerHTML = `
      <div class="post-header">
        <h4>${material.title}</h4>
        <span class="post-date">${new Date(material.date).toLocaleDateString()}</span>
      </div>
      <p class="post-description">${material.description}</p>
      ${material.deadline ? `<p class="post-deadline"><strong>Deadline:</strong> ${new Date(material.deadline).toLocaleDateString()}</p>` : ''}
      ${material.resourceLink ? `<p class="post-link"><a href="${material.resourceLink}" target="_blank">${material.resourceLink}</a></p>` : ''}
      ${material.files && material.files.length > 0 ? `
        <div class="post-files">
          <strong>Attached Files:</strong>
          <ul>
            ${material.files.map(file => `
              <li>
                <a href="#" onclick="downloadFile('${file.name.replace(/'/g, "\\'")}', '${file.url || file.content}'); return false;">
                  <i class="fas fa-download"></i> ${file.name} (${(file.size / 1024 / 1024).toFixed(2)}MB)
                </a>
              </li>
            `).join('')}
          </ul>
        </div>
      ` : ''}
    `;
    postsContainer.appendChild(postElement);
  });
}

function loadClassAssignments(isArchived = false) {
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  const assignmentsContainer = document.getElementById('assignments-container');
  
  if (!classItem || !assignmentsContainer) return;
  
  assignmentsContainer.innerHTML = '';
  
  if (!isArchived) {
    const professorClasses = localStorage.getItem('professor_classes');
    if (professorClasses) {
      try {
        const profClasses = JSON.parse(professorClasses);
        const matchingClass = profClasses.find(pc => pc.code === classItem.code);
        if (matchingClass && matchingClass.assignments) {
          classItem.assignments = matchingClass.assignments;
          console.log('✅ Loaded assignments from professor data:', classItem.assignments.length);
        }
      } catch (e) {
        console.error('Error loading professor assignments:', e);
      }
    }
  }
  
  if (!classItem.assignments || classItem.assignments.length === 0) {
    assignmentsContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No Assignments</h3>
        <p>No assignments have been posted for this class yet</p>
      </div>
    `;
    return;
  }
  
  // ✅ SORT BY CREATION DATE (NEWEST FIRST)
  const sortedAssignments = [...classItem.assignments].sort((a, b) => {
    const dateA = new Date(a.dateCreated || a.dueDate);
    const dateB = new Date(b.dateCreated || b.dueDate);
    return dateB - dateA;
  });
  
  sortedAssignments.forEach(assignment => {
    const submission = assignment.submissions ? 
      assignment.submissions.find(s => String(s.studentId) === String(studentData.id)) : null;
    
    const isSubmitted = !!submission;
    const isGraded = isSubmitted && submission.grade !== undefined;
    const isOverdue = new Date(assignment.dueDate) < new Date() && !isSubmitted;
    
    // ✅ SEPARATE VIDEO AND NON-VIDEO FILES
    const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
    const videoFiles = [];
    const otherFiles = [];
    
    if (assignment.files && assignment.files.length > 0) {
      assignment.files.forEach(file => {
        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (videoExtensions.includes(fileExtension)) {
          videoFiles.push(file);
        } else {
          otherFiles.push(file);
        }
      });
    }
    
    const assignmentElement = document.createElement('div');
    assignmentElement.className = `assignment-card ${isOverdue ? 'overdue' : ''} ${isGraded ? 'graded' : ''}`;
    assignmentElement.innerHTML = `
      <div class="assignment-header">
        <h4>${assignment.title}</h4>
        <span class="due-date ${isOverdue ? 'overdue' : ''}">
          Due: ${new Date(assignment.dueDate).toLocaleDateString()}
          ${isOverdue ? ' (Overdue)' : ''}
        </span>
      </div>
      <p class="assignment-description">${assignment.description}</p>
      <div class="assignment-details">
        <span><i class="fas fa-file-alt"></i> ${assignment.points} Points</span>
        <span class="status ${isGraded ? 'graded' : isSubmitted ? 'submitted' : 'pending'}">
          <i class="fas fa-${isGraded ? 'check-circle' : isSubmitted ? 'clock' : 'exclamation-circle'}"></i>
          ${isGraded ? 'Graded' : isSubmitted ? 'Submitted' : 'Not Submitted'}
        </span>
        ${isGraded ? `<span class="grade">Grade: ${submission.grade}/${assignment.points}</span>` : ''}
      </div>
      
      ${videoFiles.length > 0 ? `
        <div class="assignment-videos" style="margin: 1.5rem 0; padding: 1.5rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);">
          <strong style="color: white; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem; font-size: 1.1rem;">
            <i class="fas fa-video"></i> Video Resources:
          </strong>
          <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            ${videoFiles.map(file => {
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <button 
                  onclick="downloadFile('${escapedName}', '${escapedSource}')" 
                  style="display: flex; align-items: center; gap: 1rem; padding: 1rem 1.25rem; background: rgba(255, 255, 255, 0.95); border: none; border-radius: 8px; cursor: pointer; transition: all 0.3s ease; text-align: left; box-shadow: 0 2px 8px rgba(0,0,0,0.1);"
                  onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.2)'"
                  onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.1)'">
                  <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <i class="fas fa-play" style="color: white; font-size: 1.5rem;"></i>
                  </div>
                  <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 600; color: #2d3748; font-size: 1rem; margin-bottom: 0.25rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                      ${file.name}
                    </div>
                    <div style="color: #718096; font-size: 0.875rem;">
                      ${file.size ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : 'Video file'}
                    </div>
                  </div>
                  <i class="fas fa-chevron-right" style="color: #cbd5e0; font-size: 1.2rem;"></i>
                </button>
              `;
            }).join('')}
          </div>
        </div>
      ` : ''}
      
      ${otherFiles.length > 0 ? `
        <div class="assignment-files">
          <strong>Other Resources:</strong>
          <ul>
            ${otherFiles.map(file => {
              const fileSource = file.url || file.content || '';
              const escapedName = file.name.replace(/'/g, "\\'");
              const escapedSource = fileSource.replace(/'/g, "\\'");
              
              return `
                <li>
                  <a href="#" onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;">
                    <i class="fas fa-download"></i> ${file.name}
                  </a>
                </li>
              `;
            }).join('')}
          </ul>
        </div>
      ` : ''}
      
      ${assignment.instructions ? `
        <div class="assignment-instructions">
          <strong>Instructions:</strong>
          <p>${assignment.instructions}</p>
        </div>
      ` : ''}
      <div class="assignment-actions">
        ${!isSubmitted && !isArchived ? `
          <button class="btn-primary" onclick="openSubmissionModal('${assignment.id}')">
            <i class="fas fa-paper-plane"></i> Submit Assignment
          </button>
        ` : isSubmitted ? `
          <button class="btn-secondary" onclick="viewSubmission('${assignment.id}')">
            <i class="fas fa-eye"></i> View Submission
          </button>
        ` : ''}
        ${isArchived ? `
          <span style="color: #999; font-style: italic;"><i class="fas fa-lock"></i> Class Archived - Read Only</span>
        ` : ''}
        ${isGraded && submission.feedback ? `
          <button class="btn-outline" onclick="viewFeedback('${assignment.id}')">
            <i class="fas fa-comment"></i> View Feedback
          </button>
        ` : ''}
      </div>
    `;
    assignmentsContainer.appendChild(assignmentElement);
  });
}

function openSubmissionModal(assignmentId) {
  console.log('📝 Opening submission modal for assignment:', assignmentId);
  
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  if (!classItem) {
    alert('❌ Error: Class not found');
    return;
  }
  
  const assignment = classItem.assignments ? classItem.assignments.find(a => a.id === assignmentId) : null;
  if (!assignment) {
    alert('❌ Error: Assignment not found');
    return;
  }
  
  const modal = document.getElementById('submission-modal');
  modal.dataset.assignmentId = assignmentId;
  
  document.getElementById('submission-text').value = '';
  document.getElementById('submission-files').value = '';
  document.getElementById('submission-files-chosen').textContent = 'No files selected';
  
  modal.style.display = 'flex';
  
  setTimeout(() => {
    document.getElementById('submission-text').focus();
  }, 100);
  
  console.log('✅ Submission modal opened');
}

async function submitAssignment() {
  console.log('📤 submitAssignment() called');
  
  const modal = document.getElementById('submission-modal');
  const assignmentId = modal.dataset.assignmentId;
  const submissionText = document.getElementById('submission-text').value.trim();
  const filesInput = document.getElementById('submission-files');
  
  if (!studentData || !studentData.id) {
    console.error('❌ Student data not loaded');
    alert('❌ Error: Student profile not loaded. Please refresh the page and try again.');
    return;
  }
  
  console.log('👤 Student ID:', studentData.id);
  console.log('📝 Assignment ID:', assignmentId);
  console.log('📄 Submission text length:', submissionText.length);
  
  if (!submissionText) {
    alert('⚠️ Please enter your submission text');
    document.getElementById('submission-text').focus();
    return;
  }
  
  if (submissionText.length < 10) {
    alert('⚠️ Submission text is too short. Please provide more detail.');
    document.getElementById('submission-text').focus();
    return;
  }
  
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  if (!classItem) {
    console.error('❌ Class not found:', currentClassId);
    alert('❌ Error: Class not found. Please refresh and try again.');
    return;
  }
  
  console.log('📚 Class found:', classItem.name);
  
  const professorClasses = localStorage.getItem('professor_classes');
  if (professorClasses) {
    try {
      const profClasses = JSON.parse(professorClasses);
      const matchingClass = profClasses.find(pc => pc.code === classItem.code);
      if (matchingClass && matchingClass.assignments) {
        classItem.assignments = matchingClass.assignments;
        console.log('✅ Loaded assignments from professor data');
      }
    } catch (e) {
      console.error('❌ Error loading professor assignments:', e);
    }
  }
  
  const assignment = classItem.assignments ? classItem.assignments.find(a => a.id === assignmentId) : null;
  if (!assignment) {
    console.error('❌ Assignment not found:', assignmentId);
    alert('❌ Error: Assignment not found. It may have been deleted by the professor.');
    return;
  }
  
  console.log('📋 Assignment found:', assignment.title);
  
  const existingSubmission = assignment.submissions ? 
    assignment.submissions.find(s => String(s.studentId) === String(studentData.id)) : null;
  
  if (existingSubmission) {
    const confirm = window.confirm('⚠️ You have already submitted this assignment. Do you want to resubmit?');
    if (!confirm) {
      return;
    }
  }
  
  const submission = {
    studentId: String(studentData.id),
    studentName: studentData.name,
    content: submissionText,
    date: new Date().toISOString(),
    files: []
  };
  
  console.log('📦 Created submission object:', submission);
  
  if (filesInput && filesInput.files && filesInput.files.length > 0) {
    try {
      console.log(`📎 Uploading ${filesInput.files.length} file(s)...`);
      
      const submitBtn = document.getElementById('submit-assignment');
      const originalText = submitBtn.innerHTML;
      
      for (let i = 0; i < filesInput.files.length; i++) {
        const file = filesInput.files[i];
        console.log(`⬆️ Uploading file ${i + 1}/${filesInput.files.length}: ${file.name}`);
        
        submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Uploading ${i + 1}/${filesInput.files.length}...`;
        
        const formData = new FormData();
        formData.append('file', file);
        
        try {
          const response = await fetch('/api/upload_file', {
            method: 'POST',
            body: formData
          });
          
          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Failed to upload ${file.name}`);
          }
          
          const result = await response.json();
          
          submission.files.push({
            name: file.name,
            type: file.type,
            size: file.size,
            url: result.url
          });
          
          console.log(`✅ File uploaded: ${file.name}`);
          
        } catch (fileError) {
          console.error(`❌ Error uploading ${file.name}:`, fileError);
          throw new Error(`Failed to upload ${file.name}: ${fileError.message}`);
        }
      }
      
      submitBtn.innerHTML = originalText;
      console.log('✅ All files uploaded successfully');
      
    } catch (uploadError) {
      console.error('❌ Error during file upload:', uploadError);
      alert('❌ Error uploading files: ' + uploadError.message);
      return;
    }
  }
  
  try {
    await saveSubmission(assignment, submission, classItem);
    console.log('✅ Submission saved successfully');
  } catch (saveError) {
    console.error('❌ Error saving submission:', saveError);
    alert('❌ Error saving submission: ' + saveError.message);
    return;
  }
}

async function saveSubmission(assignment, submission, classItem) {
  console.log('💾 saveSubmission() called');
  
  try {
    if (!assignment.submissions) {
      assignment.submissions = [];
    }
    
    const existingIndex = assignment.submissions.findIndex(s => 
      String(s.studentId) === String(submission.studentId)
    );
    
    if (existingIndex !== -1) {
      assignment.submissions[existingIndex] = submission;
      console.log('✅ Updated existing submission');
    } else {
      assignment.submissions.push(submission);
      console.log('✅ Added new submission');
    }
    
    const professorClasses = localStorage.getItem('professor_classes');
    if (professorClasses) {
      const profClasses = JSON.parse(professorClasses);
      const profClassIndex = profClasses.findIndex(pc => pc.code === classItem.code);
      
      if (profClassIndex !== -1) {
        if (!profClasses[profClassIndex].assignments) {
          profClasses[profClassIndex].assignments = [];
        }
        
        const profAssignmentIndex = profClasses[profClassIndex].assignments.findIndex(a => a.id === assignment.id);
        
        if (profAssignmentIndex !== -1) {
          profClasses[profClassIndex].assignments[profAssignmentIndex].submissions = assignment.submissions;
          console.log('✅ Updated submissions in professor data');
        } else {
          console.warn('⚠️ Assignment not found in professor data');
        }
        
        try {
          localStorage.setItem('professor_classes', JSON.stringify(profClasses));
          console.log('✅ Saved to localStorage');
        } catch (storageError) {
          if (storageError.name === 'QuotaExceededError') {
            console.error('⚠️ Storage quota exceeded');
            throw new Error('Storage full. Please ask your professor to clear old data, or avoid uploading large files.');
          } else {
            throw storageError;
          }
        }
      } else {
        console.warn('⚠️ Class not found in professor data');
      }
    } else {
      console.warn('⚠️ No professor classes data found');
    }
    
    await loadClassAssignments();
    await loadAllAssignments();
    updateDashboardStats();
    
    const modal = document.getElementById('submission-modal');
    if (modal) {
      modal.style.display = 'none';
      document.getElementById('submission-text').value = '';
      document.getElementById('submission-files').value = '';
      document.getElementById('submission-files-chosen').textContent = 'No files selected';
    }
    
    // ✅ FIX #2: Add notification for submission
    addNotification(
      'submission',
      'Assignment Submitted',
      `Successfully submitted "${assignment.title}" to ${classItem.name}`,
      `class:${currentClassId}`
    );
    
    alert(`✅ Assignment submitted successfully!\n\nAssignment: ${assignment.title}\nClass: ${classItem.name}\nSubmitted: ${new Date().toLocaleString()}`);
    
  } catch (error) {
    console.error('❌ Error in saveSubmission:', error);
    throw error;
  }
}

function viewSubmission(assignmentId) {
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const assignment = classItem.assignments.find(a => a.id === assignmentId);
  if (!assignment) return;
  
  const submission = assignment.submissions.find(s => String(s.studentId) === String(studentData.id));
  if (!submission) return;
  
  const dueDate = new Date(assignment.dueDate);
  const isPastDue = new Date() > dueDate;
  const isGraded = submission.grade !== undefined;
  
  const existingModal = document.getElementById('view-submission-modal');
  if (existingModal) {
    existingModal.remove();
  }
  
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.style.display = 'flex';
  modal.id = 'view-submission-modal';
  
  let modalHTML = `
    <div class="modal-content" style="max-width: 700px; max-height: 90vh; overflow-y: auto;">
      <div class="modal-header">
        <h3><i class="fas fa-file-alt"></i> Your Submission</h3>
        <button class="close-btn" onclick="closeViewSubmissionModal()">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body" style="padding: 2rem;">
        <div style="margin-bottom: 1.5rem;">
          <strong style="color: #333; display: block; margin-bottom: 0.5rem;">
            <i class="fas fa-clock"></i> Submitted:
          </strong>
          <p style="padding: 0.75rem; background: #f8f9fa; border-radius: 6px;">
            ${new Date(submission.date).toLocaleString()}
          </p>
        </div>
        
        <div style="margin-bottom: 1.5rem;">
          <strong style="color: #333; display: block; margin-bottom: 0.5rem;">
            <i class="fas fa-file-alt"></i> Content:
          </strong>
          <div style="padding: 1.25rem; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #4a90a4; white-space: pre-wrap; line-height: 1.6;">
            ${submission.content || 'No content provided'}
          </div>
        </div>
  `;
  
  if (submission.files && submission.files.length > 0) {
    modalHTML += `
      <div style="margin-bottom: 1.5rem;">
        <strong style="color: #333; display: block; margin-bottom: 0.75rem;">
          <i class="fas fa-paperclip"></i> Attached Files:
        </strong>
        <div style="display: flex; flex-wrap: wrap; gap: 0.75rem;">
          ${submission.files.map(file => {
            const fileSource = file.url || file.content || '';
            const escapedName = file.name.replace(/'/g, "\\'");
            const escapedSource = fileSource.replace(/'/g, "\\'");
            
            return `
              <a href="#" 
                onclick="downloadFile('${escapedName}', '${escapedSource}'); return false;" 
                style="display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1rem; background: #e8f4f8; color: #4a90a4; text-decoration: none; border-radius: 6px; font-size: 0.9rem; font-weight: 500; transition: all 0.2s ease;"
                onmouseover="this.style.background='#d0e8f0'; this.style.transform='translateY(-2px)'"
                onmouseout="this.style.background='#e8f4f8'; this.style.transform='translateY(0)'">
                <i class="fas fa-download"></i> ${file.name}
              </a>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  if (isGraded) {
    const percentage = ((submission.grade / assignment.points) * 100).toFixed(1);
    let gradeColor = '#dc3545';
    if (percentage >= 80) gradeColor = '#28a745';
    else if (percentage >= 60) gradeColor = '#fd7e14';
    
    modalHTML += `
      <div style="margin-bottom: 1.5rem;">
        <strong style="color: #333; display: block; margin-bottom: 0.5rem;">
          <i class="fas fa-star"></i> Grade:
        </strong>
        <div style="padding: 1rem; background: ${gradeColor}20; border-radius: 6px; color: ${gradeColor}; font-size: 1.1rem; font-weight: 600; border: 2px solid ${gradeColor};">
          ${submission.grade}/${assignment.points} (${percentage}%)
        </div>
      </div>
    `;
  } else {
    modalHTML += `
      <div style="margin-bottom: 1.5rem;">
        <div style="padding: 1rem; background: #fff3cd; border-radius: 6px; color: #856404; font-weight: 500;">
          <i class="fas fa-hourglass-half"></i> Not graded yet
        </div>
      </div>
    `;
  }
  
  if (submission.feedback) {
    modalHTML += `
      <div style="margin-bottom: 1.5rem;">
        <strong style="color: #333; display: block; margin-bottom: 0.5rem;">
          <i class="fas fa-comment"></i> Feedback:
        </strong>
        <div style="padding: 1.25rem; background: #e8f4f8; border-radius: 8px; border-left: 4px solid #17a2b8; line-height: 1.6;">
          ${submission.feedback}
        </div>
      </div>
    `;
  }
  
  if (!isGraded && !isPastDue) {
    modalHTML += `
      <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 2px solid #e0e0e0;">
        <button onclick="unsubmitAssignment('${assignmentId}')" class="btn-danger" style="width: 100%;">
          <i class="fas fa-undo"></i> Unsubmit Assignment
        </button>
        <small style="display: block; text-align: center; margin-top: 0.5rem; color: #666;">
          You can unsubmit and resubmit before the deadline
        </small>
      </div>
    `;
  } else if (isGraded) {
    modalHTML += `
      <div style="margin-top: 1rem; text-align: center; color: #666; font-size: 0.9rem;">
        <i class="fas fa-lock"></i> Cannot unsubmit - assignment has been graded
      </div>
    `;
  } else if (isPastDue) {
    modalHTML += `
      <div style="margin-top: 1rem; text-align: center; color: #666; font-size: 0.9rem;">
        <i class="fas fa-lock"></i> Cannot unsubmit - deadline has passed
      </div>
    `;
  }
  
  modalHTML += `
      </div>
    </div>
  `;
  
  modal.innerHTML = modalHTML;
  document.body.appendChild(modal);
  
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeViewSubmissionModal();
    }
  });
}

function closeViewSubmissionModal() {
  const modal = document.getElementById('view-submission-modal');
  if (modal) {
    modal.remove();
  }
}

function unsubmitAssignment(assignmentId) {
  if (!confirm('Are you sure you want to unsubmit this assignment? You can submit again before the deadline.')) {
    return;
  }
  
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  if (!classItem) return;
  
  const assignment = classItem.assignments.find(a => a.id === assignmentId);
  if (!assignment) return;
  
  const dueDate = new Date(assignment.dueDate);
  if (new Date() > dueDate) {
    alert('Cannot unsubmit - assignment deadline has passed.');
    return;
  }
  
  try {
    if (assignment.submissions) {
      assignment.submissions = assignment.submissions.filter(
        s => String(s.studentId) !== String(studentData.id)
      );
    }
    
    const professorClasses = localStorage.getItem('professor_classes');
    if (professorClasses) {
      const profClasses = JSON.parse(professorClasses);
      const profClassIndex = profClasses.findIndex(pc => pc.code === classItem.code);
      
      if (profClassIndex !== -1) {
        const profAssignmentIndex = profClasses[profClassIndex].assignments.findIndex(a => a.id === assignmentId);
        if (profAssignmentIndex !== -1) {
          profClasses[profClassIndex].assignments[profAssignmentIndex].submissions = assignment.submissions;
          localStorage.setItem('professor_classes', JSON.stringify(profClasses));
        }
      }
    }
    
    loadClassAssignments();
    loadAllAssignments();
    updateDashboardStats();
    
    alert('✅ Submission removed successfully! You can submit again before the deadline.');
    
    addNotification(
      'submission',
      'Assignment Unsubmitted',
      `You unsubmitted "${assignment.title}"`,
      `class:${currentClassId}`
    );
    
  } catch (error) {
    console.error('Error unsubmitting:', error);
    alert('❌ Failed to unsubmit assignment: ' + error.message);
  }
}

function loadClassGrades() {
  const classItem = enrolledClasses.find(c => c.id === currentClassId);
  const gradesContainer = document.getElementById('grades-container');
  
  if (!classItem || !gradesContainer) return;
  
  gradesContainer.innerHTML = '';
  
  if (!classItem.assignments || classItem.assignments.length === 0) {
    gradesContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-chart-line"></i>
        <h3>No Grades Available</h3>
        <p>Grades will appear here once assignments are graded</p>
      </div>
    `;
    return;
  }
  
  let gradesHTML = `
    <div class="grades-table">
      <table>
        <thead>
          <tr>
            <th>Assignment</th>
            <th>Due Date</th>
            <th>Points</th>
            <th>Your Grade</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
  `;
  
  let totalEarned = 0;
  let totalPossible = 0;
  let gradedCount = 0;
  
  classItem.assignments.forEach(assignment => {
    const submission = assignment.submissions ? 
      assignment.submissions.find(s => s.studentId === String(studentData.id)) : null;
    
    const isSubmitted = !!submission;
    const isGraded = isSubmitted && submission.grade !== undefined;
    
    if (isGraded) {
      totalEarned += submission.grade;
      totalPossible += assignment.points;
      gradedCount++;
    }
    
    gradesHTML += `
      <tr>
        <td>${assignment.title}</td>
        <td>${new Date(assignment.dueDate).toLocaleDateString()}</td>
        <td>${assignment.points}</td>
        <td>${isGraded ? `${submission.grade}/${assignment.points}` : '-'}</td>
        <td class="status ${isGraded ? 'graded' : isSubmitted ? 'submitted' : 'pending'}">
          ${isGraded ? 'Graded' : isSubmitted ? 'Submitted' : 'Not Submitted'}
        </td>
      </tr>
    `;
  });
  
  gradesHTML += `
        </tbody>
      </table>
    </div>
  `;
  
  if (gradedCount > 0) {
    const classAverage = (totalEarned / totalPossible * 100).toFixed(2);
    gradesHTML = `
      <div class="class-average">
        <h4>Class Average: ${classAverage}%</h4>
        <p>${gradedCount} assignment(s) graded</p>
      </div>
    ` + gradesHTML;
  }
  
  gradesContainer.innerHTML = gradesHTML;
}

function loadAllAssignments() {
  const assignmentsList = document.getElementById('assignments-list');
  if (!assignmentsList) return;
  
  const filter = document.getElementById('assignment-filter') ? 
                 document.getElementById('assignment-filter').value : 'all';
  
  assignmentsList.innerHTML = '';
  
  let allAssignments = [];
  
  const professorClasses = localStorage.getItem('professor_classes');
  let profClasses = [];
  if (professorClasses) {
    try {
      profClasses = JSON.parse(professorClasses);
      console.log('✅ Professor classes loaded:', profClasses.length);
    } catch (e) {
      console.error('Error loading professor assignments:', e);
    }
  }
  
  enrolledClasses.forEach(classItem => {
    const matchingClass = profClasses.find(pc => pc.code === classItem.code);
    const assignments = matchingClass && matchingClass.assignments ? 
                       matchingClass.assignments : (classItem.assignments || []);
    
    console.log(`Class ${classItem.name}: ${assignments.length} assignments`);
    
    if (assignments && assignments.length > 0) {
      assignments.forEach(assignment => {
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => String(s.studentId) === String(studentData.id)) : null;
        
        allAssignments.push({
          ...assignment,
          className: classItem.name,
          classId: classItem.id,
          isSubmitted: !!submission,
          isGraded: !!submission && submission.grade !== undefined,
          isOverdue: new Date(assignment.dueDate) < new Date() && !submission,
          submission: submission
        });
      });
    }
  });
  
  console.log('✅ Total assignments found:', allAssignments.length);
  
  if (filter === 'pending') {
    allAssignments = allAssignments.filter(a => !a.isSubmitted && !a.isOverdue);
  } else if (filter === 'submitted') {
    allAssignments = allAssignments.filter(a => a.isSubmitted && !a.isGraded);
  } else if (filter === 'graded') {
    allAssignments = allAssignments.filter(a => a.isGraded);
  }
  
  allAssignments.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
  
  if (allAssignments.length === 0) {
    assignmentsList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No Assignments</h3>
        <p>${filter !== 'all' ? `No ${filter} assignments` : 'No assignments found'}</p>
      </div>
    `;
    return;
  }
  
  allAssignments.forEach(assignment => {
    const assignmentElement = document.createElement('div');
    assignmentElement.className = `assignment-item ${assignment.isOverdue ? 'overdue' : ''} ${assignment.isGraded ? 'graded' : ''}`;
    assignmentElement.innerHTML = `
      <div class="assignment-info">
        <h4>${assignment.title}</h4>
        <p class="class-name">${assignment.className}</p>
        <p class="assignment-description">${assignment.description}</p>
        <div class="assignment-meta">
          <span class="due-date ${assignment.isOverdue ? 'overdue' : ''}">
            <i class="fas fa-clock"></i> Due: ${new Date(assignment.dueDate).toLocaleDateString()}
            ${assignment.isOverdue ? ' (Overdue)' : ''}
          </span>
          <span class="points"><i class="fas fa-file-alt"></i> ${assignment.points} Points</span>
        </div>
      </div>
      <div class="assignment-status">
        <span class="status ${assignment.isGraded ? 'graded' : assignment.isSubmitted ? 'submitted' : 'pending'}">
          ${assignment.isGraded ? 'Graded' : assignment.isSubmitted ? 'Submitted' : 'Not Submitted'}
        </span>
        ${assignment.isGraded ? `
          <span class="grade">${assignment.submission.grade}/${assignment.points}</span>
        ` : ''}
        <div class="assignment-actions">
          ${!assignment.isSubmitted ? `
            <button class="btn-primary" onclick="openClass('${assignment.classId}'); setTimeout(() => switchTab('assignments'), 300);">
              Submit
            </button>
          ` : `
            <button class="btn-secondary" onclick="openClass('${assignment.classId}'); setTimeout(() => switchTab('assignments'), 300);">
              View
            </button>
          `}
        </div>
      </div>
    `;
    assignmentsList.appendChild(assignmentElement);
  });
}

function filterAssignments(filter) {
  loadAllAssignments();
}

function downloadFile(filename, urlOrContent) {
    console.log('📥 Downloading file:', filename);
    
    if (urlOrContent && urlOrContent.startsWith('/uploads/')) {
        const link = document.createElement('a');
        link.href = urlOrContent;
        link.download = filename;
        link.target = '_blank';
        
        document.body.appendChild(link);
        link.click();
        
        setTimeout(() => {
            document.body.removeChild(link);
        }, 100);
        
        return;
    }
    
    if (urlOrContent && urlOrContent.startsWith('data:')) {
        try {
            const link = document.createElement('a');
            link.href = urlOrContent;
            link.download = filename;
            
            document.body.appendChild(link);
            link.click();
            
            setTimeout(() => {
                document.body.removeChild(link);
            }, 100);
            
        } catch (e) {
            console.error('❌ Error downloading file:', e);
            alert('Error downloading file: ' + e.message);
        }
        return;
    }
    
    console.error('❌ Invalid file format:', urlOrContent ? urlOrContent.substring(0, 50) : 'empty');
    alert('⚠️ Invalid file format. Please contact your professor.');
}

function updateGradeFilter() {
  const gradeFilter = document.getElementById('grade-filter');
  if (!gradeFilter) return;
  
  gradeFilter.innerHTML = '<option value="all">All Classes</option>';
  
  enrolledClasses.forEach(classItem => {
    const option = document.createElement('option');
    option.value = classItem.id;
    option.textContent = classItem.name;
    gradeFilter.appendChild(option);
  });
}

function initializeCalendar() {
  const monthYear = document.getElementById('month-year');
  const calendarDays = document.getElementById('calendar-days');
  const prevMonth = document.getElementById('prev-month');
  const nextMonth = document.getElementById('next-month');
  
  if (!monthYear || !calendarDays) return;
  
  let currentDate = new Date();
  
  function renderCalendar() {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    monthYear.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;
    
    calendarDays.innerHTML = '';
    
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    for (let i = 0; i < firstDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day empty';
      calendarDays.appendChild(emptyCell);
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      
      const dateKey = `${year}-${month + 1}-${day}`;
      if (hasEventOnDate(dateKey)) {
        dayElement.classList.add('has-event');
      }
      
      dayElement.addEventListener('click', () => showEventsForDate(year, month, day));
      calendarDays.appendChild(dayElement);
    }
  }
  
  function hasEventOnDate(dateKey) {
    const professorClasses = localStorage.getItem('professor_classes');
    let profClasses = [];
    if (professorClasses) {
      try {
        profClasses = JSON.parse(professorClasses);
      } catch (e) {
        console.error('Error loading professor data:', e);
      }
    }
    
    for (const classItem of enrolledClasses) {
      const matchingClass = profClasses.find(pc => pc.code === classItem.code);
      const assignments = matchingClass && matchingClass.assignments ? matchingClass.assignments : (classItem.assignments || []);
      
      if (assignments) {
        for (const assignment of assignments) {
          const dueDate = new Date(assignment.dueDate);
          const assignmentDateKey = `${dueDate.getFullYear()}-${dueDate.getMonth() + 1}-${dueDate.getDate()}`;
          if (assignmentDateKey === dateKey) {
            return true;
          }
        }
      }
    }
    return false;
  }
  
  function showEventsForDate(year, month, day) {
    const selectedDate = document.getElementById('selected-date');
    const eventList = document.getElementById('event-list');
    
    if (!selectedDate || !eventList) return;
    
    const date = new Date(year, month, day);
    selectedDate.textContent = date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    const professorClasses = localStorage.getItem('professor_classes');
    let profClasses = [];
    if (professorClasses) {
      try {
        profClasses = JSON.parse(professorClasses);
      } catch (e) {
        console.error('Error loading professor data:', e);
      }
    }
    
    const events = [];
    enrolledClasses.forEach(classItem => {
      const matchingClass = profClasses.find(pc => pc.code === classItem.code);
      const assignments = matchingClass && matchingClass.assignments ? matchingClass.assignments : (classItem.assignments || []);
      
      if (assignments) {
        assignments.forEach(assignment => {
          const dueDate = new Date(assignment.dueDate);
          if (dueDate.getFullYear() === year && 
              dueDate.getMonth() === month && 
              dueDate.getDate() === day) {
            events.push(`Assignment: ${assignment.title} (${classItem.name})`);
          }
        });
      }
    });
    
    eventList.innerHTML = '';
    if (events.length === 0) {
      eventList.innerHTML = '<li>No events or deadlines for this day</li>';
    } else {
      events.forEach(event => {
        const li = document.createElement('li');
        li.textContent = event;
        eventList.appendChild(li);
      });
    }
  }
  
  if (prevMonth) {
    prevMonth.addEventListener('click', () => {
      currentDate.setMonth(currentDate.getMonth() - 1);
      renderCalendar();
    });
  }
  
  if (nextMonth) {
    nextMonth.addEventListener('click', () => {
      currentDate.setMonth(currentDate.getMonth() + 1);
      renderCalendar();
    });
  }
  
  renderCalendar();
}

async function updateDashboardStats() {
  try {
    const response = await fetch('/api/student/stats');
    if (response.ok) {
      const stats = await response.json();
      
      document.getElementById('enrolled-classes-count').textContent = stats.enrolled_classes;
      
      calculateDashboardStats();
    } else {
      calculateDashboardStats();
    }
  } catch (error) {
    console.error('Error fetching stats:', error);
    calculateDashboardStats();
  }
  
  updateDeadlineList();
  updateRecentActivity();
}

function calculateDashboardStats() {
  const enrolledClassesCount = enrolledClasses.length;
  let pendingAssignments = 0;
  let upcomingDeadlines = 0;
  let completedAssignments = 0;
  
  const professorClasses = localStorage.getItem('professor_classes');
  let profClasses = [];
  if (professorClasses) {
    try {
      profClasses = JSON.parse(professorClasses);
    } catch (e) {
      console.error('Error loading professor data:', e);
    }
  }
  
  enrolledClasses.forEach(classItem => {
    const matchingClass = profClasses.find(pc => pc.code === classItem.code);
    const assignments = matchingClass && matchingClass.assignments ? matchingClass.assignments : (classItem.assignments || []);
    
    if (assignments) {
      assignments.forEach(assignment => {
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => s.studentId === String(studentData.id)) : null;
        
        if (submission) {
          completedAssignments++;
        } else {
          const dueDate = new Date(assignment.dueDate);
          const today = new Date();
          
          if (dueDate > today) {
            pendingAssignments++;
          }
        }
        
        const dueDate = new Date(assignment.dueDate);
        const today = new Date();
        const daysUntilDue = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
        
        if (daysUntilDue >= 0 && daysUntilDue <= 7 && !submission) {
          upcomingDeadlines++;
        }
      });
    }
  });
  
  document.getElementById('enrolled-classes-count').textContent = enrolledClassesCount;
  document.getElementById('pending-assignments').textContent = pendingAssignments;
  document.getElementById('upcoming-deadlines').textContent = upcomingDeadlines;
  document.getElementById('completed-assignments').textContent = completedAssignments;
}

function updateDeadlineList() {
  const deadlineList = document.getElementById('deadline-list');
  if (!deadlineList) return;
  
  deadlineList.innerHTML = '';
  
  let allDeadlines = [];
  
  const professorClasses = localStorage.getItem('professor_classes');
  let profClasses = [];
  if (professorClasses) {
    try {
      profClasses = JSON.parse(professorClasses);
    } catch (e) {
      console.error('Error loading professor data:', e);
    }
  }
  
  enrolledClasses.forEach(classItem => {
    const matchingClass = profClasses.find(pc => pc.code === classItem.code);
    const assignments = matchingClass && matchingClass.assignments ? matchingClass.assignments : (classItem.assignments || []);
    
    if (assignments) {
      assignments.forEach(assignment => {
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => s.studentId === String(studentData.id)) : null;
        
        if (!submission) {
          const dueDate = new Date(assignment.dueDate);
          const today = new Date();
          
          if (dueDate > today) {
            allDeadlines.push({
              title: assignment.title,
              class: classItem.name,
              dueDate: dueDate,
              classId: classItem.id
            });
          }
        }
      });
    }
  });
  
  allDeadlines.sort((a, b) => a.dueDate - b.dueDate);
  allDeadlines = allDeadlines.slice(0, 5);
  
  if (allDeadlines.length === 0) {
    deadlineList.innerHTML = '<li>No upcoming deadlines</li>';
    return;
  }
  
  allDeadlines.forEach(deadline => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span class="deadline-title">${deadline.title}</span>
      <span class="deadline-class">${deadline.class}</span>
      <span class="deadline-date">${deadline.dueDate.toLocaleDateString()}</span>
      <button class="btn-small" onclick="openClass('${deadline.classId}')">View</button>
    `;
    deadlineList.appendChild(li);
  });
}

function updateRecentActivity() {
  const activityList = document.getElementById('activity-list');
  if (!activityList) return;
  
  activityList.innerHTML = '';
  
  let allActivities = [];
  
  enrolledClasses.forEach(classItem => {
    allActivities.push({
      type: 'enrollment',
      class: classItem.name,
      date: new Date(classItem.enrollmentDate || new Date()),
      classId: classItem.id
    });
    
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => s.studentId === String(studentData.id)) : null;
        
        if (submission) {
          allActivities.push({
            type: 'submission',
            class: classItem.name,
            assignment: assignment.title,
            date: new Date(submission.date),
            classId: classItem.id
          });
        }
        
        allActivities.push({
          type: 'assignment_created',
          class: classItem.name,
          assignment: assignment.title,
          date: new Date(assignment.dateCreated || assignment.dueDate),
          classId: classItem.id
        });
      });
    }
    
    if (classItem.materials) {
      classItem.materials.forEach(material => {
        allActivities.push({
          type: 'material',
          class: classItem.name,
          material: material.title,
          date: new Date(material.date),
          classId: classItem.id
        });
      });
    }
  });
  
  allActivities.sort((a, b) => b.date - a.date);
  allActivities = allActivities.slice(0, 10);
  
  if (allActivities.length === 0) {
    activityList.innerHTML = '<li>No recent activity</li>';
    return;
  }
  
  allActivities.forEach(activity => {
    const li = document.createElement('li');
    
    let activityText = '';
    let icon = '';
    
    switch (activity.type) {
      case 'enrollment':
        activityText = `Enrolled in ${activity.class}`;
        icon = 'fas fa-user-plus';
        break;
      case 'submission':
        activityText = `Submitted "${activity.assignment}" in ${activity.class}`;
        icon = 'fas fa-paper-plane';
        break;
      case 'assignment_created':
        activityText = `New assignment "${activity.assignment}" in ${activity.class}`;
        icon = 'fas fa-tasks';
        break;
      case 'material':
        activityText = `New material "${activity.material}" in ${activity.class}`;
        icon = 'fas fa-file-upload';
        break;
    }
    
    li.innerHTML = `
      <i class="${icon}"></i>
      <div class="activity-content">
        <span class="activity-text">${activityText}</span>
        <span class="activity-date">${activity.date.toLocaleDateString()}</span>
      </div>
      <button class="btn-small" onclick="openClass('${activity.classId}')">View</button>
    `;
    activityList.appendChild(li);
  });
}

function showMessage(message, type) {
  const messageEl = document.getElementById('profile-message');
  if (!messageEl) return;
  
  messageEl.textContent = message;
  messageEl.className = `profile-message ${type}`;
  messageEl.style.display = 'block';
  
  setTimeout(() => {
    messageEl.style.display = 'none';
  }, 5000);
}

// ✅ FIX #2: Monitor for new grades and send notifications
function checkForNewGrades() {
  const lastCheck = localStorage.getItem('student_last_grade_check');
  const lastCheckTime = lastCheck ? new Date(lastCheck) : new Date(0);
  
  enrolledClasses.forEach(classItem => {
    if (classItem.assignments) {
      classItem.assignments.forEach(assignment => {
        const submission = assignment.submissions ? 
          assignment.submissions.find(s => String(s.studentId) === String(studentData.id)) : null;
        
        if (submission && submission.grade !== undefined) {
          // Check if this grade was added recently
          const submissionDate = new Date(submission.date);
          
          // If grade exists and submission was recent, it's a new grade
          if (submissionDate > lastCheckTime) {
            const percentage = ((submission.grade / assignment.points) * 100).toFixed(1);
            
            addNotification(
              'grade',
              'Grade Released',
              `"${assignment.title}" - ${submission.grade}/${assignment.points} (${percentage}%)`,
              `class:${classItem.id}`
            );
            
            // If there's feedback, add separate notification
            if (submission.feedback) {
              addNotification(
                'feedback',
                'Feedback Received',
                `Your professor left feedback on "${assignment.title}"`,
                `class:${classItem.id}`
              );
            }
          }
        }
      });
    }
  });
  
  localStorage.setItem('student_last_grade_check', new Date().toISOString());
}

// ✅ FIX #2: Call check functions periodically
setInterval(() => {
  if (studentData && studentData.id) {
    checkForNewAssignments();
    checkUpcomingDeadlines();
    checkForNewGrades();
  }
}, 60000); // Check every minute

// ✅ FIX #2: Request notification permission on page load
if ("Notification" in window && Notification.permission === "default") {
  Notification.requestPermission();
}

// ✅ NEW: Enhanced downloadFile function with VIDEO PLAYER support
function downloadFile(filename, urlOrContent) {
  console.log('📥 Downloading/Playing file:', filename);
  
  // ✅ CHECK IF IT'S A VIDEO FILE
  const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
  const fileExtension = filename.split('.').pop().toLowerCase();
  const isVideo = videoExtensions.includes(fileExtension);
  
  // ✅ IF VIDEO, SHOW PLAYER MODAL
  if (isVideo && urlOrContent && urlOrContent.startsWith('/uploads/')) {
    showVideoPlayer(filename, urlOrContent);
    return;
  }
  
  // Regular file download for non-video files
  if (urlOrContent && urlOrContent.startsWith('/uploads/')) {
    const link = document.createElement('a');
    link.href = urlOrContent;
    link.download = filename;
    link.target = '_blank';
    
    document.body.appendChild(link);
    link.click();
    
    setTimeout(() => {
      document.body.removeChild(link);
    }, 100);
    
    return;
  }
  
  if (urlOrContent && urlOrContent.startsWith('data:')) {
    try {
      const link = document.createElement('a');
      link.href = urlOrContent;
      link.download = filename;
      
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
      }, 100);
      
    } catch (e) {
      console.error('❌ Error downloading file:', e);
      alert('Error downloading file: ' + e.message);
    }
    return;
  }
  
  console.error('❌ Invalid file format:', urlOrContent ? urlOrContent.substring(0, 50) : 'empty');
  alert('⚠️ Invalid file format. Please contact your professor.');
}

// ✅ NEW: Video player modal function
function showVideoPlayer(filename, videoUrl) {
  // Remove existing video modal if any
  const existingModal = document.getElementById('video-player-modal');
  if (existingModal) {
    existingModal.remove();
  }
  
  // Create video player modal
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.style.display = 'flex';
  modal.style.zIndex = '10001';
  modal.id = 'video-player-modal';
  
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 900px; max-height: 95vh; overflow: hidden;">
      <div class="modal-header">
        <h3><i class="fas fa-play-circle"></i> ${filename}</h3>
        <button class="close-btn" onclick="closeVideoPlayer()">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="modal-body" style="padding: 0; background: #000;">
        <video 
          id="assignment-video-player" 
          controls 
          controlsList="nodownload"
          style="width: 100%; max-height: 70vh; display: block;"
          autoplay>
          <source src="${videoUrl}" type="video/${filename.split('.').pop()}">
          Your browser does not support the video tag.
        </video>
      </div>
      <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.5rem;">
        <div style="display: flex; gap: 1rem; align-items: center;">
          <button onclick="togglePlayPause()" class="btn-secondary" style="min-width: 100px;">
            <i class="fas fa-pause" id="play-pause-icon"></i> <span id="play-pause-text">Pause</span>
          </button>
          <button onclick="toggleFullscreen()" class="btn-secondary">
            <i class="fas fa-expand"></i> Fullscreen
          </button>
        </div>
        <div style="display: flex; gap: 0.5rem;">
          <button onclick="changePlaybackSpeed(-0.25)" class="btn-outline" title="Slower">
            <i class="fas fa-backward"></i>
          </button>
          <span id="playback-speed" style="padding: 0.5rem 1rem; background: #f8f9fa; border-radius: 6px; font-weight: 600;">1.0x</span>
          <button onclick="changePlaybackSpeed(0.25)" class="btn-outline" title="Faster">
            <i class="fas fa-forward"></i>
          </button>
        </div>
        <a href="${videoUrl}" download="${filename}" class="btn-primary" style="text-decoration: none;">
          <i class="fas fa-download"></i> Download
        </a>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Close on outside click
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeVideoPlayer();
    }
  });
  
  // Add keyboard shortcuts
  document.addEventListener('keydown', videoKeyboardHandler);
}

// ✅ Close video player
function closeVideoPlayer() {
  const modal = document.getElementById('video-player-modal');
  if (modal) {
    const video = document.getElementById('assignment-video-player');
    if (video) {
      video.pause();
    }
    modal.remove();
    document.removeEventListener('keydown', videoKeyboardHandler);
  }
}

// ✅ Toggle play/pause
function togglePlayPause() {
  const video = document.getElementById('assignment-video-player');
  const icon = document.getElementById('play-pause-icon');
  const text = document.getElementById('play-pause-text');
  
  if (video.paused) {
    video.play();
    icon.className = 'fas fa-pause';
    text.textContent = 'Pause';
  } else {
    video.pause();
    icon.className = 'fas fa-play';
    text.textContent = 'Play';
  }
}

// ✅ Toggle fullscreen
function toggleFullscreen() {
  const video = document.getElementById('assignment-video-player');
  
  if (!document.fullscreenElement) {
    if (video.requestFullscreen) {
      video.requestFullscreen();
    } else if (video.webkitRequestFullscreen) {
      video.webkitRequestFullscreen();
    } else if (video.msRequestFullscreen) {
      video.msRequestFullscreen();
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }
}

// ✅ Change playback speed
function changePlaybackSpeed(delta) {
  const video = document.getElementById('assignment-video-player');
  const speedDisplay = document.getElementById('playback-speed');
  
  let newSpeed = video.playbackRate + delta;
  
  // Clamp between 0.25x and 2.0x
  newSpeed = Math.max(0.25, Math.min(2.0, newSpeed));
  
  video.playbackRate = newSpeed;
  speedDisplay.textContent = newSpeed.toFixed(2) + 'x';
}

// ✅ Keyboard shortcuts for video player
function videoKeyboardHandler(e) {
  const video = document.getElementById('assignment-video-player');
  if (!video) return;
  
  switch(e.key) {
    case ' ':
    case 'k':
      e.preventDefault();
      togglePlayPause();
      break;
    case 'f':
      e.preventDefault();
      toggleFullscreen();
      break;
    case 'ArrowLeft':
      e.preventDefault();
      video.currentTime -= 5; // Rewind 5 seconds
      break;
    case 'ArrowRight':
      e.preventDefault();
      video.currentTime += 5; // Forward 5 seconds
      break;
    case 'ArrowUp':
      e.preventDefault();
      video.volume = Math.min(1, video.volume + 0.1);
      break;
    case 'ArrowDown':
      e.preventDefault();
      video.volume = Math.max(0, video.volume - 0.1);
      break;
    case 'm':
      e.preventDefault();
      video.muted = !video.muted;
      break;
    case 'Escape':
      closeVideoPlayer();
      break;
  }
}