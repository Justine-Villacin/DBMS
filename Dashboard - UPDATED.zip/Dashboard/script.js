function showSection(sectionId, el) {
    document.querySelectorAll('.content-section').forEach(sec => {
      sec.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');

    document.querySelectorAll('.sidebar a').forEach(link => {
      link.classList.remove('active');
    });
    el.classList.add('active');
  }

  function logOut() {
    alert("You have logged out!");
    // window.location.href = "login.html";
  }

  function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("collapsed");
  }

  function saveAccount() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const studentId = document.getElementById("student-id").value;

  // update display
  document.getElementById("display-student-id").textContent = studentId || "Student ID";

  alert("Account updated!\nUsername: " + username + "\nPassword: " + password + "\nStudent ID: " + studentId);
  }

  function saveUserInfo() {
    const name = document.getElementById("name").value;
    document.getElementById("display-name").textContent = name || "Your Name";

    const gender = document.getElementById("gender").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const yearLevel = document.getElementById("year-level").value;
    const section = document.getElementById("section").value;

    alert("User Info updated!\nName: " + name + "\nGender: " + gender + "\nEmail: " + email +
          "\nPhone: " + phone + "\nYear Level: " + yearLevel + "\nSection: " + section);
  }

  function previewProfilePicture(event) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        // Update big profile preview
        document.getElementById("profile-preview").src = e.target.result;

        // Update topbar small avatar
        document.getElementById("topbar-avatar").src = e.target.result;
      };
      reader.readAsDataURL(file);
    }
    }

      // Calendar Setup
  const monthYear = document.getElementById("month-year");
  const calendarDays = document.getElementById("calendar-days");
  const prevMonthBtn = document.getElementById("prev-month");
  const nextMonthBtn = document.getElementById("next-month");

  let date = new Date();
  let events = {}; // store events { "YYYY-MM-DD": ["event1", "event2"] }

  // Render Calendar
  function renderCalendar() {
    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];

    monthYear.textContent = `${monthNames[month]} ${year}`;
    calendarDays.innerHTML = "";

    // Add blank days before start
    for (let i = 0; i < firstDay; i++) {
      const empty = document.createElement("div");
      calendarDays.appendChild(empty);
    }

    // Add days
    for (let day = 1; day <= lastDate; day++) {
      const dayElement = document.createElement("div");
      dayElement.textContent = day;

      const today = new Date();
      if (
        day === today.getDate() &&
        month === today.getMonth() &&
        year === today.getFullYear()
      ) {
        dayElement.classList.add("today");
      }

      // Add event indicator
      const dateKey = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      if (events[dateKey] && events[dateKey].length > 0) {
        dayElement.classList.add("has-event");
      }

      calendarDays.appendChild(dayElement);
    }
  }

  // Month navigation
  prevMonthBtn.addEventListener("click", () => {
    date.setMonth(date.getMonth() - 1);
    renderCalendar();
  });

  nextMonthBtn.addEventListener("click", () => {
    date.setMonth(date.getMonth() + 1);
    renderCalendar();
  });

  // =================
  // Event Side Panel Logic
  // =================
  const eventModal = document.getElementById("event-modal");
  const selectedDateText = document.getElementById("selected-date");
  const eventText = document.getElementById("event-text");
  const saveEventBtn = document.getElementById("save-event");
  const closeEventBtn = document.getElementById("close-event");
  const eventList = document.getElementById("event-list");

  let activeDate = null;

  // Open modal on day click
  calendarDays.addEventListener("click", (e) => {
    if (e.target && e.target.textContent && !isNaN(e.target.textContent)) {
      const day = e.target.textContent;
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      activeDate = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      
      selectedDateText.textContent = `Events on ${activeDate}`;
      eventText.value = "";
      renderEvents();
      eventModal.classList.add("active");   // ✅ side panel slides in
    }
  });

  // Save event
  saveEventBtn.addEventListener("click", () => {
    if (!events[activeDate]) events[activeDate] = [];
    if (eventText.value.trim() !== "") {
      events[activeDate].push(eventText.value.trim());
    }
    eventText.value = "";
    renderEvents();
    renderCalendar(); // refresh dots
  });

  // Close modal
  closeEventBtn.addEventListener("click", () => {
    eventModal.classList.remove("active");   // ✅ slide out
  });

  // Render event list with delete buttons
  function renderEvents() {
  eventList.innerHTML = "";
  if (events[activeDate]) {
    events[activeDate].forEach((ev, index) => {
      const li = document.createElement("li");

      // Create a container for text + delete button
      const wrapper = document.createElement("div");
      wrapper.classList.add("event-item");

      // Event text
      const textSpan = document.createElement("span");
      textSpan.textContent = ev;

      // Delete button
      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "✖";
      deleteBtn.classList.add("delete-btn");

      // Delete event on click
      deleteBtn.addEventListener("click", () => {
        events[activeDate].splice(index, 1);
        renderEvents();
        renderCalendar();
      });

      wrapper.appendChild(textSpan);
      wrapper.appendChild(deleteBtn);
      li.appendChild(wrapper);
      eventList.appendChild(li);
    });
  }
}

  // Initial render
  renderCalendar();
